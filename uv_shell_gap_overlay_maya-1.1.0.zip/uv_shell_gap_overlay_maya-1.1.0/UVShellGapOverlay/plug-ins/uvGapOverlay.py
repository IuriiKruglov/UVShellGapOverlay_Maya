# SPDX-License-Identifier: GPL-3.0-or-later
#
# UV Shell Gap Overlay for Maya - Viewport 2.0 plug-in: a locator whose draw override colors
# the shown meshes' faces by texel density. The UV Gaps window creates the locator (never
# saved with the scene) and hands it the triangles to draw (uvgap.td3d).
#
# Authors: Iurii Kruglov & Claude (Anthropic)

import maya.api.OpenMaya as om
import maya.api.OpenMayaRender as omr
import maya.api.OpenMayaUI as omui

NODE_TYPE = "uvGapOverlay"
# A node id from the range Autodesk leaves for local use. The node is never written to a
# scene file, so the id only has to differ from the other plug-ins loaded in the session.
NODE_ID = om.MTypeId(0x0007E5A1)
DRAW_CLASSIFICATION = "drawdb/geometry/uvGapOverlay"
DRAW_REGISTRANT = "uvGapOverlayPlugin"
VERSION = "1.1.0"


def maya_useNewAPI():
    """This plug-in uses the Maya Python API 2.0."""
    pass


def _items():
    """What to draw: [(MPointArray positions, [(MColor, MUintArray triangle indices), ...])]."""
    try:
        from uvgap import td3d
    except Exception:
        return None, ()
    return td3d, td3d.draw_items()


class UVGapOverlayNode(omui.MPxLocatorNode):
    @staticmethod
    def creator():
        return UVGapOverlayNode()

    @staticmethod
    def initialize():
        pass

    def __init__(self):
        omui.MPxLocatorNode.__init__(self)

    def isBounded(self):
        return False

    def excludeAsLocator(self):
        return True  # not filtered as a locator: still drawn when Show > Locators is off


class _Data(om.MUserData):
    def __init__(self):
        try:
            om.MUserData.__init__(self, False)  # keep after drawing
        except TypeError:
            om.MUserData.__init__(self)
            try:
                self.setDeleteAfterUse(False)
            except Exception:
                pass


class UVGapDrawOverride(omr.MPxDrawOverride):
    @staticmethod
    def creator(obj):
        return UVGapDrawOverride(obj)

    @staticmethod
    def draw(context, data):
        return

    def __init__(self, obj):
        # not always dirty: the drawables are rebuilt only when uvgap.td3d marks the node dirty
        omr.MPxDrawOverride.__init__(self, obj, UVGapDrawOverride.draw, False)

    def supportedDrawAPIs(self):
        return omr.MRenderer.kAllDevices

    def isBounded(self, objPath, cameraPath):
        return False

    def boundingBox(self, objPath, cameraPath):
        return om.MBoundingBox()

    def transform(self, objPath, cameraPath):
        return om.MMatrix()  # the points are in world space, wherever the locator is

    def disableInternalBoundingBoxDraw(self):
        return True

    def prepareForDraw(self, objPath, cameraPath, frameContext, oldData):
        return oldData if isinstance(oldData, _Data) else _Data()

    def hasUIDrawables(self):
        return True

    def addUIDrawables(self, objPath, drawManager, frameContext, data):
        mod, items = _items()
        if mod is None:
            return
        mod.note_draw()
        if not items:
            return
        drawManager.beginDrawable(omr.MUIDrawManager.kNonSelectable)
        try:
            drawManager.setDepthPriority(omr.MRenderItem.sActiveWireDepthPriority)
            for positions, groups in items:
                for color, index in groups:
                    drawManager.setColor(color)
                    drawManager.mesh(omr.MUIDrawManager.kTriangles, positions, None, None, index)
        finally:
            drawManager.endDrawable()


def initializePlugin(obj):
    plugin = om.MFnPlugin(obj, "Iurii Kruglov & Claude (Anthropic)", VERSION, "Any")
    plugin.registerNode(NODE_TYPE, NODE_ID, UVGapOverlayNode.creator, UVGapOverlayNode.initialize,
                        om.MPxNode.kLocatorNode, DRAW_CLASSIFICATION)
    try:
        omr.MDrawRegistry.registerDrawOverrideCreator(DRAW_CLASSIFICATION, DRAW_REGISTRANT,
                                                      UVGapDrawOverride.creator)
    except Exception:
        plugin.deregisterNode(NODE_ID)
        raise


def uninitializePlugin(obj):
    # (Maya unloads the plug-in only once no uvGapOverlay node is left: closing the UV Gaps
    # window or turning its 3D colors off deletes the node)
    plugin = om.MFnPlugin(obj)
    omr.MDrawRegistry.deregisterDrawOverrideCreator(DRAW_CLASSIFICATION, DRAW_REGISTRANT)
    plugin.deregisterNode(NODE_ID)
