# SPDX-License-Identifier: GPL-3.0-or-later
#
# UV Shell Gap Overlay for Maya - the UV view on the GPU (OpenGL through Qt): the UV layout,
# texel density fill, selection and gap overlay live in GPU buffers built once per change, so
# panning and zooming only redraw them. Labels and the HUD are drawn with QPainter on top.
# Falls back to the QPainter view (view.py) when OpenGL isn't usable.
#
# Authors: Iurii Kruglov & Claude (Anthropic)

import time
import traceback

import numpy as np

from . import core
from .qtcompat import QtCore, QtGui, Signal, gl_classes
from .view import BG, WIRE, BORDER, SEL_RGB, PREVIEW_RGB, UV_STEPS, ViewBase, thin

GL_LINES, GL_TRIANGLES = 0x0001, 0x0004
GL_FLOAT, GL_UNSIGNED_BYTE = 0x1406, 0x1401
GL_COLOR_BUFFER_BIT, GL_BLEND, GL_DEPTH_TEST, GL_CULL_FACE = 0x4000, 0x0BE2, 0x0B71, 0x0B44
GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA = 0x0302, 0x0303
GL_VERSION = 0x1F02

_GLC = gl_classes()

# -- shaders: GLSL 3.30 core, 1.20 for old contexts, and their OpenGL ES forms (3.00 es, 1.00) ----

_FLAT = ("""
in vec2 pos;
uniform vec4 xf;
void main() { gl_Position = vec4(pos * xf.xy + xf.zw, 0.0, 1.0); }
""", """
uniform vec4 color;
void main() { FRAG = color; }
""", ("pos",))

_VCOL = ("""
in vec2 pos;
in vec4 col;
uniform vec4 xf;
uniform float alpha;
out vec4 vcol;
void main() { gl_Position = vec4(pos * xf.xy + xf.zw, 0.0, 1.0); vcol = vec4(col.rgb, col.a * alpha); }
""", """
in vec4 vcol;
void main() { FRAG = vcol; }
""", ("pos", "col"))

# a line from a to b (UV, plus pixel offsets apx / bpx) as two triangles hw pixels to each side;
# cn: (which end 0 / 1, side -1 / +1); cap extends the ends by hw (square ends: dots, when a = b)
_THICK = ("""
in vec2 a;
in vec2 b;
in vec2 apx;
in vec2 bpx;
in vec2 cn;
in vec4 col;
uniform vec4 xf;
uniform vec2 vp;
uniform float hw;
uniform float cap;
uniform float alpha;
out vec4 vcol;
void main() {
    vec2 h = vp * 0.5;
    vec2 sa = (a * xf.xy + xf.zw) * h + apx;
    vec2 sb = (b * xf.xy + xf.zw) * h + bpx;
    vec2 d = sb - sa;
    float len = length(d);
    d = len > 1e-4 ? d / len : vec2(1.0, 0.0);
    vec2 n = vec2(-d.y, d.x);
    vec2 p = mix(sa, sb, cn.x) + n * (cn.y * hw) + d * ((2.0 * cn.x - 1.0) * cap * hw);
    gl_Position = vec4(p / h, 0.0, 1.0);
    vcol = vec4(col.rgb, col.a * alpha);
}
""", """
in vec4 vcol;
void main() { FRAG = vcol; }
""", ("a", "b", "apx", "bpx", "cn", "col"))

THICK_DTYPE = np.dtype([("a", np.float32, 2), ("b", np.float32, 2), ("apx", np.float32, 2),
                        ("bpx", np.float32, 2), ("cn", np.float32, 2), ("col", np.uint8, 4)])
_CORNERS = np.array([[0, -1], [0, 1], [1, 1], [0, -1], [1, 1], [1, -1]], dtype=np.float32)


def _source(body, vertex, modern, es=False):
    """The shader for the context: `modern` (in / out; desktop 3.3+, ES 3.0+) or the old
    attribute / varying form; `es`: OpenGL ES (ANGLE, embedded drivers)."""
    precision = "precision highp float;\n" if es else ""
    if modern:
        head = ("#version 300 es\n" if es else "#version 330 core\n") + precision
        if not vertex:
            head += "out vec4 frag_out;\n#define FRAG frag_out\n"
        return head + body
    body = body.replace("in vec", "attribute vec" if vertex else "varying vec")
    body = body.replace("out vec4 vcol", "varying vec4 vcol")
    return ("#version 100\n" if es else "#version 120\n") + precision + "#define FRAG gl_FragColor\n" + body


def thick_lines(A, B, rgba, apx=None, bpx=None):
    """Vertices (THICK_DTYPE) of lines A[i] -> B[i] (UV, already relative to the reference point),
    rgba: (n, 4) uint8 or one color; apx / bpx: pixel offsets of the ends."""
    n = A.shape[0]
    v = np.zeros((n, 6), dtype=THICK_DTYPE)
    v["a"] = A.astype(np.float32)[:, None, :]
    v["b"] = B.astype(np.float32)[:, None, :]
    if apx is not None:
        v["apx"] = np.broadcast_to(np.asarray(apx, dtype=np.float32).reshape(-1, 2), (n, 2))[:, None, :]
    if bpx is not None:
        v["bpx"] = np.broadcast_to(np.asarray(bpx, dtype=np.float32).reshape(-1, 2), (n, 2))[:, None, :]
    v["cn"] = _CORNERS[None, :, :]
    v["col"] = np.broadcast_to(np.asarray(rgba, dtype=np.uint8).reshape(-1, 4), (n, 4))[:, None, :]
    return v.reshape(-1)


def rgba8(rgb, alpha=1.0):
    rgb = np.asarray(rgb, dtype=np.float64).reshape(-1, 3)
    out = np.empty((rgb.shape[0], 4), dtype=np.uint8)
    out[:, :3] = np.clip(np.rint(rgb * 255.0), 0, 255)
    out[:, 3] = int(round(255 * max(0.0, min(1.0, alpha))))
    return out


if _GLC is not None:
    QOpenGLWidget, QOpenGLShaderProgram, QOpenGLShader, QOpenGLBuffer, QOpenGLVertexArrayObject = _GLC

    class _Buf(object):
        """A vertex buffer and how many vertices it holds."""

        def __init__(self, data):
            self.count = int(data.shape[0])
            self.buf = QOpenGLBuffer(QOpenGLBuffer.Type.VertexBuffer)
            self.buf.create()
            self.buf.bind()
            raw = np.ascontiguousarray(data).tobytes()
            self.buf.allocate(raw, len(raw))
            self.buf.release()

        def destroy(self):
            try:
                self.buf.destroy()
            except Exception:
                pass

    class GLView(ViewBase, QOpenGLWidget):
        """The UV view drawn with OpenGL. `gl_failed` tells the panel to use the QPainter view."""

        gl_failed = Signal(str)

        def __init__(self, engine, parent=None):
            QOpenGLWidget.__init__(self, parent)
            self._ready = False
            self._failed = None
            self._bufs = {}   # name -> (key, _Buf or None)
            self._ref = np.zeros(2)
            self._ref_key = None
            self._errors = 0
            self._init_view(engine)

        # -- context -------------------------------------------------------------------------------

        def showEvent(self, event):
            QOpenGLWidget.showEvent(self, event)
            if not self._ready and self._failed is None:  # shown: OpenGL must be there soon
                QtCore.QTimer.singleShot(1500, self._check_alive)

        def _check_alive(self):
            try:
                if not self._ready and self._failed is None and self.isVisible():
                    self._fail("no OpenGL context")
            except RuntimeError:  # (the widget is gone)
                pass

        def _fail(self, msg):
            if self._failed is None:
                self._failed = msg
                QtCore.QTimer.singleShot(0, self._tell_failed)

        def _tell_failed(self):
            try:
                self.gl_failed.emit(self._failed)
            except RuntimeError:  # (the widget is gone)
                pass

        def initializeGL(self):
            self._bufs = {}  # (a new context: the old buffers went with the old one)
            self._ready = False
            try:
                ctx = self.context()
                fmt = ctx.format()
                self.f = ctx.functions()
                es = bool(ctx.isOpenGLES())
                modern = (fmt.majorVersion(), fmt.minorVersion()) >= ((3, 0) if es else (3, 3))
                self.gl_info = "OpenGL %s%d.%d %s" % ("ES " if es else "", fmt.majorVersion(), fmt.minorVersion(),
                                                      self.f.glGetString(GL_VERSION) or "")
                self._p_flat = self._program(_FLAT, modern, es)
                self._p_vcol = self._program(_VCOL, modern, es)
                self._p_thick = self._program(_THICK, modern, es)
                self._vao = QOpenGLVertexArrayObject(self)
                if not self._vao.create():
                    if modern and fmt.profile() == QtGui.QSurfaceFormat.OpenGLContextProfile.CoreProfile:
                        raise RuntimeError("no vertex array objects")
                    self._vao = None
                self._ready = True
            except Exception as e:
                self._fail(str(e))
                print("[UV Shell Gap Overlay] GPU view not available, using the standard view:\n" +
                      traceback.format_exc())

        def _program(self, spec, modern, es=False):
            vs, fs, attrs = spec
            prog = QOpenGLShaderProgram(self)
            ok = (prog.addShaderFromSourceCode(QOpenGLShader.ShaderTypeBit.Vertex, _source(vs, True, modern, es)) and
                  prog.addShaderFromSourceCode(QOpenGLShader.ShaderTypeBit.Fragment, _source(fs, False, modern, es)))
            for i, name in enumerate(attrs):
                prog.bindAttributeLocation(name, i)
            if not ok or not prog.link():
                raise RuntimeError("shader: " + str(prog.log()))
            prog.loc = {n: prog.uniformLocation(n) for n in ("xf", "color", "alpha", "vp", "hw", "cap")}
            return prog

        # -- buffers -------------------------------------------------------------------------------

        def _buf(self, name, key, build):
            """The buffer `name`, built again (build() -> array or None) when its key changes."""
            hit = self._bufs.get(name)
            if hit is not None and hit[0] == key:
                return hit[1]
            if hit is not None and hit[1] is not None:
                hit[1].destroy()
            data = build()
            buf = _Buf(data) if data is not None and data.shape[0] else None
            self._bufs[name] = (key, buf)
            return buf

        def _rel(self, P):
            return (np.asarray(P, dtype=np.float64).reshape(-1, 2) - self._ref).astype(np.float32)

        def _update_ref(self):
            """UVs go to the GPU relative to a point near them (float32 keeps its precision)."""
            eng = self.engine
            if self._ref_key != eng.geo_version:
                geo = eng.geo
                self._ref = ((geo.bmin.min(axis=0) + geo.bmax.max(axis=0)) * 0.5) if geo.nshells else np.zeros(2)
                self._ref = np.floor(self._ref)
                self._ref_key = eng.geo_version
                for name in list(self._bufs):  # everything is relative to the reference point
                    self._bufs[name] = (None, self._bufs[name][1])

        # -- drawing -------------------------------------------------------------------------------

        def _clip_xf(self):
            """UV (relative to the reference point) -> clip space: scale x, y, offset x, y."""
            w, h = max(1.0, float(self.width())), max(1.0, float(self.height()))
            sx, sy = 2.0 * self.zoom / w, 2.0 * self.zoom / h
            return sx, sy, (self._ref[0] - self.u0) * sx - 1.0, (self._ref[1] - self.v0) * sy - 1.0

        def _use(self, prog, **uniforms):
            """Bind a program and set its uniforms (floats: glUniform*f says so plainly, where
            setUniformValue may pick an integer overload)."""
            prog.bind()
            f = self.f
            for name, val in uniforms.items():
                loc = prog.loc[name]
                if loc < 0:
                    continue
                if not isinstance(val, tuple):
                    f.glUniform1f(loc, float(val))
                elif len(val) == 2:
                    f.glUniform2f(loc, float(val[0]), float(val[1]))
                else:
                    f.glUniform4f(loc, float(val[0]), float(val[1]), float(val[2]), float(val[3]))
            return prog

        def _draw_flat(self, buf, mode, rgb, alpha):
            if buf is None:
                return
            prog = self._use(self._p_flat, xf=self._clip_xf(), color=(rgb[0], rgb[1], rgb[2], alpha))
            buf.buf.bind()
            prog.enableAttributeArray(0)
            prog.setAttributeBuffer(0, GL_FLOAT, 0, 2, 8)
            self.f.glDrawArrays(mode, 0, buf.count)
            prog.disableAttributeArray(0)
            buf.buf.release()

        def _draw_vcol(self, pos, col, alpha):
            if pos is None or col is None:
                return
            prog = self._use(self._p_vcol, xf=self._clip_xf(), alpha=alpha)
            pos.buf.bind()
            prog.enableAttributeArray(0)
            prog.setAttributeBuffer(0, GL_FLOAT, 0, 2, 8)
            col.buf.bind()
            prog.enableAttributeArray(1)
            prog.setAttributeBuffer(1, GL_UNSIGNED_BYTE, 0, 4, 4)
            self.f.glDrawArrays(GL_TRIANGLES, 0, min(pos.count, col.count))
            prog.disableAttributeArray(0)
            prog.disableAttributeArray(1)
            col.buf.release()

        def _draw_thick(self, buf, hw, cap=0.0, alpha=1.0):
            if buf is None:
                return
            prog = self._use(self._p_thick, xf=self._clip_xf(), vp=(max(1.0, float(self.width())),
                                                             max(1.0, float(self.height()))),
                             hw=float(hw), cap=float(cap), alpha=alpha)
            buf.buf.bind()
            stride = THICK_DTYPE.itemsize
            for i, (name, n) in enumerate((("a", 2), ("b", 2), ("apx", 2), ("bpx", 2), ("cn", 2))):
                prog.enableAttributeArray(i)
                prog.setAttributeBuffer(i, GL_FLOAT, THICK_DTYPE.fields[name][1], n, stride)
            prog.enableAttributeArray(5)
            prog.setAttributeBuffer(5, GL_UNSIGNED_BYTE, THICK_DTYPE.fields["col"][1], 4, stride)
            self.f.glDrawArrays(GL_TRIANGLES, 0, buf.count)
            for i in range(6):
                prog.disableAttributeArray(i)
            buf.buf.release()

        def paintGL(self):
            t0 = time.perf_counter()
            f = getattr(self, "f", None)
            if f is None or not self._ready:
                if f is not None:
                    f.glClearColor(BG.redF(), BG.greenF(), BG.blueF(), 1.0)
                    f.glClear(GL_COLOR_BUFFER_BIT)
                return
            try:
                self._paint_gl()
                self._errors = 0
                self._last_error = None
            except Exception:
                err = traceback.format_exc()
                if err != self._last_error:
                    print("[UV Shell Gap Overlay] GPU view error:\n" + err)
                    self._last_error = err
                self._errors += 1
                if self._errors >= 3:
                    self._fail("drawing failed")
            self.last_draw_ms = (time.perf_counter() - t0) * 1000.0
            self.engine.timings["draw"] = self.last_draw_ms

        def _paint_gl(self):
            f = self.f
            eng, st, geo = self.engine, self.engine.settings, self.engine.geo
            L = geo.layer
            f.glClearColor(BG.redF(), BG.greenF(), BG.blueF(), 1.0)
            f.glClear(GL_COLOR_BUFFER_BIT)
            f.glDisable(GL_DEPTH_TEST)
            f.glDisable(GL_CULL_FACE)
            f.glEnable(GL_BLEND)
            f.glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA)
            if self._vao is not None:
                self._vao.bind()
            self._update_ref()
            gv = eng.geo_version
            geo_dim = 0.35 if eng.geo_pending else 1.0
            meas_dim = 0.35 if eng.stale else 1.0
            sty = self._style()
            if st.show_grid:
                self._draw_grid()
            have = L is not None and L.nobj
            once, okey = self.shown_once()
            if have and st.td_show and eng.td.size == geo.sh_n:
                pos = self._buf("tri", gv, lambda: self._rel(L.pts[L.tri]))
                thr = st.thresholds()
                col = self._buf("td", (gv, eng.td_key, thr, okey), lambda: self._td_colors(geo, L, thr, once))
                self._draw_vcol(pos, col, float(st.td_fill_opacity) * geo_dim)
            meas_on = st.show and eng.meas is not None
            flip = geo.flipped & once if geo.nshells else geo.flipped
            if have and meas_on and st.show_flipped and flip.any():
                buf = self._buf("flip_fill", (gv, okey), lambda: self._flipped_tris(geo, L, flip))
                self._draw_flat(buf, GL_TRIANGLES, st.color_flipped, 0.22 * float(st.opacity) * meas_dim)
            sel = self.selection_display() if st.show_selection else None
            skey = (self._sel_cache[0] if self._sel_cache else None)
            if have and sel is not None and sel.faces.size:
                buf = self._buf("sel_faces", skey, lambda: self._rel(L.pts[L.tri[np.isin(L.tri_face, sel.faces)]]))
                self._draw_flat(buf, GL_TRIANGLES, SEL_RGB, 0.35)
            if have and st.show_wire:
                buf = self._buf("wire", gv, lambda: self._rel(L.pts[L.wire]))
                self._draw_flat(buf, GL_LINES, (WIRE.redF(), WIRE.greenF(), WIRE.blueF()), WIRE.alphaF())
            if geo.nshells:
                buf = self._buf("border", gv, lambda: self._rel(np.stack((geo.seg_a, geo.seg_b), axis=1)))
                self._draw_flat(buf, GL_LINES, (BORDER.redF(), BORDER.greenF(), BORDER.blueF()), BORDER.alphaF())
                hl = self._range_shells()
                if hl is not None:
                    buf = self._buf("range", hl[0], lambda: self._shell_outline(geo, hl[1], (1.0, 1.0, 1.0), 0.9))
                    self._draw_thick(buf, (sty["lw"] + 2.0) * 0.5, alpha=geo_dim)
            if have and sel is not None:
                if sel.shells.size:
                    buf = self._buf("sel_shells", skey, lambda: self._shell_outline(geo, sel.shells, SEL_RGB, 0.9))
                    self._draw_thick(buf, 0.9)
                if sel.edges.size:
                    buf = self._buf("sel_edges", skey, lambda: thick_lines(
                        self._rel(L.pts[sel.edges[:, 0]]), self._rel(L.pts[sel.edges[:, 1]]), rgba8(SEL_RGB)))
                    self._draw_thick(buf, 1.4)
            if have and meas_on and st.show_flipped and flip.any():
                buf = self._buf("flip_line", (gv, okey, tuple(st.color_flipped)),
                                lambda: self._shell_outline(geo, np.flatnonzero(flip), st.color_flipped, 1.0))
                self._draw_thick(buf, sty["lw"] * 0.5, alpha=float(st.opacity) * meas_dim)
            alpha = max(0.0, min(1.0, float(st.opacity))) * meas_dim
            fr = None
            if self.overlay_shown() and alpha > 0.0:
                fr, lab = self.label_frame(sty, alpha, lines=False)
                if meas_on:
                    mkey = (eng.meas.version, self._labels[0], sty["xh"])
                    lines = self._buf("m_lines", mkey, lambda: self._meas_lines(eng.meas, lab, st, sty))
                    dots = self._buf("m_dots", mkey, lambda: self._meas_dots(eng.meas, lab))
                    self._draw_thick(lines, sty["lw"] * 0.5, alpha=alpha)
                    self._draw_thick(dots, sty["dot"], cap=1.0, alpha=alpha)
            if have and sel is not None and sel.points.size:
                buf = self._buf("sel_pts", skey, lambda: thick_lines(
                    self._rel(L.pts[sel.points]), self._rel(L.pts[sel.points]), rgba8(SEL_RGB)))
                self._draw_thick(buf, 2.5, cap=1.0)
            pv = self.preview()
            if pv is not None:
                (P, Q), M = pv  # (it changes with every mouse move: built again each time)
                buf = self._buf("preview", object(), lambda: thick_lines(self._rel(P), self._rel(Q), rgba8(PREVIEW_RGB, 0.9)))
                self._draw_thick(buf, 0.8)
                buf = self._buf("preview_pts", object(), lambda: thick_lines(self._rel(M), self._rel(M), rgba8(PREVIEW_RGB)))
                self._draw_thick(buf, 2.0, cap=1.0)
            if self._vao is not None:
                self._vao.release()
            p = QtGui.QPainter(self)
            try:
                if fr is not None:
                    self.paint_labels(p, fr, sty, alpha)
                self.paint_tool_overlay(p)
                self.paint_hud(p)
            finally:
                p.end()

        # -- buffer contents -----------------------------------------------------------------------

        def _draw_grid(self):
            h = float(self.height())
            groups = {}
            for qc, x0, y0, x1, y1 in self.grid_lines():
                groups.setdefault(qc.rgba(), (qc, []))[1].append((x0, y0, x1, y1))
            for _k, (qc, segs) in groups.items():
                S = np.asarray(segs, dtype=np.float64)
                A = np.column_stack((self.u0 + S[:, 0] / self.zoom, self.v0 + (h - S[:, 1]) / self.zoom))
                B = np.column_stack((self.u0 + S[:, 2] / self.zoom, self.v0 + (h - S[:, 3]) / self.zoom))
                buf = _Buf(self._rel(np.stack((A, B), axis=1)))
                self._draw_flat(buf, GL_LINES, (qc.redF(), qc.greenF(), qc.blueF()), qc.alphaF())
                buf.destroy()

        def _td_colors(self, geo, L, thr, once):
            """A color per triangle corner: its shell's density color; a stack is filled once
            (the copies under the shell standing for it are transparent)."""
            eng = self.engine
            shell = L.face_shell[L.tri_face]
            lv = core.td_levels(eng.td[shell], *thr, steps=UV_STEPS)
            col = rgba8(core.level_rgb(lv, UV_STEPS))
            if geo.nshells and not once.all():
                hide = np.zeros(geo.sh_n, dtype=bool)
                hide[geo.gap_shell[~once]] = True
                col[hide[shell], 3] = 0
            return np.repeat(col, 3, axis=0)

        def _flipped_tris(self, geo, L, flip):
            flip_all = np.zeros(geo.sh_n, dtype=bool)
            flip_all[geo.gap_shell] = flip
            return self._rel(L.pts[L.tri[flip_all[L.face_shell[L.tri_face]]]])

        def _shell_outline(self, geo, gap_shells, rgb, a):
            m = np.isin(geo.seg_shell, gap_shells)
            if not m.any():
                return None
            return thick_lines(self._rel(geo.seg_a[m]), self._rel(geo.seg_b[m]), rgba8(rgb, a))

        def _range_shells(self):
            eng, geo, st = self.engine, self.engine.geo, self.engine.settings
            if not (st.td_range_highlight and geo.nshells and eng.td.size == geo.sh_n
                    and (st.td_sel_from > 0.0 or st.td_sel_to < 100.0)):
                return None
            key = (eng.geo_version, eng.td_key, float(st.td_sel_from), float(st.td_sel_to))
            shells, bounds = core.shells_in_range(eng.td, st.td_sel_from / 100.0, st.td_sel_to / 100.0)
            if bounds is None or not shells.size:
                return None
            gid = geo.sh_gid[shells]
            return key, gid[gid >= 0]

        def _meas_lines(self, m, lab, st, sty):
            parts = []
            if m.p_uv.size:
                parts.append(thick_lines(self._rel(m.p_uv), self._rel(m.q_uv), rgba8(lab.gap_rgb)))
            if m.bp_uv.size:
                parts.append(thick_lines(self._rel(m.bp_uv), self._rel(m.bf_uv), rgba8(lab.border_rgb)))
                h = sty["xh"]
                vert = (m.baxis == 0)[:, None]
                off = np.where(vert, np.array([[0.0, h]]), np.array([[h, 0.0]]))
                parts.append(thick_lines(self._rel(m.bf_uv), self._rel(m.bf_uv), rgba8(lab.border_rgb), -off, off))
            X = [uv for uv in (m.ov_uv, m.cross_uv, m.tile_mark_uv) if uv.size]
            if X:
                X = self._rel(thin(np.concatenate(X), 100000))
                h = sty["xh"]
                col = rgba8(st.color_overlap)
                parts.append(thick_lines(X, X, col, np.array([[-h, -h]]), np.array([[h, h]])))
                parts.append(thick_lines(X, X, col, np.array([[-h, h]]), np.array([[h, -h]])))
            return np.concatenate(parts) if parts else None

        def _meas_dots(self, m, lab):
            parts = []
            if m.p_uv.size:
                P = self._rel(m.p_uv)
                parts.append(thick_lines(P, P, rgba8(lab.gap_rgb)))
            if m.bp_uv.size:
                P = self._rel(m.bp_uv)
                parts.append(thick_lines(P, P, rgba8(lab.border_rgb)))
            return np.concatenate(parts) if parts else None
else:
    GLView = None
