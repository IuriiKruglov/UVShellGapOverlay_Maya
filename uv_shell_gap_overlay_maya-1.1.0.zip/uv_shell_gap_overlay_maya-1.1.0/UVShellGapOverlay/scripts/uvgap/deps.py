# SPDX-License-Identifier: GPL-3.0-or-later
#
# UV Shell Gap Overlay for Maya - NumPy for Maya's Python. Maya doesn't ship NumPy; this
# installs it with Maya's own pip into Maya's per-version scripts/site-packages folder (no
# administrator rights needed), as Autodesk documents for mayapy and pip.
#
# Authors: Iurii Kruglov & Claude (Anthropic)

import importlib
import os
import site
import subprocess
import sys

NUMPY_SPEC = "numpy<2"  # NumPy 1.x: builds exist for every Python Maya 2022+ ships


def numpy_version():
    try:
        import numpy
        return numpy.__version__
    except ImportError:
        return None


def site_packages_dir():
    """Maya's per-version site-packages: <user maya dir>/<version>/scripts/site-packages."""
    from maya import cmds
    return os.path.normpath(os.path.join(cmds.internalVar(userScriptDir=True), "site-packages"))


def mayapy():
    loc = os.environ.get("MAYA_LOCATION", "")
    exe = "mayapy.exe" if sys.platform.startswith("win") else "mayapy"
    path = os.path.join(loc, "bin", exe)
    return path if os.path.isfile(path) else None


def pip_command(target=None):
    py = mayapy() or "mayapy"
    return [py, "-m", "pip", "install", "--upgrade", "--target", target or site_packages_dir(), NUMPY_SPEC]


def install_numpy():
    """Run Maya's pip. Returns (ok, output)."""
    py = mayapy()
    if py is None:
        return False, "mayapy was not found next to Maya (MAYA_LOCATION=%s)" % os.environ.get("MAYA_LOCATION")
    target = site_packages_dir()
    if not os.path.isdir(target):
        os.makedirs(target)
    flags = 0x08000000 if sys.platform.startswith("win") else 0  # no console window
    out = []

    def run(args):
        p = subprocess.Popen(args, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, creationflags=flags)
        text = p.communicate()[0].decode("utf-8", "replace")
        out.append(" ".join(args) + "\n" + text)
        return p.returncode == 0, text

    ok, text = run(pip_command(target))
    if not ok and "No module named pip" in text:
        run([py, "-m", "ensurepip", "--upgrade"])
        ok, text = run(pip_command(target))
    if ok:
        if target not in sys.path:
            site.addsitedir(target)
        importlib.invalidate_caches()
        ok = numpy_version() is not None
        if not ok:
            out.append("NumPy was installed into %s but can't be imported yet: restart Maya." % target)
    return ok, "\n".join(out)


def offer_numpy():
    """Ask to install NumPy if it's missing. Returns True when NumPy can be imported."""
    if numpy_version() is not None:
        return True
    from maya import cmds
    cmd = " ".join('"%s"' % a if " " in a or "<" in a else a for a in pip_command())
    answer = cmds.confirmDialog(
        title="UV Shell Gap Overlay",
        message="UV Shell Gap Overlay needs NumPy, which Maya doesn't include.\n\n"
                "Install it now? Maya's own pip downloads it (internet needed) into\n%s\n\n"
                "Or run this yourself, then restart Maya:\n%s" % (site_packages_dir(), cmd),
        button=["Install NumPy", "Cancel"], defaultButton="Install NumPy", cancelButton="Cancel",
        dismissString="Cancel")
    if answer != "Install NumPy":
        return False
    cmds.waitCursor(state=True)
    try:
        ok, log = install_numpy()
    finally:
        cmds.waitCursor(state=False)
    print(log)
    if ok:
        cmds.confirmDialog(title="UV Shell Gap Overlay", message="NumPy %s is installed." % numpy_version(),
                           button=["OK"])
        return True
    cmds.confirmDialog(title="UV Shell Gap Overlay",
                       message="NumPy could not be installed (details in the Script Editor).\n\n"
                               "Run this in a terminal, then restart Maya:\n%s" % cmd, button=["OK"])
    return False
