# SPDX-License-Identifier: GPL-3.0-or-later
#
# UV Shell Gap Overlay for Maya - reading meshes, selections and materials from Maya
# (OpenMaya 2.0), selecting components, and editing UVs with Maya's own commands (undoable).
#
# Authors: Iurii Kruglov & Claude (Anthropic)

import re

import numpy as np
import maya.api.OpenMaya as om
from maya import cmds

from . import core

_RANGE = re.compile(r"\[(\d+)(?::(\d+))?\]$")
KINDS = {"uv": "map", "face": "f", "edge": "e", "vertex": "vtx"}


# ---------------------------------------------------------------------------
# Maya arrays -> NumPy
# ---------------------------------------------------------------------------

def _np_int(arr):
    n = len(arr)
    if not n:
        return np.zeros(0, dtype=np.int64)
    try:  # (arrays with the buffer protocol: no copy element by element)
        mv = memoryview(arr)
        if mv.itemsize == 4 and mv.nbytes == 4 * n:
            return np.frombuffer(mv, dtype=np.int32, count=n).astype(np.int64)
    except Exception:
        pass
    try:
        return np.fromiter(arr, dtype=np.int64, count=n)
    except Exception:
        return np.array(list(arr), dtype=np.int64)


def _np_float(arr):
    n = len(arr)
    if not n:
        return np.zeros(0, dtype=np.float64)
    try:
        mv = memoryview(arr)
        if mv.itemsize == 4 and mv.nbytes == 4 * n:
            return np.frombuffer(mv, dtype=np.float32, count=n).astype(np.float64)
    except Exception:
        pass
    try:
        return np.fromiter(arr, dtype=np.float64, count=n)
    except Exception:
        return np.array(list(arr), dtype=np.float64)


def _np_points(pts):
    """(n, 3) from an MPointArray."""
    n = len(pts)
    if not n:
        return np.zeros((0, 3))
    try:
        a = np.array(pts, dtype=np.float64)
        if a.shape == (n, 4) or a.shape == (n, 3):
            return a[:, :3].copy()
    except Exception:
        pass
    return np.array([(p.x, p.y, p.z) for p in pts], dtype=np.float64).reshape(n, 3)


_RAW = {"ok": None}  # whether the fast point reading works here (None: not tried yet)
RAW_POINTS_MIN = 4096  # (smaller meshes: the check costs more than it saves)


def _raw_points(path, fn2):
    """The mesh's points straight from Maya's float array (API 1.0 MFnMesh.getRawPoints),
    checked against a few points read the usual way; None when that isn't possible here."""
    if _RAW["ok"] is False:
        return None
    try:
        import ctypes
        import maya.OpenMaya as om1
        n = int(fn2.numVertices)
        if n == 0:
            return np.zeros((0, 3))
        sl = om1.MSelectionList()
        sl.add(path)
        dag = om1.MDagPath()
        sl.getDagPath(0, dag)
        fn1 = om1.MFnMesh(dag)
        addr = int(fn1.getRawPoints())
        if not addr:
            raise ValueError("no points")
        buf = (ctypes.c_float * (3 * n)).from_address(addr)
        P = np.frombuffer(buf, dtype=np.float32, count=3 * n).reshape(n, 3).astype(np.float64)
        for i in sorted({0, n // 2, n - 1, n // 3, (2 * n) // 3}):
            q = fn2.getPoint(i, om.MSpace.kObject)
            if np.abs(P[i] - np.array((q.x, q.y, q.z))).max() > 1e-4 * max(1.0, float(np.abs(P[i]).max())):
                raise ValueError("points differ")
        _RAW["ok"] = True
        return P
    except Exception:
        _RAW["ok"] = False
        return None


def _np_matrix(m):
    """MMatrix (row vectors, translation in the last row) -> 4x4 for column vectors."""
    return np.array([[m.getElement(r, c) for c in range(4)] for r in range(4)], dtype=np.float64).T


# ---------------------------------------------------------------------------
# Scene queries
# ---------------------------------------------------------------------------

def dag_path(name):
    sl = om.MSelectionList()
    sl.add(name)
    return sl.getDagPath(0)


def up_axis():
    try:
        return str(cmds.upAxis(q=True, axis=True)).lower()
    except Exception:
        return "y"


def _mesh_shapes(node):
    """Mesh shapes of a DAG node: itself, or the meshes under a transform (also in groups)."""
    try:
        if cmds.objectType(node, isAType="mesh"):
            return [] if cmds.getAttr(node + ".intermediateObject") else cmds.ls(node, long=True) or []
        return cmds.listRelatives(node, allDescendents=True, type="mesh", fullPath=True,
                                  noIntermediate=True) or []
    except Exception:
        return []


def _corner_next(A):
    """Next corner of each corner's face (MeshArrays)."""
    n = A.loop_vert.size
    nxt = np.arange(1, n + 1, dtype=np.int64)
    if A.f_total.size:
        nxt[A.f_start + A.f_total - 1] = A.f_start
    return nxt


def _mask(n, ids):
    m = np.zeros(max(int(n), 1), dtype=bool)
    ids = np.asarray(ids, dtype=np.int64).reshape(-1)
    m[ids[(ids >= 0) & (ids < m.size)]] = True
    return m


class Selection(object):
    """What is selected in Maya, per mesh shape. comps: {shape path: {kind: ids}} with kinds
    'uv', 'face', 'edge', 'vertex', 'vtxface' ((n, 2) vertex, face); edge_verts: {shape path:
    (n, 2) mesh vertices of the selected edges}; objects: shapes selected as whole objects;
    hilited: shapes in component mode."""
    __slots__ = ("comps", "edge_verts", "objects", "hilited")

    def __init__(self):
        self.comps, self.edge_verts, self.objects, self.hilited = {}, {}, set(), set()

    def has_components(self):
        return any(len(ids) for d in self.comps.values() for ids in d.values())

    def kinds(self):
        return {k for d in self.comps.values() for k, ids in d.items() if len(ids)}

    def corners(self, path, A):
        """Corners (MeshArrays order) of the selected components of a mesh: their UVs are
        the selected UVs (as Maya converts faces, edges and vertices to UVs)."""
        d = self.comps.get(path, {})
        hit = np.zeros(A.loop_vert.size, dtype=bool)
        if len(d.get("uv", ())):
            m = _mask(A.uv_table.shape[0], d["uv"])
            hit |= (A.uv_id >= 0) & m[np.maximum(A.uv_id, 0)]
        if len(d.get("face", ())):
            hit |= np.repeat(_mask(A.f_total.size, d["face"])[:A.f_total.size], A.f_total)
        if len(d.get("vertex", ())):
            hit |= _mask(A.co.shape[0], d["vertex"])[A.loop_vert]
        ev = self.edge_verts.get(path)
        if ev is not None and len(ev):
            nxt = _corner_next(A)
            nv = int(max(A.co.shape[0], int(np.max(ev)) + 1))
            a, b = A.loop_vert, A.loop_vert[nxt]
            ck = np.minimum(a, b) * nv + np.maximum(a, b)
            ek = np.minimum(ev[:, 0], ev[:, 1]) * nv + np.maximum(ev[:, 0], ev[:, 1])
            on = np.isin(ck, ek)
            hit[on] = True
            hit[nxt[on]] = True
        vf = d.get("vtxface")
        if vf is not None and len(vf):
            vf = np.asarray(vf, dtype=np.int64).reshape(-1, 2)
            face = np.repeat(np.arange(A.f_total.size, dtype=np.int64), A.f_total)
            nv = int(max(A.co.shape[0], int(vf[:, 0].max()) + 1))
            hit |= np.isin(face * nv + A.loop_vert, vf[:, 1] * nv + vf[:, 0])
        return hit

    def uv_ids(self, arrays):
        """{shape path: selected UV ids, or None when the mesh is selected as a whole object}
        for the meshes in `arrays` ({path: (generations, MeshArrays)})."""
        out = {}
        for path, (_g, A) in arrays.items():
            if path in self.comps:
                hit = self.corners(path, A)
                ids = A.uv_id[hit]
                out[path] = np.unique(ids[ids >= 0])
            elif path in self.objects:
                out[path] = None
            else:
                out[path] = np.zeros(0, dtype=np.int64)
        return out


class Shown(object):
    """Meshes the UV view shows, in selection order: the selected meshes (also under selected
    groups), meshes with selected components and meshes in component mode."""
    __slots__ = ("paths", "names", "selection")

    def __init__(self):
        self.paths, self.names, self.selection = [], {}, Selection()


def _component_items():
    """[(shape path, kind, ids)] of the selected mesh components, through the API."""
    out = []
    sl = om.MGlobal.getActiveSelectionList()
    for i in range(sl.length()):
        try:
            dag, comp = sl.getComponent(i)
        except Exception:
            continue
        if comp is None or comp.isNull():
            continue
        try:
            if not dag.hasFn(om.MFn.kMesh):
                dag = om.MDagPath(dag)
                dag.extendToShape()
            if not dag.hasFn(om.MFn.kMesh):
                continue
        except Exception:
            continue
        t = comp.apiType()
        kind = {om.MFn.kMeshMapComponent: "uv", om.MFn.kMeshPolygonComponent: "face",
                om.MFn.kMeshEdgeComponent: "edge", om.MFn.kMeshVertComponent: "vertex"}.get(t)
        try:
            if kind is not None:
                ids = _np_int(om.MFnSingleIndexedComponent(comp).getElements())
            elif t == om.MFn.kMeshVtxFaceComponent:
                kind = "vtxface"
                ids = np.asarray([tuple(e) for e in om.MFnDoubleIndexedComponent(comp).getElements()],
                                 dtype=np.int64).reshape(-1, 2)
            else:
                continue
        except Exception:
            continue
        out.append((dag.fullPathName(), kind, ids, dag))
    return out


def edge_vertices(path, edges, dag=None):
    """(n, 2) mesh vertices of edges."""
    edges = np.asarray(edges, dtype=np.int64).reshape(-1)
    if not edges.size:
        return np.zeros((0, 2), dtype=np.int64)
    fn = om.MFnMesh(dag if dag is not None else dag_path(path))
    get = fn.getEdgeVertices
    return np.array([tuple(get(int(e))) for e in edges.tolist()], dtype=np.int64).reshape(-1, 2)


def _meshes_below(nodes=None):
    """Mesh shapes at or below the nodes (the selection when None), in one call."""
    try:
        if nodes is None:
            return cmds.ls(sl=True, long=True, dag=True, type="mesh", noIntermediate=True) or []
        if not nodes:  # (ls without names would list every mesh of the scene)
            return []
        return cmds.ls(nodes, long=True, dag=True, type="mesh", noIntermediate=True) or []
    except Exception:
        return []


def shown_meshes():
    sh = Shown()
    sel = sh.selection
    seen = set()

    def add(path):
        if path and path not in seen:
            seen.add(path)
            sh.paths.append(path)

    comps = _component_items()
    with_comps = {path for path, _k, _i, _d in comps}
    for shape in _meshes_below():
        add(shape)
        if shape not in with_comps:
            sel.objects.add(shape)
    for path, kind, ids, dag in comps:
        d = sel.comps.setdefault(path, {})
        if kind == "vtxface":
            d[kind] = np.concatenate((d[kind], ids)) if kind in d else ids
        else:
            d[kind] = np.union1d(d[kind], ids) if kind in d else ids
        if kind == "edge":
            try:
                sel.edge_verts[path] = edge_vertices(path, d["edge"], dag)
            except Exception:
                pass
        add(path)
    try:
        hilited = cmds.ls(hilite=True, long=True) or []
    except Exception:
        hilited = []
    for shape in (_meshes_below(hilited) if hilited else []):
        sel.hilited.add(shape)
        if shape not in seen:  # in component mode with none of its components selected
            sel.comps.setdefault(shape, {})
        add(shape)
    for p in sel.comps:
        sel.objects.discard(p)  # (components selected, or component mode: it counts by its components)
    # always in the same order, whatever was selected first: results are kept per object and
    # per group of objects, and of shells lying on each other the first one stays
    sh.paths.sort(key=natural_key)
    sh.names = display_names(sh.paths)
    return sh


_NUMBER = re.compile(r"(\d+)")
_KEYS = {}


def natural_key(path):
    """Sort key of a DAG path: names level by level, numbers by value (part2 before part10,
    part before part1)."""
    k = _KEYS.get(path)
    if k is None:
        if len(_KEYS) > 200000:
            _KEYS.clear()
        k = _KEYS[path] = tuple(
            tuple((1, int(t), "") if t.isdigit() else (0, 0, t.lower()) for t in _NUMBER.split(part) if t)
            + ((-1, 0, part),) for part in path.split("|"))
    return k


def display_names(paths):
    """{shape path: the transform's short name}; the shape's name too where a transform has
    several of the meshes."""
    parents = {}
    for p in paths:
        parents.setdefault(p.rsplit("|", 1)[0], []).append(p)
    out = {}
    for parent, shapes in parents.items():
        short = parent.rsplit("|", 1)[-1]
        for p in shapes:
            out[p] = short if len(shapes) == 1 and short else (short + "|" if short else "") + p.rsplit("|", 1)[-1]
    return out


def display_name(shape_path):
    """The transform's short name (the shape's when it has several meshes)."""
    parts = shape_path.split("|")
    if len(parts) >= 2 and parts[-2]:
        try:
            siblings = cmds.listRelatives("|".join(parts[:-1]), shapes=True, type="mesh", noIntermediate=True) or []
        except Exception:
            siblings = []
        if len(siblings) <= 1:
            return parts[-2]
        return parts[-2] + "|" + parts[-1]
    return parts[-1]


def material_name(sg):
    """Name of the material connected to a shading group, else the shading group's."""
    fn = om.MFnDependencyNode(sg)
    try:
        src = fn.findPlug("surfaceShader", False).source()
        if not src.isNull:
            return om.MFnDependencyNode(src.node()).name()
    except Exception:
        pass
    return fn.name()


def transform_scale(shape_path):
    """Local scale of the mesh's transform."""
    try:
        got = cmds.getAttr(shape_path.rsplit("|", 1)[0] + ".scale")
        return tuple(float(c) for c in (got[0] if got and isinstance(got[0], (list, tuple)) else got))
    except Exception:
        return (1.0, 1.0, 1.0)


def read_matrix(path):
    """(4x4 object -> world for column vectors, local scale) of a mesh shape."""
    dag = dag_path(path)
    return _np_matrix(dag.inclusiveMatrix()), transform_scale(dag.fullPathName())


def copy_with_matrix(A, path):
    """A copy of MeshArrays A with the mesh's current matrix and scale (moved, not edited)."""
    B = A.copy()
    B.matrix, B.scale = read_matrix(path)
    return B


def read_mesh(path, name=None):
    """core.MeshArrays of a mesh shape: its current UV set, points, world matrix, materials."""
    dag = dag_path(path)
    fn = om.MFnMesh(dag)
    counts, verts = fn.getVertices()
    counts, verts = _np_int(counts), _np_int(verts)
    uv_set = fn.currentUVSetName()
    if uv_set and fn.numUVs(uv_set) > 0:
        uv_counts, uv_ids = fn.getAssignedUVs(uv_set)
        us, vs = fn.getUVs(uv_set)
        uv_counts, uv_ids, us, vs = _np_int(uv_counts), _np_int(uv_ids), _np_float(us), _np_float(vs)
    else:
        uv_counts, uv_ids = np.zeros(counts.size, dtype=np.int64), np.zeros(0, dtype=np.int64)
        us = vs = np.zeros(0)
    pts = _raw_points(dag.fullPathName(), fn) if fn.numVertices >= RAW_POINTS_MIN else None
    if pts is None:
        pts = _np_points(fn.getPoints(om.MSpace.kObject))
    try:
        sgs, face_sg = fn.getConnectedShaders(dag.instanceNumber())
        keys = [material_name(sgs[i]) for i in range(len(sgs))]
        f_mat = _np_int(face_sg)
        if f_mat.size != counts.size:
            f_mat = None
    except Exception:
        keys, f_mat = [], None
    A = core.MeshArrays.build(name or display_name(path), counts, uv_counts, uv_ids, us, vs, verts, pts,
                              _np_matrix(dag.inclusiveMatrix()), f_mat, keys,
                              scale=transform_scale(dag.fullPathName()), key=path)
    A.select(None)
    return A


def mesh_triangles(path):
    """(triangle count per face, vertex ids of the triangles (n, 3))."""
    fn = om.MFnMesh(dag_path(path))
    tc, tv = fn.getTriangles()
    return _np_int(tc), _np_int(tv).reshape(-1, 3)


def uv_set_name(path):
    try:
        return om.MFnMesh(dag_path(path)).currentUVSetName()
    except Exception:
        return ""


def edge_of_corner(path, face, v0, v1):
    """The mesh edge of a face that joins vertices v0 and v1, or -1."""
    try:
        it = om.MItMeshPolygon(dag_path(path))
        it.setIndex(int(face))
        edges = [int(e) for e in it.getEdges()]
        fn = om.MFnMesh(dag_path(path))
    except Exception:
        return -1
    want = {int(v0), int(v1)}
    for e in edges:
        if set(fn.getEdgeVertices(e)) == want:
            return e
    return -1


def edges_of_corners(path, faces, v0, v1):
    """Mesh edges for (face, vertex, next vertex) triples; -1 where none matches."""
    out = np.full(len(faces), -1, dtype=np.int64)
    try:
        dag = dag_path(path)
        it = om.MItMeshPolygon(dag)
        fn = om.MFnMesh(dag)
    except Exception:
        return out
    cache = {}
    for k, (f, a, b) in enumerate(zip(np.asarray(faces).tolist(), np.asarray(v0).tolist(), np.asarray(v1).tolist())):
        if f not in cache:
            try:
                it.setIndex(int(f))
                cache[f] = [(int(e), set(fn.getEdgeVertices(int(e)))) for e in it.getEdges()]
            except Exception:
                cache[f] = []
        want = {a, b}
        for e, vs in cache[f]:
            if vs == want:
                out[k] = e
                break
    return out


# ---------------------------------------------------------------------------
# Texture size of the UV Editor's image
# ---------------------------------------------------------------------------

def uv_editor_image_size():
    """(width, height, panel) of the image shown in a UV Editor, or None."""
    try:
        panels = cmds.getPanel(scriptType="polyTexturePlacementPanel") or []
        visible = set(cmds.getPanel(visiblePanels=True) or [])
    except Exception:
        return None
    for p in sorted(panels, key=lambda p: p not in visible):
        try:
            size = cmds.textureWindow(p, q=True, imageSize=True)
        except Exception:
            continue
        if size and len(size) >= 2 and size[0] > 0 and size[1] > 0:
            return int(size[0]), int(size[1]), p
    return None


# ---------------------------------------------------------------------------
# Selecting components
# ---------------------------------------------------------------------------

def _runs(ids):
    """Sorted unique ids as (first, last) runs of consecutive ids."""
    ids = np.unique(np.asarray(ids, dtype=np.int64))
    if not ids.size:
        return []
    cut = np.flatnonzero(np.diff(ids) != 1) + 1
    starts = np.concatenate(([0], cut))
    ends = np.concatenate((cut - 1, [ids.size - 1]))
    return list(zip(ids[starts].tolist(), ids[ends].tolist()))


def component_strings(path, ids, kind):
    comp = KINDS.get(kind, kind)
    return ["%s.%s[%d:%d]" % (path, comp, a, b) if a != b else "%s.%s[%d]" % (path, comp, a)
            for a, b in _runs(ids)]


def face_mode():
    """True when faces (not UVs) are what is being selected. In object selection mode Maya
    picks components with the object-mode component masks (selectType -objectComponent), as
    after right-click > Face or with objects in component mode (hilited)."""
    try:
        kw = {"objectComponent": True} if cmds.selectMode(q=True, object=True) else {}
        face = cmds.selectType(q=True, facet=True, **kw) or cmds.selectType(q=True, polymeshFace=True, **kw)
        return bool(face) and not bool(cmds.selectType(q=True, polymeshUV=True, **kw))
    except Exception:
        return False


def select_components(per_object, kind="uv", mode="replace"):
    """Select components: per_object [(shape path, ids)]; kind 'uv', 'face', 'edge' or
    'vertex'; mode 'replace', 'add', 'toggle' or 'deselect'. Returns how many component ranges."""
    items = []
    for path, ids in per_object:
        items.extend(component_strings(path, ids, kind))
    if mode == "replace":
        if items:
            cmds.select(items, replace=True)
        else:
            cmds.select(clear=True)
    elif items:
        if mode == "add":
            cmds.select(items, add=True)
        elif mode == "toggle":
            cmds.select(items, toggle=True)
        else:
            cmds.select(items, deselect=True)
    return len(items)


# ---------------------------------------------------------------------------
# Editing UVs (Maya's commands: undoable, with construction history as Maya does it)
# ---------------------------------------------------------------------------

class Chunk(object):
    """One undo step."""

    def __init__(self, name):
        self.name = name

    def __enter__(self):
        cmds.undoInfo(openChunk=True, chunkName="UV Gap Overlay: " + self.name)

    def __exit__(self, *exc):
        cmds.undoInfo(closeChunk=True)
        return False


def _uv_strings(per_object):
    items = []
    for path, ids in per_object:
        items.extend(component_strings(path, ids, "uv"))
    return items


def move_uvs(per_object, du, dv):
    """Move UVs by (du, dv): per_object [(shape path, UV ids)]."""
    items = _uv_strings(per_object)
    if items and (du or dv):
        with Chunk("move UVs"):
            cmds.polyEditUV(items, relative=True, uValue=float(du), vValue=float(dv))
    return len(items)


# Maya's documentation doesn't say which way polyEditUV's angle turns. The first rotation that
# can tell (not a half turn, a UV away from the pivot) looks where a UV went; had Maya turned
# the other way, it is turned back and on, and from then on the angle is passed with the other
# sign. +1: counterclockwise, -1: clockwise, None: not known yet.
_ROTATION = {"sign": None}


def _uv_at(path, uv_id):
    fn = om.MFnMesh(dag_path(path))
    u, v = fn.getUV(int(uv_id), fn.currentUVSetName())
    return float(u), float(v)


def _rotation_probe(per_object, pu, pv, angle):
    """(path, UV id, (u, v) now) of a UV far enough from the pivot to show which way a rotation
    by `angle` went, or None."""
    if abs(np.sin(np.radians(float(angle)))) < 1e-3:
        return None  # (a half turn looks the same either way)
    best = None
    for path, ids in per_object:
        for i in np.asarray(ids, dtype=np.int64).reshape(-1)[:8].tolist():
            try:
                u, v = _uv_at(path, i)
            except Exception:
                return None
            d = (u - pu) ** 2 + (v - pv) ** 2
            if best is None or d > best[0]:
                best = (d, path, i, (u, v))
        if best is not None and best[0] > 1e-8:
            break
    return best[1:] if best is not None and best[0] > 1e-8 else None


def _rotation_seen(probe, pu, pv, angle):
    """+1 when the probed UV went counterclockwise by `angle`, -1 when clockwise, None when
    neither."""
    path, i, (u0, v0) = probe
    try:
        u, v = _uv_at(path, i)
    except Exception:
        return None
    a = np.radians(float(angle))
    dx, dy = u0 - pu, v0 - pv
    r = max(float(np.hypot(dx, dy)), 1e-12)
    ccw = (pu + dx * np.cos(a) - dy * np.sin(a), pv + dx * np.sin(a) + dy * np.cos(a))
    cw = (pu + dx * np.cos(a) + dy * np.sin(a), pv - dx * np.sin(a) + dy * np.cos(a))
    e_ccw, e_cw = np.hypot(u - ccw[0], v - ccw[1]) / r, np.hypot(u - cw[0], v - cw[1]) / r
    if min(e_ccw, e_cw) > 1e-3 or abs(e_ccw - e_cw) < 1e-3:
        return None
    return 1.0 if e_ccw < e_cw else -1.0


def rotate_uvs(groups, angle):
    """Rotate UVs by `angle` degrees (counterclockwise) around pivots: groups [(per_object,
    (pu, pv))], one polyEditUV per group."""
    n = 0
    with Chunk("rotate UVs"):
        for per_object, (pu, pv) in groups:
            items = _uv_strings(per_object)
            if not items or not angle:
                continue
            pu, pv = float(pu), float(pv)
            sign = _ROTATION["sign"]
            probe = _rotation_probe(per_object, pu, pv, angle) if sign is None else None
            cmds.polyEditUV(items, pivotU=pu, pivotV=pv, angle=float(angle) * (sign or 1.0))
            if probe is not None:
                seen = _rotation_seen(probe, pu, pv, angle)
                if seen is not None:
                    _ROTATION["sign"] = seen
                    if seen < 0.0:  # Maya turned clockwise: back, and on to where it was asked to go
                        cmds.polyEditUV(items, pivotU=pu, pivotV=pv, angle=-2.0 * float(angle))
            n += 1
    return n


def scale_uvs(groups, su, sv):
    """Scale UVs by (su, sv) around pivots: groups [(per_object, (pu, pv))]."""
    n = 0
    with Chunk("scale UVs"):
        for per_object, (pu, pv) in groups:
            items = _uv_strings(per_object)
            if items:
                cmds.polyEditUV(items, pivotU=float(pu), pivotV=float(pv), scaleU=float(su), scaleV=float(sv))
                n += 1
    return n


def selection_strings():
    return cmds.ls(sl=True, long=True) or []


def edges_to_cut(items):
    """Edges for a cut from selection strings: edges as they are, the border of selected faces,
    the edges between selected UVs or vertices."""
    edges, faces, inner = [], [], []
    for s in items:
        comp = s.rsplit(".", 1)[-1] if "." in s.rsplit("|", 1)[-1] else ""
        if comp.startswith("e["):
            edges.append(s)
        elif comp.startswith("f["):
            faces.append(s)
        elif comp.startswith(("map[", "vtx[")):
            inner.append(s)
    out = list(edges)
    if faces:
        out += cmds.polyListComponentConversion(faces, fromFace=True, toEdge=True, border=True) or []
    if inner:
        out += cmds.polyListComponentConversion(inner, toEdge=True, internal=True) or []
    return out


def cut_edges(edges):
    if edges:
        with Chunk("cut UVs"):
            cmds.polyMapCut(edges)
    return len(edges)


def sew_edges(edges):
    if edges:
        with Chunk("sew UVs"):
            cmds.polyMapSew(edges)
    return len(edges)


def merge_uvs(per_object, distance):
    """Merge UVs of the same vertex within `distance` (UV units): Maya's Merge UVs."""
    items = _uv_strings(per_object)
    if items:
        with Chunk("merge UVs"):
            cmds.polyMergeUV(items, distance=float(distance))
    return len(items)
