# SPDX-License-Identifier: GPL-3.0-or-later
#
# UV Shell Gap Overlay for Maya - Qt binding (PySide2 in Maya 2022-2024, PySide6 in 2025+)
# and fast QPainterPath building from NumPy arrays.
#
# Authors: Iurii Kruglov & Claude (Anthropic)

import numpy as np


def _maya_qt_major():
    try:
        from maya import cmds
        return int(str(cmds.about(qtVersion=True)).split(".")[0])
    except Exception:
        return None


_major = _maya_qt_major()
if _major == 5:
    from PySide2 import QtCore, QtGui, QtWidgets
    from shiboken2 import wrapInstance, isValid
elif _major == 6:
    from PySide6 import QtCore, QtGui, QtWidgets
    from shiboken6 import wrapInstance, isValid
else:  # outside Maya
    try:
        from PySide6 import QtCore, QtGui, QtWidgets
        from shiboken6 import wrapInstance, isValid
    except ImportError:
        from PySide2 import QtCore, QtGui, QtWidgets
        from shiboken2 import wrapInstance, isValid

QT6 = QtCore.qVersion().startswith("6")
Qt = QtCore.Qt
Signal = QtCore.Signal
QAction = getattr(QtWidgets, "QAction", None) or QtGui.QAction

__all__ = ["QtCore", "QtGui", "QtWidgets", "Qt", "Signal", "QAction", "QT6", "wrapInstance", "isValid",
           "event_pos", "maya_main_window", "path_from_points", "segments_path", "polygons_path", "color"]


def gl_classes():
    """(QOpenGLWidget, QOpenGLShaderProgram, QOpenGLShader, QOpenGLBuffer,
    QOpenGLVertexArrayObject) of the binding in use, or None when OpenGL isn't available."""
    try:
        if QT6:
            from importlib import import_module
            pkg = QtCore.__name__.split(".")[0]
            qgl = import_module(pkg + ".QtOpenGL")
            qglw = import_module(pkg + ".QtOpenGLWidgets")
            return (qglw.QOpenGLWidget, qgl.QOpenGLShaderProgram, qgl.QOpenGLShader, qgl.QOpenGLBuffer,
                    qgl.QOpenGLVertexArrayObject)
        return (QtWidgets.QOpenGLWidget, QtGui.QOpenGLShaderProgram, QtGui.QOpenGLShader, QtGui.QOpenGLBuffer,
                QtGui.QOpenGLVertexArrayObject)
    except Exception:
        return None


def event_pos(event):
    """Mouse / wheel position as QPointF, with its fraction of a pixel (Qt 5 and 6)."""
    for name in ("position", "localPos", "posF"):  # Qt 6; Qt 5 mouse events; Qt 5 wheel events
        f = getattr(event, name, None)
        if f is not None:
            return QtCore.QPointF(f())
    return QtCore.QPointF(event.pos())


def maya_main_window():
    try:
        from maya import OpenMayaUI as omui1
        ptr = omui1.MQtUtil.mainWindow()
        if ptr is not None:
            return wrapInstance(int(ptr), QtWidgets.QWidget)
    except Exception:
        pass
    return None


def color(rgb, alpha=1.0):
    r, g, b = (max(0.0, min(1.0, float(c))) for c in rgb[:3])
    return QtGui.QColor.fromRgbF(r, g, b, max(0.0, min(1.0, float(alpha))))


# ---------------------------------------------------------------------------
# QPainterPath from NumPy arrays
# ---------------------------------------------------------------------------
#
# A QPainterPath streams as: int32 element count, per element (int32 type, float64 x,
# float64 y), int32 index of the current subpath start, int32 fill rule - big-endian.
# Reading that stream builds a path of any size in C++; element by element from Python is
# about ten times slower. The first use checks the result and falls back if it differs.

_STREAM_OK = None
_WINDING = 1


def _stream_path(xy, types, fill_rule):
    n = int(xy.shape[0])
    rec = np.empty(n, dtype=[("t", ">i4"), ("x", ">f8"), ("y", ">f8")])
    rec["t"] = types
    rec["x"] = xy[:, 0]
    rec["y"] = xy[:, 1]
    data = QtCore.QByteArray(np.array([n], dtype=">i4").tobytes() + rec.tobytes() +
                             np.array([0, fill_rule], dtype=">i4").tobytes())
    # the stream reads `data` in place: it must stay alive until the path is read
    stream = QtCore.QDataStream(data, QtCore.QIODevice.OpenModeFlag.ReadOnly)
    path = QtGui.QPainterPath()
    stream >> path
    del stream
    return path


def _loop_path(xy, types, fill_rule):
    path = QtGui.QPainterPath()
    move, line = path.moveTo, path.lineTo
    for (x, y), t in zip(xy.tolist(), types.tolist()):
        if t == 0:
            move(x, y)
        else:
            line(x, y)
    path.setFillRule(Qt.FillRule.WindingFill if fill_rule == _WINDING else Qt.FillRule.OddEvenFill)
    return path


def _stream_works():
    global _STREAM_OK
    if _STREAM_OK is None:
        try:
            xy = np.array([[1.5, -2.0], [3.25, 4.0], [7.0, 8.5]])
            p = _stream_path(xy, np.array([0, 1, 1], dtype=np.int32), _WINDING)
            ok = p.elementCount() == 3
            if ok:  # (elementAt past the end would crash)
                for i in range(3):
                    e = p.elementAt(i)
                    ok = ok and abs(e.x - xy[i, 0]) < 1e-12 and abs(e.y - xy[i, 1]) < 1e-12
                ok = ok and p.elementAt(0).isMoveTo() and p.elementAt(2).isLineTo()
                ok = ok and p.fillRule() == Qt.FillRule.WindingFill
            _STREAM_OK = bool(ok)
        except Exception:
            _STREAM_OK = False
    return _STREAM_OK


def path_from_points(xy, types, winding=True):
    """QPainterPath from (n, 2) points and element types (0: move to, 1: line to)."""
    xy = np.ascontiguousarray(xy, dtype=np.float64).reshape(-1, 2)
    types = np.asarray(types, dtype=np.int32).reshape(-1)
    if not xy.shape[0]:
        return QtGui.QPainterPath()
    keep = np.isfinite(xy).all(axis=1)  # Qt drops paths with invalid coordinates
    if not keep.all():
        types = types.copy()
        nxt = np.flatnonzero(~keep) + 1
        types[nxt[nxt < types.size]] = 0  # restart after a dropped point
        xy, types = xy[keep], types[keep]
        if not xy.shape[0]:
            return QtGui.QPainterPath()
        types[0] = 0
    rule = _WINDING if winding else 0
    if _stream_works():
        return _stream_path(xy, types, rule)
    return _loop_path(xy, types, rule)


def segments_path(P, Q):
    """One line per pair of points."""
    n = P.shape[0]
    xy = np.empty((2 * n, 2))
    xy[0::2] = P
    xy[1::2] = Q
    return path_from_points(xy, np.tile(np.array([0, 1], dtype=np.int32), n))


def polygons_path(xy, counts, winding=True):
    """Closed polygons (filled; outlines are open unless the last point repeats the first)."""
    counts = np.asarray(counts, dtype=np.int64)
    types = np.ones(int(counts.sum()), dtype=np.int32)
    if counts.size:
        starts = np.cumsum(counts) - counts
        types[starts[counts > 0]] = 0
    return path_from_points(xy, types, winding)
