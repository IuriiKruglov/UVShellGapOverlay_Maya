# SPDX-License-Identifier: GPL-3.0-or-later
#
# UV Shell Gap Overlay for Maya - texel density in the 3D viewport: the triangles of the shown
# meshes grouped by color, drawn by the uvGapOverlay plug-in's locator (Viewport 2.0). The
# locator is created on demand and never saved with the scene.
#
# Authors: Iurii Kruglov & Claude (Anthropic)

import os
import time
import traceback

import numpy as np
import maya.api.OpenMaya as om
from maya import cmds

from . import core, mayadata

PLUGIN = "uvGapOverlay"
NODE_TYPE = "uvGapOverlay"
NODE_NAME = "uvGapOverlay_TD"


class _State(object):
    items = []          # [(MPointArray, [(MColor, MUintArray), ...])] for the draw override
    key = None
    tris = {}           # mesh path -> (the engine's MeshArrays it was read for, triangles per face,
                        #               triangle vertex ids): read again whenever the engine reads the mesh again
    enabled = False
    draws = 0           # addUIDrawables calls (for the self-test)
    build_ms = 0.0


def draw_items():
    return _State.items if _State.enabled else ()


def note_draw():
    _State.draws += 1


def plugin_file():
    here = os.path.dirname(os.path.abspath(__file__))
    return os.path.join(os.path.dirname(os.path.dirname(here)), "plug-ins", PLUGIN + ".py")


def plugin_loaded():
    for name in (PLUGIN, PLUGIN + ".py"):
        try:
            if cmds.pluginInfo(name, q=True, loaded=True):
                return True
        except Exception:
            pass
    return False


def ensure_plugin():
    if plugin_loaded():
        return
    try:
        cmds.loadPlugin(PLUGIN + ".py", quiet=True)
    except Exception:
        path = plugin_file()
        if not os.path.isfile(path):
            raise RuntimeError("the uvGapOverlay plug-in was not found (expected %s)" % path)
        cmds.loadPlugin(path, quiet=True)


class _NoUndo(object):
    """The locator comes and goes outside the undo queue (undo would delete or restore it)."""

    def __enter__(self):
        self.state = cmds.undoInfo(q=True, stateWithoutFlush=True)
        if self.state:
            cmds.undoInfo(stateWithoutFlush=False)

    def __exit__(self, *exc):
        if self.state:
            cmds.undoInfo(stateWithoutFlush=True)
        return False


def _mobject(name):
    sl = om.MSelectionList()
    sl.add(name)
    return sl.getDependNode(0)


def find_node():
    try:
        nodes = cmds.ls(type=NODE_TYPE, long=True) or []
    except Exception:
        return None
    return nodes[0] if nodes else None


def ensure_node():
    node = find_node()
    if node is not None:
        return node
    with _NoUndo():
        sel = cmds.ls(sl=True, long=True) or []
        tr = cmds.createNode("transform", name=NODE_NAME, skipSelect=True)
        shape = cmds.createNode(NODE_TYPE, name=NODE_NAME + "Shape", parent=tr, skipSelect=True)
        for n in (tr, shape):
            om.MFnDependencyNode(_mobject(n)).setDoNotWrite(True)  # never saved with the scene
        for attr, value in ((".hiddenInOutliner", True), (".overrideEnabled", True), (".overrideDisplayType", 2)):
            try:
                cmds.setAttr(tr + attr, value)
            except Exception:
                pass
        if sel:  # createNode may change the selection in some versions
            cmds.select(sel, replace=True)
    return cmds.ls(shape, long=True)[0]


def remove_node():
    nodes = []
    try:
        for n in cmds.ls(type=NODE_TYPE, long=True) or []:
            nodes.extend(cmds.listRelatives(n, parent=True, fullPath=True) or [n])
    except Exception:
        return
    if nodes:
        with _NoUndo():
            try:
                cmds.delete(nodes)
            except Exception:
                pass


def mark_dirty():
    node = find_node()
    if node is None:
        return
    try:
        import maya.api.OpenMayaRender as omr
        omr.MRenderer.setGeometryDrawDirty(_mobject(node), True)
    except Exception:
        pass
    try:
        import maya.api.OpenMayaUI as omui
        omui.M3dView.scheduleRefreshAllViews()
    except Exception:
        try:
            cmds.refresh()
        except Exception:
            pass


def enable(on):
    """Show or remove the 3D viewport colors."""
    if on:
        ensure_plugin()
        ensure_node()
        _State.enabled = True
    else:
        _State.enabled = False
        _State.items = []
        _State.key = None
        _State.tris.clear()
        if plugin_loaded():
            remove_node()


def _triangles(path, arrays):
    """Triangles of a mesh, cached for as long as the engine keeps the same arrays of it (a new
    scene, an edit or the mesh being shown again all give new arrays)."""
    hit = _State.tris.get(path)
    if hit is not None and arrays is not None and hit[0] is arrays:
        return hit[1], hit[2]
    tc, tv = mayadata.mesh_triangles(path)
    _State.tris[path] = (arrays, tc, tv)
    return tc, tv


def build_items(geo, td, thr, alpha, arrays):
    """Draw items for the shown meshes: per mesh its world-space points and, per color step,
    the triangles of the faces in that step. `arrays`: the engine's {path: (generation,
    MeshArrays)}."""
    items = []
    lv_rgb = {}
    for path in [p for p in list(_State.tris) if p not in arrays]:
        del _State.tris[path]
    for oi, path in enumerate(geo.obj_keys):
        try:
            dag = mayadata.dag_path(path)
            fn = om.MFnMesh(dag)
            nf, nv = fn.numPolygons, fn.numVertices
            if geo.obj_fidx[oi].size and int(geo.obj_fidx[oi].max()) >= nf:
                continue  # the mesh changed since it was read: the next update has it
            levels = core.object_face_levels(geo, td, thr, oi, nf)
            tc, tv = _triangles(path, (arrays.get(path) or (None, None))[1])
            if tc.size != nf or (tv.size and (tv.min() < 0 or tv.max() >= nv)):
                _State.tris.pop(path, None)  # changed under us: read again next time
                continue
            off = np.cumsum(tc) - tc
            groups = []
            for lv in np.unique(levels[levels >= -1]).tolist():
                faces = np.flatnonzero(levels == lv)
                tri = core.ranges(off[faces], off[faces] + tc[faces])
                if not tri.size:
                    continue
                if lv not in lv_rgb:
                    lv_rgb[lv] = core.level_rgb(np.array([lv]))[0]
                r, g, b = (float(c) for c in lv_rgb[lv])
                groups.append((om.MColor((r, g, b, float(alpha))), om.MUintArray(tv[tri].ravel().tolist())))
            if groups:
                items.append((fn.getPoints(om.MSpace.kWorld), groups))
        except Exception:
            print("[UV Shell Gap Overlay] 3D colors for %s failed:\n%s" % (path, traceback.format_exc()))
    return items


def update(engine):
    """Rebuild the draw items when the shells, densities, thresholds or opacity changed."""
    st = engine.settings
    if not st.td_show_3d:
        if _State.enabled:  # turned off (also by a scene's own settings)
            enable(False)
        return
    if not _State.enabled:
        return
    if find_node() is None:  # deleted by hand, or a new scene
        enable(True)
    thr = st.thresholds()
    alpha = max(0.0, min(1.0, float(st.td_fill_opacity)))
    key = (engine.geo_version, engine.td_key, thr, round(alpha, 4))
    if key == _State.key:
        return
    t0 = time.perf_counter()
    _State.items = build_items(engine.geo, engine.td, thr, alpha, engine.arrays)
    _State.key = key
    _State.build_ms = (time.perf_counter() - t0) * 1000.0
    mark_dirty()
