# SPDX-License-Identifier: GPL-3.0-or-later
#
# UV Shell Gap Overlay for Maya - the dockable UV Gaps window: settings and tools on the left,
# the UV view (with its toolbar) on the right.
#
# Authors: Iurii Kruglov & Claude (Anthropic)

import os
import traceback

import numpy as np

from . import core, settings as settings_mod, tools
from .engine import Engine
from .qtcompat import QtWidgets, Qt
from .view import PainterView
from .widgets import ColorButton, RangeSlider, Section, spin

try:
    from .glview import GLView
except Exception:  # no OpenGL classes in this Qt
    GLView = None

try:
    from maya.app.general.mayaMixin import MayaQWidgetDockableMixin
except Exception:  # outside Maya
    MayaQWidgetDockableMixin = None

try:
    import maya.api.OpenMaya as om
except Exception:  # outside Maya
    om = None

PANEL_NAME = "uvGapOverlayPanel"
TITLE = "UV Gaps"

RES_LABELS = [("256", "256"), ("512", "512"), ("1024", "1024"), ("2048", "2048"), ("4096", "4096"),
              ("8192", "8192"), ("CUSTOM", "Custom"), ("IMAGE", "UV Editor Image")]


def _info(msg):
    if om is not None:
        om.MGlobal.displayInfo("UV Gaps: " + msg)
    else:
        print("UV Gaps: " + msg)


def _warn(msg):
    if om is not None:
        om.MGlobal.displayWarning("UV Gaps: " + msg)
    else:
        print("UV Gaps warning: " + msg)


class _Binder(object):
    """Two-way links between widgets and settings."""

    def __init__(self, st):
        self.st = st
        self.refreshers = {}

    def _add(self, key, fn):
        self.refreshers.setdefault(key, []).append(fn)
        fn()

    def refresh(self, names):
        for n in names:
            for fn in self.refreshers.get(n, ()):
                fn()

    def check(self, w, key):
        def pull():
            w.blockSignals(True)
            w.setChecked(bool(getattr(self.st, key)))
            w.blockSignals(False)
        w.toggled.connect(lambda on: self.st.update({key: bool(on)}))
        self._add(key, pull)
        return w

    def value(self, w, key):
        integer = isinstance(w, QtWidgets.QSpinBox)

        def pull():
            v = getattr(self.st, key)
            w.blockSignals(True)
            w.setValue(int(round(v)) if integer else float(v))
            w.blockSignals(False)
        w.valueChanged.connect(lambda v: self.st.update({key: v}))
        self._add(key, pull)
        return w

    def density(self, w, key, manual=False):
        """A texel density stored in px/m, shown in the chosen unit. `manual`: typing a value
        turns Auto Low / High off, so the typed value stays."""
        def pull():
            w.blockSignals(True)
            w.setSuffix(" " + self.st.td_label())
            w.setValue(getattr(self.st, key) * self.st.td_factor())
            w.blockSignals(False)

        def push(v):
            values = {key: max(0.0, float(v)) / self.st.td_factor()}
            if manual and self.st.td_auto_range:
                values["td_auto_range"] = False
            self.st.update(values)
        w.valueChanged.connect(push)
        self._add(key, pull)
        self.refreshers.setdefault("td_unit", []).append(pull)
        return w

    def combo(self, w, key, items):
        for value, label in items:
            w.addItem(label, value)

        def pull():
            w.blockSignals(True)
            i = w.findData(getattr(self.st, key))
            w.setCurrentIndex(max(0, i))
            w.blockSignals(False)
        w.currentIndexChanged.connect(lambda i: self.st.update({key: w.itemData(i)}))
        self._add(key, pull)
        return w

    def color(self, w, key):
        def pull():
            w.set_rgb(getattr(self.st, key))
        w.changed.connect(lambda rgb: self.st.update({key: rgb}))
        self._add(key, pull)
        return w


class _MaterialList(QtWidgets.QTreeWidget):
    """Material sets of the shown meshes: check sets for Low / High and the buttons, uncheck
    Shown to hide a set's shells from the view and the measurements."""

    def __init__(self, panel):
        QtWidgets.QTreeWidget.__init__(self)
        self.panel = panel
        self.setColumnCount(4)
        self.setHeaderLabels(["Material set", "Shells", "Density", "Shown"])
        self.setRootIsDecorated(False)
        self.setUniformRowHeights(True)
        self.setSelectionMode(QtWidgets.QAbstractItemView.SelectionMode.SingleSelection)
        hdr = self.header()
        hdr.setStretchLastSection(False)
        hdr.setSectionResizeMode(0, QtWidgets.QHeaderView.ResizeMode.Stretch)
        for c in (1, 2, 3):
            hdr.setSectionResizeMode(c, QtWidgets.QHeaderView.ResizeMode.ResizeToContents)
        self.setMinimumWidth(10)
        self.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self._keys = []
        self._busy = False
        self.itemChanged.connect(self._item_changed)
        self.itemDoubleClicked.connect(lambda it, col: self.panel.select_sets([it.data(0, Qt.ItemDataRole.UserRole)]))

    def keys(self):
        return list(self._keys)

    def current_key(self):
        it = self.currentItem()
        return it.data(0, Qt.ItemDataRole.UserRole) if it is not None else None

    def fill(self, eng):
        """Show the material sets of the shown meshes. Rows are updated in place while the
        sets stay the same (this also runs from the rows' own change signals)."""
        st = eng.settings
        pub = eng.pub
        keys = list(eng.materials)
        checked, hidden = set(st.checked), set(st.hidden)
        f = st.td_factor()
        self._busy = True
        try:
            if keys != self._keys or self.topLevelItemCount() != len(keys):
                cur = self.current_key()
                self.clear()
                self._keys = keys
                for k in keys:
                    it = QtWidgets.QTreeWidgetItem([core.material_label(k), "", "", ""])
                    it.setData(0, Qt.ItemDataRole.UserRole, k)
                    it.setFlags(it.flags() | Qt.ItemFlag.ItemIsUserCheckable)
                    it.setCheckState(0, Qt.CheckState.Unchecked)  # (a box shows only once a state is set)
                    it.setCheckState(3, Qt.CheckState.Checked)
                    for c in (1, 2):
                        it.setTextAlignment(c, Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
                    self.addTopLevelItem(it)
                    if k == cur:
                        self.setCurrentItem(it)
            for row, k in enumerate(keys):
                it = self.topLevelItem(row)
                n, lo, hi, faces, shown = pub.stats.get(k, (0, None, None, 0, 0)) if pub else (0, None, None, 0, 0)
                if lo is None:
                    dens = "-"
                elif abs(hi - lo) <= 1e-9 * max(1.0, hi):
                    dens = core.fmt_td(lo * f, "").strip()
                else:
                    dens = "%s - %s" % (core.fmt_td(lo * f, "").strip(), core.fmt_td(hi * f, "").strip())
                it.setText(1, str(n))
                it.setText(2, dens)
                it.setToolTip(0, "%s: %d faces, %d shown" % (core.material_label(k), faces, shown))
                want = Qt.CheckState.Checked if k in checked else Qt.CheckState.Unchecked
                if it.checkState(0) != want:
                    it.setCheckState(0, want)
                want = Qt.CheckState.Unchecked if k in hidden else Qt.CheckState.Checked
                if it.checkState(3) != want:
                    it.setCheckState(3, want)
        finally:
            self._busy = False
        self._fit_height()

    def _fit_height(self):
        """As tall as its rows (3 to 8)."""
        rows = max(3, min(8, self.topLevelItemCount()))
        rh = self.sizeHintForRow(0) if self.topLevelItemCount() else self.fontMetrics().height() + 4
        h = self.header().sizeHint().height() + rows * max(rh, 16) + 2 * self.frameWidth() + 2
        self.setFixedHeight(int(h))

    def _item_changed(self, it, col):
        if self._busy:
            return
        k = it.data(0, Qt.ItemDataRole.UserRole)
        st = self.panel.engine.settings
        if col == 0:
            on = it.checkState(0) == Qt.CheckState.Checked
            checked = set(st.checked)
            checked = (checked | {k}) if on else (checked - {k})
            st.update({"checked": tuple(sorted(checked))})
        elif col == 3:
            self.panel.engine.set_hidden([k], it.checkState(3) != Qt.CheckState.Checked)


_Bases = (MayaQWidgetDockableMixin, QtWidgets.QWidget) if MayaQWidgetDockableMixin is not None else (QtWidgets.QWidget,)


class Panel(*_Bases):
    def __init__(self, parent=None):
        super(Panel, self).__init__(parent)
        self.setObjectName(PANEL_NAME)
        self.setWindowTitle(TITLE)
        self.engine = Engine(self)
        self.st = self.engine.settings
        self.bind = _Binder(self.st)
        self._closed = False
        self._build()
        self.engine.settings_changed.connect(self._settings_changed)
        self.engine.updated.connect(self._data_changed)
        self.engine.start()
        self._td3d_sync()

    # -- layout -----------------------------------------------------------------------------

    def _build(self):
        b = self.bind
        outer = QtWidgets.QVBoxLayout(self)
        outer.setContentsMargins(4, 4, 4, 4)
        outer.setSpacing(4)

        top = QtWidgets.QHBoxLayout()
        self.cb_show = b.check(QtWidgets.QCheckBox("Gaps"), "show")
        self.cb_show.setToolTip("Measure and draw the pixel gaps between UV shells and to UDIM tile borders")
        self.cb_td = b.check(QtWidgets.QCheckBox("Texel Density"), "td_show")
        self.cb_td.setToolTip("Color every UV shell by its texel density (red at Low, green at Needed, blue at High)")
        self.cb_td3d = b.check(QtWidgets.QCheckBox("In 3D Viewport"), "td_show_3d")
        self.cb_td3d.setToolTip("Color the shown meshes' faces in the 3D viewport by the texel density of their shell")
        for w in (self.cb_show, self.cb_td, self.cb_td3d):
            top.addWidget(w)
        top.addStretch(1)
        btn = QtWidgets.QToolButton()
        btn.setText("Refresh")
        btn.setToolTip("Read the meshes again")
        btn.clicked.connect(self.engine.invalidate)
        top.addWidget(btn)
        menu_btn = QtWidgets.QToolButton()
        menu_btn.setText("Settings")
        menu_btn.setPopupMode(QtWidgets.QToolButton.ToolButtonPopupMode.InstantPopup)
        menu = QtWidgets.QMenu(menu_btn)
        try:
            menu.setToolTipsVisible(True)
        except Exception:
            pass
        menu.addAction("Save Settings as My Defaults", self._save_defaults)
        menu.addAction("Reset to My Defaults", self._reset_mine)
        menu.addAction("Reset to Factory Defaults", self._reset_factory)
        menu.addSeparator()
        self.act_gpu = menu.addAction("Draw the View on the GPU")
        self.act_gpu.setCheckable(True)
        self.act_gpu.setChecked(bool(self.st.gpu_view))
        self.act_gpu.setToolTip("Draw the UV view with OpenGL (fast with many faces). Turn off if the view "
                                "stays black or misdraws. Kept for this computer, not with the scene")
        self.act_gpu.toggled.connect(lambda on: self.st.update({"gpu_view": bool(on)}))
        menu.addSeparator()
        menu.addAction("Run Self-Test", self._self_test)
        menu.addAction("About", self._about)
        menu_btn.setMenu(menu)
        top.addWidget(menu_btn)
        outer.addLayout(top)

        split = QtWidgets.QSplitter(Qt.Orientation.Horizontal)
        scroll = QtWidgets.QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QtWidgets.QFrame.Shape.NoFrame)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        side = QtWidgets.QWidget()
        col = QtWidgets.QVBoxLayout(side)
        col.setContentsMargins(0, 0, 6, 0)
        col.setSpacing(2)
        scroll.setWidget(side)
        scroll.setMinimumWidth(300)
        right = QtWidgets.QWidget()
        self.view_box = QtWidgets.QVBoxLayout(right)
        self.view_box.setContentsMargins(0, 0, 0, 0)
        self.view_box.setSpacing(2)
        self.view_box.addLayout(self._toolbar())
        self.view = None
        self._make_view()
        split.addWidget(scroll)
        split.addWidget(right)
        split.setStretchFactor(0, 0)
        split.setStretchFactor(1, 1)
        split.setSizes([360, 700])
        outer.addWidget(split, 1)
        self.status = QtWidgets.QLabel("")
        self.status.setWordWrap(True)
        outer.addWidget(self.status)

        # summary
        sec = Section("Summary")
        self.summary = QtWidgets.QLabel("")
        self.summary.setWordWrap(True)
        self.summary.setTextFormat(Qt.TextFormat.RichText)
        sec.row("", self.summary)
        self.timing = QtWidgets.QLabel("")
        self.timing.setWordWrap(True)
        self.timing.setStyleSheet("color: #909090;")
        self.timing.setToolTip("How long the last update took: reading the meshes from Maya, finding shells, "
                               "measuring gaps, drawing the view")
        sec.row("", self.timing)
        col.addWidget(sec)

        self._build_tools(col)

        # texture
        sec = Section("Texture")
        b.combo(sec.row("Size", QtWidgets.QComboBox()), "resolution", RES_LABELS).setToolTip(
            "Texture size used to turn UV distances into pixels (Custom: any width and height; UV Editor "
            "Image: the size of the image shown in the UV Editor)")
        self.res_row = QtWidgets.QWidget()
        lay = QtWidgets.QHBoxLayout(self.res_row)
        lay.setContentsMargins(0, 0, 0, 0)
        self.res_x = b.value(spin(1, 65536, 0, 256, " px"), "res_x")
        self.res_y = b.value(spin(1, 65536, 0, 256, " px"), "res_y")
        self.res_x.setToolTip("Custom texture width")
        self.res_y.setToolTip("Custom texture height")
        lay.addWidget(self.res_x, 1)
        lay.addWidget(QtWidgets.QLabel("×"))
        lay.addWidget(self.res_y, 1)
        sec.row("", self.res_row)
        self.res_note = sec.row("", QtWidgets.QLabel(""))
        self.res_note.setWordWrap(True)
        col.addWidget(sec)

        # gaps
        sec = Section("Gaps")
        b.value(sec.row("Minimal", spin(0, 4096, 1, 1, " px")), "min_px").setToolTip(
            "Smallest acceptable gap between shells, in texture pixels")
        b.value(sec.row("Needed", spin(0, 4096, 1, 1, " px")), "needed_px").setToolTip(
            "Target gap between shells, in texture pixels")
        b.value(sec.row("Search Radius", spin(0.1, 4096, 1, 1, " px")), "search_px").setToolTip(
            "Gaps up to this size are measured; shells farther apart are not treated as neighbors")
        b.value(sec.row("Points per Shell", spin(1, 512, 0, 1)), "points").setToolTip(
            "Measurement points spread evenly along each shell's border (outer border and holes)")
        b.value(sec.row("Shift Along Border", spin(0, 100, 0, 5, " %")), "shift").setToolTip(
            "Slide the measurement points along the borders, as a fraction of their spacing")
        b.check(sec.row("", QtWidgets.QCheckBox("Selected Shells Only")), "selected_only").setToolTip(
            "Measure only from shells with selected components (UVs, faces, edges or vertices); objects "
            "selected as a whole count fully. Distances still go to every shell")
        b.check(sec.row("", QtWidgets.QCheckBox("Same Material Only")), "same_material").setToolTip(
            "Measure gaps and find overlaps only between shells of the same material (each material has its "
            "own texture). A shell's material is the one covering most of its UV area")
        col.addWidget(sec)

        self._build_overlaps(col)

        # UDIM tiles
        sec = Section("UDIM Tiles", expanded=False)
        b.check(sec.row("", QtWidgets.QCheckBox("Measure to Tile Borders")), "tile_border").setToolTip(
            "Measure shells near the border of their UDIM tile and flag shells crossing a tile border. Each "
            "tile is its own texture: gaps are measured only between shells in the same tile")
        b.value(sec.row("Border Minimal", spin(0, 4096, 1, 1, " px")), "border_min_px")
        b.value(sec.row("Border Needed", spin(0, 4096, 1, 1, " px")), "border_needed_px")
        col.addWidget(sec)

        # flipped
        sec = Section("Flipped Shells", expanded=False)
        b.check(sec.row("", QtWidgets.QCheckBox("Show Flipped Shells")), "show_flipped").setToolTip(
            "Highlight shells whose UVs are mirrored (clockwise in UV space)")
        bt = sec.row("", QtWidgets.QPushButton("Select Flipped Shells"))
        bt.setToolTip("Select the mirrored shells (their UVs; their faces while you select faces). "
                      "Shift-click: add to the selection")
        bt.clicked.connect(self.select_flipped)
        col.addWidget(sec)

        # materials
        sec = Section("Material Sets")
        self.materials = _MaterialList(self)
        sec.row("", self.materials)
        row = QtWidgets.QHBoxLayout()
        row.setContentsMargins(0, 0, 0, 0)
        for text, tip, fn in (("Select", "Select the shells of the checked sets (the current row when none "
                                         "is checked). Shift-click: add", self._select_sets_clicked),
                              ("Hide", "Hide the shells of the checked sets (or the current row) from this "
                                       "view and the measurements", lambda: self._hide_sets(True)),
                              ("Reveal", "Show the hidden shells of the checked sets (or the current row)",
                               lambda: self._hide_sets(False))):
            w = QtWidgets.QPushButton(text)
            w.setToolTip(tip)
            w.clicked.connect(fn)
            row.addWidget(w)
        holder = QtWidgets.QWidget()
        holder.setLayout(row)
        sec.row("", holder)
        row = QtWidgets.QHBoxLayout()
        row.setContentsMargins(0, 0, 0, 0)
        row.addWidget(QtWidgets.QLabel("Check"))
        for text, act in (("All", "ALL"), ("None", "NONE"), ("Invert", "INVERT")):
            w = QtWidgets.QToolButton()
            w.setText(text)
            w.setToolTip("Check %s material sets" % {"ALL": "all", "NONE": "no", "INVERT": "the other"}[act])
            w.clicked.connect(lambda _c=False, a=act: self._check_sets(a))
            row.addWidget(w)
        row.addStretch(1)
        holder = QtWidgets.QWidget()
        holder.setLayout(row)
        sec.row("", holder)
        col.addWidget(sec)

        # texel density
        sec = Section("Texel Density")
        b.combo(sec.row("Unit", QtWidgets.QComboBox()), "td_unit", [(u[0], u[1]) for u in core.TD_UNITS])
        b.density(sec.row("Needed", spin(0, 1e9, 2, 10)), "td_needed_m").setToolTip(
            "Target texel density, shown green")
        b.density(sec.row("Low", spin(0, 1e9, 2, 10)), "td_low_m", manual=True).setToolTip(
            "Texel density shown red; lower densities are red too. Typing a value turns Auto Low / High off")
        b.density(sec.row("High", spin(0, 1e9, 2, 10)), "td_high_m", manual=True).setToolTip(
            "Texel density shown blue; higher densities are blue too. Typing a value turns Auto Low / High off")
        row = QtWidgets.QHBoxLayout()
        row.setContentsMargins(0, 0, 0, 0)
        auto = b.check(QtWidgets.QCheckBox("Auto Low / High"), "td_auto_range")
        auto.setToolTip("Fill Low and High with the lowest and highest texel density of the checked material "
                        "sets (all shells when none is checked) whenever the checked sets, the objects or the "
                        "texture size change")
        row.addWidget(auto)
        fill = QtWidgets.QPushButton("Fill Now")
        fill.setToolTip("Set Low and High to the lowest and highest texel density of the checked material sets")
        fill.clicked.connect(self._fill_range)
        row.addWidget(fill)
        holder = QtWidgets.QWidget()
        holder.setLayout(row)
        sec.row("", holder)
        b.value(sec.row("Fill Opacity", spin(0, 1, 2, 0.05)), "td_fill_opacity")
        self.td_stats = sec.row("", QtWidgets.QLabel(""))
        self.td_stats.setWordWrap(True)
        col.addWidget(sec)

        sec = Section("Texel Density Range")
        self.range = sec.row("", RangeSlider())
        self.range.setToolTip("0% is the lowest texel density of the shown shells, 100% the highest. "
                              "Double-click: the whole range")
        self.range.changed.connect(lambda lo, hi: self.st.update({"td_sel_from": lo, "td_sel_to": hi}))
        self.bind.refreshers.setdefault("td_sel_from", []).append(self._pull_range)
        self.bind.refreshers.setdefault("td_sel_to", []).append(self._pull_range)
        self._pull_range()
        self.range_note = sec.row("", QtWidgets.QLabel(""))
        b.check(sec.row("", QtWidgets.QCheckBox("Highlight Range")), "td_range_highlight").setToolTip(
            "Outline the shells inside the range while it is narrower than all shells")
        bt = sec.row("", QtWidgets.QPushButton("Select Shells in Range"))
        bt.setToolTip("Select the shown shells whose texel density is inside the range. Shift-click: add")
        bt.clicked.connect(self.select_range)
        col.addWidget(sec)

        # shell info
        sec = Section("Shell Info", expanded=False)
        b.check(sec.row("", QtWidgets.QCheckBox("Info Blocks")), "info_show").setToolTip(
            "One info block per shell: texel density, object scale, flip state, orientation arrow")
        b.check(sec.row("", QtWidgets.QCheckBox("Orientation Arrows")), "show_orientation").setToolTip(
            "Arrow showing where the scene's up axis runs across each shell (green: +Y in a Y-up scene); on "
            "shells lying flat, where -Z runs (blue)")
        b.check(sec.row("", QtWidgets.QCheckBox("Object Scale")), "show_scale").setToolTip(
            "Note the object scale on the shells of objects whose scale is not 1")
        col.addWidget(sec)

        # display
        sec = Section("Display", expanded=False)
        b.value(sec.row("Font Size", spin(6, 72, 0, 1, " px")), "font_size")
        b.value(sec.row("Opacity", spin(0, 1, 2, 0.05)), "opacity")
        b.value(sec.row("Line Width", spin(1, 10, 1, 0.5, " px")), "line_width")
        b.check(sec.row("", QtWidgets.QCheckBox("Label Background")), "label_background")
        b.check(sec.row("", QtWidgets.QCheckBox("Hide Overlapping Labels")), "declutter").setToolTip(
            "Skip labels that would cover a more critical one (problems and smallest gaps win)")
        b.check(sec.row("", QtWidgets.QCheckBox("UV Wireframe")), "show_wire")
        b.check(sec.row("", QtWidgets.QCheckBox("Grid")), "show_grid")
        col.addWidget(sec)

        # colors
        sec = Section("Colors", expanded=False)
        for key, label in (("color_overlap", "Overlap"), ("color_zero", "Touching (0 px)"),
                           ("color_min", "At Minimal"), ("color_needed", "At Needed"),
                           ("color_flipped", "Flipped")):
            b.color(sec.row(label, ColorButton()), key)
        col.addWidget(sec)
        col.addStretch(1)
        self._settings_changed(("resolution",))

    # -- the view and its toolbar -------------------------------------------------------------

    def _toolbar(self):
        bar = QtWidgets.QHBoxLayout()
        bar.setContentsMargins(0, 0, 0, 0)
        bar.setSpacing(2)
        self.tool_buttons, self.mode_buttons = {}, {}

        def button(text, tip, group, key, fn):
            w = QtWidgets.QToolButton()
            w.setText(text)
            w.setToolTip(tip)
            w.setCheckable(True)
            w.setAutoRaise(False)
            w.clicked.connect(lambda _c=False: fn(key))
            group[key] = w
            bar.addWidget(w)
            return w

        beside = " A click or a drag beside the manipulator selects."
        for key, text, tip in (("select", "Select", "Select (Q): click, or drag a rectangle"),
                               ("move", "Move", "Move the selected UVs (W): drag the manipulator - its middle "
                                                "moves freely (Shift: along one direction), an arrow along "
                                                "it." + beside),
                               ("rotate", "Rotate", "Rotate the selected UVs (E): drag inside the ring, around "
                                                    "the pivot (Shift: steps of 15°)." + beside),
                               ("scale", "Scale", "Scale the selected UVs (R): drag a handle away from or "
                                                  "toward the pivot to scale along it, the middle to scale "
                                                  "both ways - right or up is bigger (Shift: steps of 0.1)."
                                                  + beside)):
            button(text, tip, self.tool_buttons, key, lambda k: self.view.set_tool(k))
        bar.addSpacing(10)
        for key, text, tip in (("UV", "UV", "Pick UVs (1)"), ("EDGE", "Edge", "Pick edges (2)"),
                               ("FACE", "Face", "Pick faces (3)"), ("SHELL", "Shell", "Pick whole shells (4)")):
            button(text, tip + ". Shift toggles, Ctrl deselects, Ctrl+Shift adds",
                   self.mode_buttons, key, lambda k: self.st.update({"sel_mode": k}))
        bar.addStretch(1)
        for text, tip, fn in (("Frame", "Frame the selection (F)", lambda: self.view.frame_selected()),
                              ("All", "Frame all the shells (A)", lambda: self.view.frame_all())):
            w = QtWidgets.QToolButton()
            w.setText(text)
            w.setToolTip(tip)
            w.clicked.connect(lambda _c=False, f=fn: f())
            bar.addWidget(w)
        return bar

    def _sync_toolbar(self):
        tool = self.view.tool if self.view is not None else "select"
        for key, w in self.tool_buttons.items():
            w.setChecked(key == tool)
        for key, w in self.mode_buttons.items():
            w.setChecked(key == self.st.sel_mode)

    def _make_view(self, force_painter=False):
        """The UV view: on the GPU when that is on and available, else drawn with QPainter.
        The view's zoom and tool carry over."""
        old = self.view
        use_gl = (bool(self.st.gpu_view) and GLView is not None and not force_painter
                  and not os.environ.get("UVGAP_NO_GPU"))
        try:
            view = GLView(self.engine) if use_gl else PainterView(self.engine)
        except Exception:
            print("[UV Shell Gap Overlay] GPU view not available:\n" + traceback.format_exc())
            use_gl = False
            view = PainterView(self.engine)
        if use_gl:
            view.gl_failed.connect(self._gl_failed)
        if old is not None:
            view.u0, view.v0, view.zoom, view.tool, view._framed_for = old.u0, old.v0, old.zoom, old.tool, old._framed_for
            try:
                self.engine.updated.disconnect(old._on_updated)
            except Exception:
                pass
            self.view_box.removeWidget(old)
            old.hide()
            old.deleteLater()
        view.tool_changed = lambda _tool: self._sync_toolbar()
        self.view = view
        self.view_box.addWidget(view, 1)
        self.gpu = use_gl
        self._sync_toolbar()

    def _gl_failed(self, msg):
        _warn("the GPU view is not available here (%s): using the standard view" % msg)
        self._make_view(force_painter=True)

    # -- tools ----------------------------------------------------------------------------------

    def _run(self, fn, *args):
        """A tool, with its errors in the Script Editor instead of a dialog."""
        try:
            return fn(self.engine, *args)
        except Exception:
            _warn("that didn't work: %s" % traceback.format_exc().strip().splitlines()[-1])
            print(traceback.format_exc())

    def _buttons(self, sec, items, label=""):
        row = QtWidgets.QHBoxLayout()
        row.setContentsMargins(0, 0, 0, 0)
        row.setSpacing(3)
        out = []
        for item in items:
            if isinstance(item, QtWidgets.QWidget):
                row.addWidget(item, 1)
                out.append(item)
                continue
            text, tip, fn = item
            w = QtWidgets.QPushButton(text)
            w.setToolTip(tip)
            w.setMinimumWidth(10)
            w.clicked.connect(lambda _c=False, f=fn: f())
            row.addWidget(w, 1)
            out.append(w)
        holder = QtWidgets.QWidget()
        holder.setLayout(row)
        sec.row(label, holder)
        return out

    def _build_tools(self, col):
        b = self.bind
        units = [("UV", "UV"), ("PX", "px")]
        sec = Section("UV Tools")
        self._buttons(sec, [
            ("Cut", "Cut the UVs along the selected edges; with faces selected, cut them out along their border",
             lambda: self._run(tools.cut)),
            ("Weld", "Weld the selection: selected edges are sewn; selected UVs are merged where they belong to "
                     "the same vertex, however far apart", lambda: self._run(tools.weld)),
        ])
        dist = b.value(spin(0, 1e6, 3, 0.5), "weld_dist")
        dist.setToolTip("Weld distance")
        unit = b.combo(QtWidgets.QComboBox(), "weld_unit", units)
        unit.setToolTip("Weld distance in UV units or in texture pixels")
        self._buttons(sec, [
            ("Weld Within", "Merge UVs of the same vertex closer than the distance: of the selected UVs, or "
                            "of all UVs of meshes selected as objects", lambda: self._run(tools.weld_within)),
            dist, unit])
        amount = b.value(spin(0, 1e6, 4, 0.25), "move_amount")
        amount.setToolTip("How far the arrow buttons move the selection (1 UV: one UDIM tile)")
        unit = b.combo(QtWidgets.QComboBox(), "move_unit", units)
        unit.setToolTip("Move amount in UV units or in texture pixels")
        self._buttons(sec, [amount, unit], "Move")
        self._buttons(sec, [(text, "Move the selected UVs %s by the amount (meshes selected as objects: "
                                   "all their UVs)" % d, lambda d=d: self._run(tools.move_step, d))
                            for text, d in (("←", "left"), ("↑", "up"), ("↓", "down"), ("→", "right"))])
        angle = b.value(spin(-360, 360, 2, 15, "°"), "rotate_angle")
        self._buttons(sec, [
            angle,
            ("↺", "Rotate the selected UVs counterclockwise by the angle",
             lambda: self._run(tools.rotate, float(self.st.rotate_angle))),
            ("↻", "Rotate the selected UVs clockwise by the angle",
             lambda: self._run(tools.rotate, -float(self.st.rotate_angle)))], "Rotate")
        factor = b.value(spin(0.0001, 10000, 4, 0.1), "scale_factor")
        self._buttons(sec, [
            factor,
            ("×", "Scale the selected UVs up by the factor",
             lambda: self._run(tools.scale, float(self.st.scale_factor), float(self.st.scale_factor))),
            ("÷", "Scale the selected UVs down by the factor",
             lambda: self._run(tools.scale, 1.0 / float(self.st.scale_factor), 1.0 / float(self.st.scale_factor)))],
            "Scale")
        b.combo(sec.row("Pivot", QtWidgets.QComboBox()), "pivot",
                [("SELECTION", "Selection Center"), ("SHELL", "Each Shell's Center")]).setToolTip(
            "Rotate and scale around the middle of the selected UVs, or every shell around its own middle")
        b.check(sec.row("", QtWidgets.QCheckBox("Show Selection")), "show_selection").setToolTip(
            "Highlight the selected UVs, edges, faces and shells in the view")
        col.addWidget(sec)

    def _build_overlaps(self, col):
        b = self.bind
        sec = Section("Overlaps and Stacks")
        b.check(sec.row("", QtWidgets.QCheckBox("Stacked Shells as One")), "stacks").setToolTip(
            "Shells lying on each other on purpose - copies of a part sharing the same texture space - count "
            "as one shell: gaps are measured once per stack and they aren't reported as overlaps. Only shells "
            "that don't fit (a copy placed carelessly, shells overlapping partly) are overlaps")
        b.value(sec.row("Stack Match", spin(50, 100, 2, 0.1, " %")), "stack_match").setToolTip(
            "Shells covering each other at least this much are a stack; less is an overlap")
        self._buttons(sec, [
            ("Overlapping", "Select the shells that overlap and aren't a stack. Shift-click: add",
             lambda: self._run(tools.select_overlapping, self._mode())),
            ("Stacked", "Select every shell lying in a stack. Shift-click: add",
             lambda: self._run(tools.select_stacked, self._mode())),
            ("All but One", "Select all the shells lying on others but one of every stack and overlap: a shell "
                            "that isn't flipped stays unselected (see Only in the 0-1 Tile). Shift-click: add",
             lambda: self._run(tools.select_but_one, self._mode()))], "Select")
        tiles = b.value(spin(-99, 99, 0, 1), "stack_tiles")
        tiles.setToolTip("How many UDIM tiles along U the shells are moved (negative: to the left)")
        self._buttons(sec, [
            ("Move All but One", "Move all the shells lying on others to another UDIM tile, leaving one of "
                                 "every stack and overlap in place - a shell that isn't flipped. One undo step",
             lambda: self._run(tools.move_but_one)),
            tiles], "")
        b.check(sec.row("", QtWidgets.QCheckBox("Only in the 0-1 Tile")), "stack_home_only").setToolTip(
            "All but One (Select and Move) takes only shells lying in the 0-1 tile (UDIM 1001): copies moved to "
            "another tile earlier stay where they are, so pressing Move All but One again changes nothing. Off: "
            "shells in every tile")
        self.stack_note = sec.row("", QtWidgets.QLabel(""))
        self.stack_note.setWordWrap(True)
        self.stack_note.setTextFormat(Qt.TextFormat.RichText)
        col.addWidget(sec)

    # -- updates ----------------------------------------------------------------------------

    def _pull_range(self):
        self.range.blockSignals(True)
        self.range.set_values(self.st.td_sel_from, self.st.td_sel_to)
        self.range.blockSignals(False)

    def _settings_changed(self, names):
        self.bind.refresh(names)
        if "resolution" in names:
            self.res_row.setVisible(self.st.resolution in ("CUSTOM", "IMAGE"))
        if "td_show_3d" in names:
            self._td3d_sync()
        if set(names) & {"checked", "hidden", "td_unit"}:
            self.materials.fill(self.engine)
        if "gpu_view" in names:
            self.act_gpu.blockSignals(True)
            self.act_gpu.setChecked(bool(self.st.gpu_view))
            self.act_gpu.blockSignals(False)
            settings_mod.save_local(self.st)  # (kept for this computer, not with the scene)
            if bool(self.st.gpu_view) != self.gpu:
                self._make_view()
        if "sel_mode" in names:
            self._sync_toolbar()
        if self.view is not None:
            self.view.update()

    def _data_changed(self):
        eng, st = self.engine, self.st
        if not eng.geo_pending:  # the shells are known (the gaps may still be on their way)
            key = (eng.geo_version, eng.td_key)
            if key != getattr(self, "_shown_geo", None):
                self._shown_geo = key
                self.materials.fill(eng)
            if st.td_show_3d:
                self._td3d_update()  # (rebuilds only when shells, densities, thresholds or opacity changed)
            self._update_texts()

    def _update_texts(self):
        eng, st = self.engine, self.st
        s = eng.summary()
        lines = ["<b>%d</b> object%s, <b>%d</b> shell%s, %d face%s" % (
            s["objects"], "" if s["objects"] == 1 else "s", s["shells"], "" if s["shells"] == 1 else "s",
            s["faces"], "" if s["faces"] == 1 else "s")]
        if "gaps" in s:
            bad = s["below_min"]
            lines.append("%d gap%s measured on %d shell%s; %s" % (
                s["gaps"], "" if s["gaps"] == 1 else "s", s["sampled"], "" if s["sampled"] == 1 else "s",
                ("<span style='color:#ff6060'><b>%d below Minimal</b></span>" % bad) if bad else "none below Minimal"))
            if np.isfinite(s["smallest"]):
                lines.append("Smallest: %s" % core.fmt_px(s["smallest"]))
            probs = []
            if s["overlaps"]:
                probs.append("%d overlapping pair%s" % (s["overlaps"], "" if s["overlaps"] == 1 else "s"))
            if s["tile_crossing"]:
                probs.append("%d crossing a tile border" % s["tile_crossing"])
            if probs:
                lines.append("<span style='color:#ff60e0'>" + ", ".join(probs) + "</span>")
        if s["flipped"]:
            lines.append("%d flipped shell%s" % (s["flipped"], "" if s["flipped"] == 1 else "s"))
        if s.get("stacks"):
            lines.append("%d shells in %d stack%s" % (s["stacked"], s["stacks"], "" if s["stacks"] == 1 else "s"))
        if eng.meas_pending:
            lines.append("<span style='color:#909090'>%s…</span>" % (eng.busy or "updating"))
        self.summary.setText("<br>".join(lines))
        self.timing.setText(eng.timing_text())
        if "stacks" in s:
            note = ("%d stack%s of %d shells (%d lying on another)" % (
                s["stacks"], "" if s["stacks"] == 1 else "s", s["stacked"], s["stacked"] - s["stacks"])
                if s["stacks"] else "No stacked shells")
            if s.get("overlaps", 0) >= 100:
                note += ("<br><span style='color:#909090'>Many overlaps: copies stack when they cover each other by "
                         "%s %%. If yours are placed less exactly, lower Stack Match.</span>" % (
                             "%g" % float(st.stack_match)))
            self.stack_note.setText(note)
        else:
            self.stack_note.setText("")
        self.stack_note.setVisible(bool(self.stack_note.text()))

        if st.resolution == "IMAGE":
            got = eng.res_source
            self.res_note.setText("%d × %d px from the UV Editor's image" % (eng.W, eng.H) if got else
                                  "No image in a UV Editor: using the size below")
        else:
            self.res_note.setText("")
        self.res_note.setVisible(bool(self.res_note.text()))

        stats = eng.td_stats()
        f, u = st.td_factor(), st.td_label()
        if stats is None or stats[1] is None:
            self.td_stats.setText("No shells with a texel density")
            self.range_note.setText("")
        else:
            n, lo, med, hi, below, above = stats
            self.td_stats.setText("%d shells: %s - %s (median %s)<br>%d at or below Low, %d at or above High" % (
                n, core.fmt_td(lo * f, u), core.fmt_td(hi * f, u), core.fmt_td(med * f, u), below, above))
            shells, bounds = eng.range_shells()
            if bounds is not None:
                self.range_note.setText("%s to %s: %d shell%s" % (
                    core.fmt_td(max(bounds[0], 0.0) * f, u), core.fmt_td(bounds[1] * f, u), shells.size,
                    "" if shells.size == 1 else "s"))
        self.status.setText("Error - see the Script Editor" if eng.error else "")

    # -- 3D viewport ------------------------------------------------------------------------

    def _td3d_sync(self):
        try:
            from . import td3d
            td3d.enable(bool(self.st.td_show_3d) and not self._closed)
            if self.st.td_show_3d:
                self._td3d_update()
        except Exception:
            _warn("the 3D viewport overlay is not available: %s" % traceback.format_exc().strip().splitlines()[-1])
            print(traceback.format_exc())

    def _td3d_update(self):
        try:
            from . import td3d
            td3d.update(self.engine)
        except Exception:
            print("[UV Shell Gap Overlay] 3D update failed:\n" + traceback.format_exc())

    # -- actions ----------------------------------------------------------------------------

    @staticmethod
    def _mode():
        mods = QtWidgets.QApplication.keyboardModifiers()
        return "add" if mods & Qt.KeyboardModifier.ShiftModifier else "replace"

    def _target_keys(self, keys=None):
        if keys:
            return list(keys)
        checked = [k for k in self.st.checked if k in self.engine.materials]
        if checked:
            return checked
        cur = self.materials.current_key()
        return [cur] if cur is not None else []

    def _set_names(self, keys):
        names = sorted(core.material_label(k) for k in keys)
        return names[0] if len(names) == 1 else "%d material sets" % len(names)

    def select_sets(self, keys=None):
        keys = self._target_keys(keys)
        if not keys:
            _warn("no material set to select: check one, or click a row")
            return
        shells = self.engine.material_shells(keys)
        n = self.engine.select_shells(shells, self._mode(), kind=tools.shell_kind(self.engine))
        _info("%s: %d shell%s selected" % (self._set_names(keys), n, "" if n == 1 else "s"))

    def _select_sets_clicked(self):
        self.select_sets()

    def _hide_sets(self, hide):
        keys = self._target_keys()
        if not keys:
            _warn("no material set: check one, or click a row")
            return
        self.engine.set_hidden(keys, hide)

    def _check_sets(self, action):
        keys = self.engine.materials
        cur = set(self.st.checked)
        if action == "ALL":
            new = set(keys) | cur
        elif action == "NONE":
            new = cur - set(keys)
        else:
            new = (cur - set(keys)) | (set(keys) - cur)
        self.st.update({"checked": tuple(sorted(new))})

    def select_flipped(self):
        shells = core.flipped_shells(self.engine.geo)
        n = self.engine.select_shells(shells, self._mode(), kind=tools.shell_kind(self.engine))
        _info("%d flipped shell%s selected" % (n, "" if n == 1 else "s"))

    def select_range(self):
        shells, bounds = self.engine.range_shells()
        if bounds is None:
            _warn("no shells with a texel density")
            return
        n = self.engine.select_shells(shells, self._mode(), kind=tools.shell_kind(self.engine))
        f, u = self.st.td_factor(), self.st.td_label()
        _info("%d shell%s from %s to %s selected" % (n, "" if n == 1 else "s", core.fmt_td(max(bounds[0], 0.0) * f, u),
                                                       core.fmt_td(bounds[1] * f, u)))

    def _fill_range(self):
        if not self.engine.fill_range():
            _warn("no texel density to fill from: select meshes with UVs")

    def _save_defaults(self):
        settings_mod.save_user_defaults(self.st)
        _info("settings saved as your defaults for new scenes")

    def _reset_mine(self):
        self.st.reset(settings_mod.load_user_defaults() or {})

    def _reset_factory(self):
        self.st.reset({})

    def _self_test(self):
        from . import selftest
        selftest.run()

    def _about(self):
        from . import __version__
        QtWidgets.QMessageBox.about(
            self, "UV Shell Gap Overlay",
            "<b>UV Shell Gap Overlay %s</b> for Maya<br><br>Pixel gaps between UV shells and to UDIM tile "
            "borders, overlaps and stacks, texel density in the UV view and the 3D viewport, per-shell info "
            "blocks, material sets and UV tools.<br><br>%s<br><br>Iurii Kruglov &amp; Claude (Anthropic)<br>"
            "GPL-3.0-or-later" % (__version__, "View: " + (getattr(self.view, "gl_info", "") or "QPainter")))

    # -- closing ----------------------------------------------------------------------------

    def shutdown(self):
        if self._closed:
            return
        self._closed = True
        try:
            self.engine.stop()
        except Exception:
            pass
        try:
            from . import td3d
            td3d.enable(False)
        except Exception:
            pass

    def closeEvent(self, e):
        self.shutdown()
        super(Panel, self).closeEvent(e)

    def dockCloseEventTriggered(self):  # MayaQWidgetDockableMixin: the workspace control closed
        self.shutdown()
