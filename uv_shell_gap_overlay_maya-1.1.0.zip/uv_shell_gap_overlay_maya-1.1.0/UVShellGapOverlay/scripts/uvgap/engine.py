# SPDX-License-Identifier: GPL-3.0-or-later
#
# UV Shell Gap Overlay for Maya - keeps the shells of the shown meshes measured: reads the
# meshes when they change (Maya callbacks), then finds shells and measures gaps in a
# background thread, so Maya and the window stay responsive. The UV layout is shown as soon as
# the shells are known; the gaps follow. Results are kept per object and per material, so an
# edit computes again only what it touched.
#
# Authors: Iurii Kruglov & Claude (Anthropic)

import threading
import time
import traceback

import numpy as np
import maya.api.OpenMaya as om
from maya import cmds

from . import core, mayadata
from .qtcompat import QtCore, Signal, Qt
from .settings import Settings, initial_values, save_to_scene

LIVE_MS = 40.0       # work cheaper than this is redone right after every change
DEBOUNCE_MS = 250    # heavier work waits until changes pause this long

# settings that only change how things are drawn or what the tools do: nothing to read or
# measure again
VIEW_ONLY = frozenset((
    "font_size", "opacity", "line_width", "label_background", "declutter", "show_wire", "show_grid",
    "color_overlap", "color_zero", "color_min", "color_needed", "color_flipped", "td_fill_opacity",
    "td_sel_from", "td_sel_to", "td_range_highlight", "td_unit", "td_needed_m", "td_low_m", "td_high_m",
    "show_scale", "show_flipped", "sel_mode", "move_amount", "move_unit", "rotate_angle", "scale_factor",
    "pivot", "weld_dist", "weld_unit", "show_selection", "info_show", "show_orientation", "stack_tiles",
    "stack_home_only", "gpu_view"))


def _log(msg):
    print("[UV Shell Gap Overlay] " + msg)


def _ms(t0):
    return (time.perf_counter() - t0) * 1000.0


class _Job(object):
    """One computation for the background thread: everything it needs, gathered on the main
    thread (the worker never touches Maya)."""

    def __init__(self):
        self.epoch = 0
        self.cancelled = False
        self.meshes = []      # MeshArrays, in order
        self.ekeys = []       # extraction key per mesh
        self.uv_sigs = []     # what each mesh's UV data depends on
        self.cached = []      # ObjectParts per mesh, or None: extract it
        self.cache = None     # the engine's MeasureCache (only this job uses it while it runs)
        self.want_orient = True
        self.axes = core.up_axes("y")
        self.hidden = []      # per mesh: the hidden material sets it has
        self.cur_geo = None   # the current geometry, when it stays
        self.sels = {}
        self.measure = None   # measurement arguments, or None
        self.same_mat = True
        self.stack_match = None  # stacks count as one shell when they match this much (0..1)


class Engine(QtCore.QObject):
    """Results for the views: geo (core.Geometry), meas (core.Measurement or None), pairs
    (overlapping shells of geo, when measured), td (px/m per shell), pub (core.Published),
    W / H (texture size). geo_pending / meas_pending: an update of the shells / gaps is on its
    way; busy: what is being computed; timings: how long the last update's steps took."""

    updated = Signal()
    settings_changed = Signal(tuple)
    _posted = Signal(object)   # (kind, job, payload) from the worker thread

    THREADED = True

    def __init__(self, parent=None, threaded=None):
        QtCore.QObject.__init__(self, parent)
        self.threaded = Engine.THREADED if threaded is None else bool(threaded)
        self.settings = Settings(initial_values())
        self.settings.add_listener(self._on_settings)
        self.timer = QtCore.QTimer(self)
        self.timer.setSingleShot(True)
        self.timer.timeout.connect(self.update)
        self._posted.connect(self._on_posted, Qt.ConnectionType.QueuedConnection)
        self.active = False
        self.paths, self.names, self.sels = [], {}, {}
        self.selection = mayadata.Selection()
        self.sel_version = 0               # counts changes of the selection
        self._sel_sig = None
        self.gen, self.xgen = {}, {}       # per mesh: change counts (geometry / transform)
        self.arrays = {}                   # path -> ((gen, xgen), MeshArrays)
        self.content = {}                  # path -> (UV data, 3D data) versions: counts of real changes
        self.parts = {}                    # path -> (extraction key, core.ObjectParts)
        self.mcache = core.MeasureCache()
        self.geo = core.Geometry()
        self.geo_key = None
        self.geo_version = 0
        self.sel_shells = np.zeros(0, dtype=bool)
        self.component_selection = False   # components (not whole objects) are selected
        self.meas = None
        self.meas_key = None
        self.meas_version = 0
        self.pairs = None
        self.pairs_key = None
        self.stacks = None                 # core.Stacks of geo (shells lying on each other), or None
        self.stacks_key = None
        self.td = np.zeros(0)
        self.td_key = None
        self.pub = None
        self.materials = []                # material keys listed in the panel
        self.W = self.H = 2048
        self.res_source = None
        self.up = "y"
        self.geo_pending = False
        self.meas_pending = False
        self.busy = ""
        self.timings = {}
        self.last_geo_ms = self.last_meas_ms = 0.0
        self.auto_key = None
        self.error = None
        self.epoch = 0
        self._job = None
        self._again = False
        self._updating = False
        self._rewatch = False
        self._cb_global, self._cb_objects = [], {}

    @property
    def stale(self):
        return self.geo_pending or self.meas_pending

    # -- lifetime ---------------------------------------------------------------------------

    def start(self):
        if self.active:
            return
        self.active = True
        add = self._cb_global.append
        for name, fn in (("SelectionChanged", self._on_event), ("NameChanged", self._on_event),
                         ("Undo", self._on_undo), ("Redo", self._on_undo)):
            try:
                add(om.MEventMessage.addEventCallback(name, fn))
            except Exception:
                _log("no %s event" % name)
        for msg, fn in ((om.MSceneMessage.kAfterOpen, self._on_scene_loaded),
                        (om.MSceneMessage.kAfterNew, self._on_scene_loaded),
                        (om.MSceneMessage.kBeforeNew, self._on_scene_closing),
                        (om.MSceneMessage.kBeforeOpen, self._on_scene_closing),
                        (om.MSceneMessage.kBeforeSave, self._on_before_save)):
            add(om.MSceneMessage.addCallback(msg, fn))
        try:
            add(om.MDGMessage.addNodeRemovedCallback(self._on_mesh_removed, "mesh"))
        except Exception:
            _log("no node-removed callback")
        self.schedule(0)

    def stop(self):
        self._unwatch()
        self._remove(self._cb_global)
        self.active = False
        self.epoch += 1  # results still on their way are dropped
        if self._job is not None:
            self._job.cancelled = True
        try:
            self.timer.stop()
        except RuntimeError:  # the Qt side is gone already
            pass

    def _dead(self):
        """The window was deleted without closing the engine: stop listening to Maya."""
        self.stop()
        try:
            from . import td3d
            td3d.enable(False)
        except Exception:
            pass

    @staticmethod
    def _remove(ids):
        for i in ids:
            try:
                om.MMessage.removeCallback(i)
            except Exception:
                pass
        del ids[:]

    # -- change tracking --------------------------------------------------------------------

    def schedule(self, delay=None):
        """Update after `delay` ms (default: right away when updates are cheap, else once
        changes pause)."""
        if not self.active:
            return
        try:
            if delay is None:
                delay = 0 if max(self.last_geo_ms, self.last_meas_ms) <= LIVE_MS else DEBOUNCE_MS
                if not self.stale:
                    self.geo_pending = True
                    self.updated.emit()  # views dim the outdated overlay
            self.timer.start(int(delay))
        except RuntimeError:  # "Internal C++ object already deleted"
            self._dead()

    def _on_event(self, *_args):
        """The selection or a name changed: read it right away. That is quick unless other
        meshes are shown now - and then their shells are found in the background."""
        if not self.active:
            return
        try:
            if not self.timer.isActive():  # (an update waiting for edits to pause stays waiting)
                self.timer.start(0)
        except RuntimeError:
            self._dead()

    def _on_mesh_removed(self, *_args):
        """A mesh was deleted. Another node may come to stand at its path (a new mesh with the
        same name, the same file imported again): the shown meshes are watched and read anew.
        What reads the same keeps its results."""
        self._rewatch = True
        for p in self.arrays:
            self.gen[p] = self.gen.get(p, 0) + 1
        self.schedule()

    def _on_undo(self, *_args):
        self.auto_key = None  # Low / High may have been undone: fill again when due
        for p in self.paths:
            self.gen[p] = self.gen.get(p, 0) + 1
        self.schedule()

    def _bump(self, path, transform=False):
        d = self.xgen if transform else self.gen
        d[path] = d.get(path, 0) + 1
        self.schedule()

    def mesh_edited(self, paths):
        """Our own tools changed these meshes: read them again."""
        for p in paths:
            self.gen[p] = self.gen.get(p, 0) + 1
        if self.active:
            self.geo_pending = True  # (views keep the preview of the edit until it is read back)
        self.schedule(0)

    def _unwatch(self):
        for ids in self._cb_objects.values():
            self._remove(ids)
        self._cb_objects.clear()

    def _watch(self, paths):
        """Callbacks on the shown meshes: edits (node dirty), materials (connections), moves.
        Meshes watched already keep their callbacks."""
        want = set(paths)
        for path in [p for p in self._cb_objects if p not in want]:
            self._remove(self._cb_objects.pop(path))
        for path in paths:
            if path in self._cb_objects:
                continue
            try:
                dag = mayadata.dag_path(path)
                node = dag.node()
            except Exception:
                continue
            ids = self._cb_objects[path] = []
            try:
                ids.append(om.MNodeMessage.addNodeDirtyCallback(node, lambda *a, p=path: self._bump(p)))
                ids.append(om.MNodeMessage.addAttributeChangedCallback(
                    node, lambda *a, p=path: self._attr_changed(p, *a)))
                ids.append(om.MDagMessage.addWorldMatrixModifiedCallback(dag, lambda *a, p=path: self._bump(p, True)))
            except Exception:
                _log("could not watch " + path + "\n" + traceback.format_exc())

    def _attr_changed(self, path, msg, plug=None, *_rest):
        if msg & (om.MNodeMessage.kConnectionMade | om.MNodeMessage.kConnectionBroken):
            self._bump(path)  # material assignments are connections
        elif msg & om.MNodeMessage.kAttributeSet and plug is not None:
            try:
                name = plug.name()
            except Exception:
                return
            if "currentUVSet" in name or name.endswith(".cuvs"):  # another UV set shown
                self._bump(path)

    def _on_settings(self, names):
        try:
            self.settings_changed.emit(names)
        except RuntimeError:
            self._dead()
            return
        if "td_auto_range" in names and self.settings.td_auto_range:
            self.auto_key = None  # fill again
        if VIEW_ONLY.issuperset(names):
            if self.active and not self._updating:  # (an update tells the views when it's done)
                self.updated.emit()  # redraw, recolor, new summaries
        else:
            self.schedule(0)

    def _on_scene_closing(self, *_args):
        self._unwatch()
        self.paths = []
        self.arrays.clear()
        self.parts.clear()
        self.epoch += 1
        self._clear_results()

    def _clear_results(self):
        """Nothing shown until the next update (the scene is going away)."""
        self.geo = core.Geometry()
        self.geo_key = None
        self.geo_version += 1
        self.meas = self.meas_key = self.pairs = self.pairs_key = None
        self.stacks = self.stacks_key = None
        self.sel_shells = np.zeros(0, dtype=bool)
        self.td = np.zeros(0)
        self.td_key = None

    def _on_scene_loaded(self, *_args):
        self.gen.clear()
        self.xgen.clear()
        self.arrays.clear()
        self.parts.clear()
        self.mcache = core.MeasureCache()  # (a running job keeps its own)
        self.epoch += 1
        self._clear_results()
        self.auto_key = None
        self.settings.reset(initial_values())
        self.schedule(0)

    def _on_before_save(self, *_args):
        try:
            save_to_scene(self.settings)
        except Exception:
            _log("could not save the settings with the scene\n" + traceback.format_exc())

    def invalidate(self):
        """Read and compute everything again (Refresh)."""
        for p in self.paths:
            self.gen[p] = self.gen.get(p, 0) + 1
        self.arrays.clear()
        self.parts.clear()
        self.mcache = core.MeasureCache()
        self.geo_key = None
        self.meas_key = None
        self.schedule(0)

    # -- texture size -----------------------------------------------------------------------

    def texture_size(self):
        st = self.settings
        if st.resolution == "CUSTOM":
            return max(1, st.res_x), max(1, st.res_y), None
        if st.resolution == "IMAGE":
            got = mayadata.uv_editor_image_size()
            if got is not None:
                return got[0], got[1], "UV Editor image"
            return max(1, st.res_x), max(1, st.res_y), None
        n = int(st.resolution)
        return n, n, None

    # -- the update -------------------------------------------------------------------------

    def update(self):
        """Read what changed and start computing (in the background when it takes a while).
        While a computation runs, another update waits for it."""
        if self._job is not None:
            self._again = True
            return
        self._updating = True
        try:
            self._update()
            self.error = None
        except Exception:
            self._fail(traceback.format_exc())
        finally:
            self._updating = False
        if self._job is None:
            self.geo_pending = self.meas_pending = False
            self.busy = ""
        try:
            self.updated.emit()
        except RuntimeError:
            self._dead()

    def sync(self):
        """Read the selection and the meshes that changed right now, when an update is still
        waiting for edits to pause: the UV tools work on what Maya has at this moment. (The
        shells follow with the update; geo_pending says they aren't current.)"""
        try:
            if not (self.active and self.timer.isActive()):
                return
            self._read()
            self.timer.start(0)
        except RuntimeError:
            self._dead()
        except Exception:
            self._fail(traceback.format_exc())

    def wait(self, timeout=60.0):
        """Wait for a running computation and take its results (tests, scripts)."""
        t_end = time.perf_counter() + timeout
        app = QtCore.QCoreApplication.instance()
        while self._job is not None and time.perf_counter() < t_end:
            if app is not None:
                app.processEvents()
            time.sleep(0.002)
        if app is not None:
            app.processEvents()
        return self._job is None

    def _fail(self, err):
        if err != self.error:
            _log("update failed:\n" + err)
        self.error = err

    def _read(self):
        t0 = time.perf_counter()
        shown = mayadata.shown_meshes()
        if self._rewatch:  # (not from inside the callback that asked for it)
            self._rewatch = False
            self._unwatch()
            self.paths = []
        if shown.paths != self.paths:
            self._watch(shown.paths)
            self.paths = list(shown.paths)
            keep = set(shown.paths)
            for d in (self.arrays, self.parts):
                for p in [p for p in d if p not in keep]:
                    del d[p]
        self.names = shown.names
        meshes, n_read = [], 0
        for path in self.paths:
            g = (self.gen.get(path, 0), self.xgen.get(path, 0))
            hit = self.arrays.get(path)
            c = self.content.get(path, (0, 0))
            try:
                if hit is None or hit[0][0] != g[0]:
                    A = mayadata.read_mesh(path, self.names.get(path))
                    n_read += 1
                    if hit is None:
                        c = (c[0] + 1, c[1] + 1)
                    else:
                        # Maya tells of more than changes (a node is marked dirty for many
                        # reasons): what reads the same keeps its results
                        uv, xyz = core.same_uv_data(hit[1], A), core.same_3d_data(hit[1], A)
                        if uv and xyz:
                            A = hit[1]
                        else:
                            c = (c[0] + (not uv), c[1] + (not xyz))
                elif hit[0][1] != g[1]:
                    A = mayadata.copy_with_matrix(hit[1], path)
                    if core.same_3d_data(hit[1], A):
                        A = hit[1]
                    else:
                        c = (c[0], c[1] + 1)
                else:
                    A = hit[1]
            except Exception:
                _log("could not read " + path + "\n" + traceback.format_exc())
                continue
            self.arrays[path] = (g, A)
            self.content[path] = c
            meshes.append(A)
        self.selection = shown.selection
        self.sels = shown.selection.uv_ids(self.arrays)
        sig = _selection_sig(shown.selection, self.paths)
        if sig != self._sel_sig:
            self._sel_sig = sig
            self.sel_version += 1
        self.timings["read"] = (_ms(t0), n_read, len(meshes))
        return meshes

    def _update(self):
        st = self.settings
        meshes = self._read()
        self.up = mayadata.up_axis()
        hidden = set(st.hidden)
        axes = core.up_axes(self.up)
        self.W, self.H, self.res_source = self.texture_size()
        self.component_selection = any(x is not None and len(x) for x in self.sels.values())

        job = _Job()
        job.epoch = self.epoch
        job.cache = self.mcache
        job.meshes = meshes
        job.want_orient, job.axes = True, axes  # (arrows are only shown or not: no work to toggle them)
        for A in meshes:
            c = self.content[A.key]
            # only the hidden sets this mesh has change what is extracted from it
            hid = tuple(sorted(k for k in hidden if k == "" or k in A.mat_keys)) if hidden else ()
            ekey = (c, hid, self.up)
            hit = self.parts.get(A.key)
            job.ekeys.append(ekey)
            job.hidden.append(hid)
            job.uv_sigs.append((A.key, c[0], hid))  # (moving the object or its points keeps its gaps)
            job.cached.append(hit[1] if hit is not None and hit[0] == ekey else None)
        geo_same = (self.geo_key is not None and all(P is not None for P in job.cached)
                    and tuple(P.serial for P in job.cached) == tuple(self.geo_key))
        job.cur_geo = self.geo if geo_same else None
        job.sels = dict(self.sels)
        job.same_mat = bool(st.same_material)
        job.stack_match = float(st.stack_match) / 100.0 if st.stacks else None
        skey = (job.same_mat, job.stack_match)
        mkey = None
        if st.show:
            job.measure = (self.W, self.H, int(st.points), float(st.shift) / 100.0, float(st.search_px),
                           bool(st.selected_only), bool(st.tile_border), bool(st.same_material), job.stack_match)
            mkey = job.measure
        if geo_same:
            self._apply_geometry(self.geo, False)
            sel_sig = self.geo.shell_sel.tobytes() if st.selected_only else None
            if mkey is None or not self.geo.nshells:
                self.meas = None
                self.meas_key = None
            stacks_ok = self.stacks_key == (self.geo_version,) + skey
            meas_ok = self.meas_key is None if (mkey is None or not self.geo.nshells) else \
                ((mkey, sel_sig) == self.meas_key and self.meas is not None)
            if stacks_ok and meas_ok:
                return  # nothing new to compute
        self.geo_pending = not geo_same
        self.meas_pending = mkey is not None
        self._start(job)

    def _start(self, job):
        self._job = job
        self.busy = "Finding shells" if job.cur_geo is None else "Measuring gaps"
        if self.threaded:
            threading.Thread(target=self._work, args=(job,), name="UVGapOverlay", daemon=True).start()
        else:
            self._work(job)

    # -- the background part ------------------------------------------------------------------

    def _post(self, kind, job, payload=None):
        if self.threaded:
            try:
                self._posted.emit((kind, job, payload))
            except RuntimeError:  # the engine is gone
                job.cancelled = True
        else:
            self._on_posted((kind, job, payload))

    def _work(self, job):
        """Runs in the worker thread: shells of the meshes that changed, the geometry and its
        stacks, then the gap measurement. Touches no Maya data, only the arrays read for it."""
        try:
            t0 = time.perf_counter()
            geo = job.cur_geo
            new_parts = {}
            n_all = len(job.meshes)
            if geo is None:
                parts = list(job.cached)
                todo = [i for i, P in enumerate(parts) if P is None]
                # meshes with the same hidden sets are extracted together
                by_hidden = {}
                for i in todo:
                    by_hidden.setdefault(job.hidden[i], []).append(i)
                for hid, idx in by_hidden.items():
                    got = core.extract_many([job.meshes[i] for i in idx], want_sel=False, want_td=True,
                                            want_orient=True, axes=job.axes, hidden=hid,
                                            uv_sigs=[job.uv_sigs[i] for i in idx], cancelled=lambda: job.cancelled)
                    if got is None:
                        return
                    for i, P in zip(idx, got):
                        parts[i] = P
                        new_parts[job.meshes[i].key] = (job.ekeys[i], P)
                geo = core.assemble(parts, True, True)
                geo.layer = core.build_layer(geo)
                core.apply_selection(geo, job.sels)  # (not shared yet)
            stacks = None
            if job.stack_match is not None and geo.nshells:
                stacks = core.find_stacks(geo, job.same_mat, job.stack_match, cache=job.cache)
            self._post("geo", job, (geo, new_parts, stacks, (_ms(t0), len(new_parts), n_all)))
            if job.measure is None or job.cancelled:
                return
            if not geo.nshells:
                self._post("meas", job, (geo, None, None, None, (0.0, 0, 0)))
                return
            t1 = time.perf_counter()
            W, H, points, shift, radius, sel_only, tiles, same_mat, smatch = job.measure
            sel = core.selected_shells(geo, job.sels)
            mgeo = core.with_selection(geo, sel[geo.gap_shell] if geo.gap_shell.size else geo.shell_sel)
            meas = core.measure(mgeo, W, H, points, shift, radius, sel_only, tiles, same_mat, cache=job.cache,
                                stack_match=smatch)
            stats = tuple(job.cache.stats)
            pairs = core.overlap_pairs(mgeo, same_mat, cache=job.cache, stack_match=smatch)
            self._post("meas", job, (geo, meas, pairs, mgeo.shell_sel.tobytes() if sel_only else None,
                                     (_ms(t1),) + stats))
        except Exception:
            self._post("error", job, traceback.format_exc())
        finally:
            self._post("done", job)

    # -- results, on the main thread -------------------------------------------------------------

    def _on_posted(self, msg):
        kind, job, payload = msg
        try:
            if kind == "done":
                if job is self._job:
                    self._job = None
                    if job.epoch == self.epoch:
                        self.geo_pending = self.meas_pending = False
                    self.busy = ""
                    if self._again:
                        self._again = False
                        self.geo_pending = True  # (an update is waiting: what is shown may be outdated)
                        self.schedule(0)
                    elif self.active:
                        self.updated.emit()
                return
            if job.epoch != self.epoch:
                return  # the scene changed meanwhile
            if kind == "error":
                self._fail(payload)
            elif kind == "geo":
                geo, new_parts, stacks, (ms, n_new, n_all) = payload
                for path, kp in new_parts.items():
                    if path in self.arrays:
                        self.parts[path] = kp
                if geo is not self.geo:
                    self.timings["shells"] = (ms, n_new, n_all)
                    self.last_geo_ms = ms
                self._apply_geometry(geo, True)
                self.stacks = stacks
                self.stacks_key = (self.geo_version, job.same_mat, job.stack_match)
                self.geo_pending = False
                self.busy = "Measuring gaps" if job.measure is not None else ""
                self.error = None
                self.updated.emit()
            elif kind == "meas":
                geo, meas, pairs, sel_sig, (ms, computed, total) = payload
                if geo is not self.geo:
                    return
                self.meas_version += 1
                if meas is not None:
                    meas.version = self.meas_version
                self.meas = meas
                self.meas_key = (job.measure, sel_sig)
                self.pairs, self.pairs_key = pairs, (self.geo_version, job.same_mat, job.stack_match)
                self.timings["gaps"] = (ms, computed, total)
                self.last_meas_ms = ms
                self.meas_pending = False
                self.updated.emit()
        except RuntimeError:
            self._dead()

    def _apply_geometry(self, geo, is_new):
        st = self.settings
        if is_new and geo is not self.geo:
            if list(geo.obj_keys) != list(self.geo.obj_keys):
                self.meas = None  # other objects: the old overlay doesn't belong on them
                self.meas_key = None
            self.geo = geo
            self.geo_key = geo.src_serials
            self.geo_version += 1
            self.pairs = None
            self.stacks = self.stacks_key = None
        self.sel_shells = core.apply_selection(self.geo, self.sels)
        tkey = (self.geo_version, self.W, self.H)
        if tkey != self.td_key:
            g = self.geo
            self.td = (core.td_values(g.td_uv_area, g.td_world_area, self.W, self.H, 1.0)
                       if g.td_nshells else np.full(g.sh_n, np.nan))
            self.td_key = tkey
            self.pub = core.published(tkey, self.td, core.td_factor(self.W, self.H, 1.0), g.sh_mat,
                                      g.mat_keys, g.mat_total, g.mat_vis)
        self.materials = core.listed_materials(self.pub)
        self._auto_fill()
        if not st.show:
            self.meas = None

    def _auto_fill(self):
        """Low / High from the checked material sets (all shells when none is checked) when the
        sets, the objects or the texture size changed - only while texel density is shown."""
        st = self.settings
        if not (st.td_auto_range and (st.td_show or st.td_show_3d)) or self.pub is None:
            return
        checked = tuple(sorted(k for k in st.checked if k in self.materials))
        kc = core.td_factor(self.W, self.H, 1.0)
        fkey = (tuple(self.paths), checked, round(kc, 6))  # not on every edit: on what the fill is for
        if fkey == self.auto_key:
            return
        rng = core.auto_range(self.pub, checked, kc)
        if rng is None:
            return
        self.auto_key = fkey
        if abs(rng[0] - st.td_low_m) > 1e-6 * max(1.0, rng[0]) or abs(rng[1] - st.td_high_m) > 1e-6 * max(1.0, rng[1]):
            st.update({"td_low_m": rng[0], "td_high_m": rng[1]})

    # -- for the panel ----------------------------------------------------------------------

    def fill_range(self):
        """Fill Low / High now. Returns False when there is no density to fill from."""
        st = self.settings
        if self.pub is None:
            return False
        checked = tuple(sorted(k for k in st.checked if k in self.materials))
        rng = core.auto_range(self.pub, checked, core.td_factor(self.W, self.H, 1.0))
        if rng is None:
            return False
        st.update({"td_low_m": rng[0], "td_high_m": rng[1]})
        return True

    def td_stats(self):
        return core.td_stats(self.td, self.settings.thresholds()) if self.td.size else None

    def summary(self):
        """Counts for the panel."""
        geo, m = self.geo, self.meas
        out = {"objects": len(self.paths), "shells": geo.sh_n, "faces": geo.nfaces,
               "flipped": int(geo.flipped.sum()) if geo.flipped.size else 0}
        if self.stacks is not None and self.stacks.rep.size == geo.nshells:
            out["stacks"], out["stacked"] = self.stacks.counts()
        if m is not None:
            st = self.settings
            out.update(sampled=m.shells_sampled, gaps=int(m.dist.size), overlaps=m.overlap_pairs,
                       tile_crossing=m.tile_crossing,
                       below_min=int(np.count_nonzero(m.dist < st.min_px)) +
                       int(np.count_nonzero(m.bdist < st.border_min_px)),
                       below_needed=int(np.count_nonzero(m.dist < st.needed_px)) +
                       int(np.count_nonzero(m.bdist < st.border_needed_px)),
                       smallest=float(min(m.dist.min(initial=np.inf), m.bdist.min(initial=np.inf))))
        return out

    def timing_text(self):
        """How long the last update's steps took, for the panel."""
        t = self.timings
        parts = []
        if "read" in t:
            ms, n, total = t["read"]
            parts.append("read %s%s" % (_fmt_ms(ms), (" (%d of %d meshes)" % (n, total)) if n and n != total else ""))
        if "shells" in t:
            ms, n, total = t["shells"]
            parts.append("shells %s%s" % (_fmt_ms(ms), (" (%d of %d objects)" % (n, total)) if n != total else ""))
        if "gaps" in t:
            ms, n, total = t["gaps"]
            parts.append("gaps %s%s" % (_fmt_ms(ms), (" (%d of %d materials)" % (n, total)) if total > 1 and n != total else ""))
        if "draw" in t:
            parts.append("draw %s" % _fmt_ms(t["draw"]))
        return ", ".join(parts)

    # -- overlapping shells -------------------------------------------------------------------

    def stack_params(self):
        st = self.settings
        return bool(st.same_material), (float(st.stack_match) / 100.0 if st.stacks else None)

    def current_stacks(self):
        """The stacks of the current geometry (core.Stacks, or None when stacks are off):
        from the last update when it has them, else found now."""
        same_mat, smatch = self.stack_params()
        if smatch is None or not self.geo.nshells:
            return None
        key = (self.geo_version, same_mat, smatch)
        if self.stacks is None or self.stacks_key != key:
            cache = self.mcache if self._job is None else None
            self.stacks = core.find_stacks(self.geo, same_mat, smatch, cache=cache)
            self.stacks_key = key
        return self.stacks

    def overlapping_pairs(self):
        """Overlapping shell pairs (core.Pairs, gap-shell indices) of the current geometry -
        between different stacks when stacks are on, of the same material only with Same
        Material Only. From the last measurement when it has them, else found now."""
        same_mat, smatch = self.stack_params()
        key = (self.geo_version, same_mat, smatch)
        if self.pairs is not None and self.pairs_key == key:
            return self.pairs
        cache = self.mcache if self._job is None else None
        self.pairs = core.overlap_pairs(self.geo, same_mat, cache=cache, stack_match=smatch)
        self.pairs_key = key
        return self.pairs

    # -- selections -------------------------------------------------------------------------

    def _target_kind(self):
        return "face" if mayadata.face_mode() else "uv"

    def select_shells(self, shells, mode="replace", kind=None):
        """Select shells (all-shell indices) in Maya: their UVs, or their faces while faces are
        being selected. Returns the number of shells."""
        shells = np.asarray(shells, dtype=np.int64)
        kind = kind or self._target_kind()
        per = []
        for path_i, (uv, faces) in enumerate(core.components_of_shells(self.geo, shells)):
            path = self.geo.obj_keys[path_i]
            per.append((path, uv if kind == "uv" else faces))
        self.select_components(per, kind, mode)
        return int(np.unique(shells).size)

    def select_components(self, per_object, kind, mode="replace"):
        """Select components of the shown meshes: per_object [(shape path, ids)], kind 'uv',
        'face', 'edge' or 'vertex'."""
        cmds.undoInfo(openChunk=True, chunkName="UV Gap Overlay: select")
        try:
            # the shown meshes stay shown: those selected as whole objects would drop out with the
            # object selection, so they go into component mode first (as in the UV Editor)
            hilited = self.selection.hilited
            transforms = sorted({p.rsplit("|", 1)[0] for p in self.paths if p.count("|") > 1 and p not in hilited})
            if transforms:
                cmds.hilite(transforms)
            mayadata.select_components(per_object, kind, mode)
        finally:
            cmds.undoInfo(closeChunk=True)

    def material_shells(self, keys):
        return core.shells_of_sets(self.geo, keys)

    def range_shells(self):
        st = self.settings
        return core.shells_in_range(self.td, st.td_sel_from / 100.0, st.td_sel_to / 100.0)

    def set_hidden(self, keys, hide):
        hidden = set(self.settings.hidden)
        hidden = (hidden | set(keys)) if hide else (hidden - set(keys))
        self.settings.update({"hidden": tuple(sorted(hidden))})

    def save_settings_to_scene(self):
        save_to_scene(self.settings)


def _selection_sig(sel, paths):
    parts = [tuple(paths), tuple(sorted(sel.objects)), tuple(sorted(sel.hilited))]
    for p in sorted(sel.comps):
        for k in sorted(sel.comps[p]):
            parts.append((p, k, np.asarray(sel.comps[p][k]).tobytes()))
    return hash(tuple(parts))


def _fmt_ms(ms):
    return ("%.0f ms" % ms) if ms < 950.0 else ("%.1f s" % (ms / 1000.0))
