# SPDX-License-Identifier: GPL-3.0-or-later
#
# UV Shell Gap Overlay for Maya - settings: saved with the scene (fileInfo), with your own
# defaults for new scenes (optionVar). What belongs to this computer rather than to a scene
# (drawing the view on the GPU) is kept apart, in an optionVar of its own.
#
# Authors: Iurii Kruglov & Claude (Anthropic)

import base64
import json

from . import core

FILE_INFO_KEY = "uvGapOverlay"
OPTION_VAR = "uvGapOverlayDefaults"
LOCAL_VAR = "uvGapOverlayLocal"
VERSION = 1

RESOLUTIONS = ("256", "512", "1024", "2048", "4096", "8192", "CUSTOM", "IMAGE")

DEFAULTS = {
    "show": True,
    # texture size
    "resolution": "2048",
    "res_x": 2048,
    "res_y": 2048,
    # measurement points
    "points": 24,
    "shift": 0.0,
    # shell-to-shell gaps
    "min_px": 4.0,
    "needed_px": 8.0,
    "search_px": 32.0,
    "selected_only": False,
    "same_material": True,
    # stacks: shells lying on each other on purpose count as one shell
    "stacks": True,
    "stack_match": 99.9,
    "stack_tiles": 1,
    "stack_home_only": True,
    # UDIM tile borders
    "tile_border": True,
    "border_min_px": 2.0,
    "border_needed_px": 4.0,
    # flipped shells
    "show_flipped": True,
    # display
    "font_size": 12,
    "opacity": 0.9,
    "line_width": 2.0,
    "label_background": True,
    "declutter": True,
    "show_wire": True,
    "show_grid": True,
    # colors
    "color_overlap": (1.0, 0.2, 0.9),
    "color_zero": (1.0, 0.1, 0.1),
    "color_min": (1.0, 0.8, 0.1),
    "color_needed": (0.25, 0.95, 0.35),
    "color_flipped": (0.2, 0.65, 1.0),
    # texel density (stored in px/m whatever the unit shown)
    "td_show": False,
    "td_show_3d": False,
    "td_unit": "PX_M",
    "td_needed_m": 300.0,
    "td_low_m": 100.0,
    "td_high_m": 500.0,
    "td_fill_opacity": 0.35,
    "td_auto_range": True,
    "td_sel_from": 0.0,
    "td_sel_to": 100.0,
    "td_range_highlight": True,
    # per-shell info blocks
    "info_show": True,
    "show_orientation": False,
    "show_scale": True,
    # material sets (keys: material names, "" for faces without one)
    "checked": (),
    "hidden": (),
    # UV tools: what a click picks, step sizes, pivot
    "sel_mode": "SHELL",
    "move_amount": 1.0,
    "move_unit": "UV",
    "rotate_angle": 90.0,
    "scale_factor": 2.0,
    "pivot": "SELECTION",
    "weld_dist": 1.0,
    "weld_unit": "PX",
    "show_selection": True,
    "gpu_view": True,
}

# settings of this computer, not of a scene: never saved with scenes or defaults, and resets
# leave them alone
LOCAL = ("gpu_view",)

SEL_MODES = ("UV", "EDGE", "FACE", "SHELL")
UNITS = ("UV", "PX")
PIVOTS = ("SELECTION", "SHELL")

# value limits (min, max)
LIMITS = {
    "res_x": (1, 65536), "res_y": (1, 65536),
    "points": (1, 512), "shift": (0.0, 100.0),
    "min_px": (0.0, 4096.0), "needed_px": (0.0, 4096.0), "search_px": (0.1, 4096.0),
    "border_min_px": (0.0, 4096.0), "border_needed_px": (0.0, 4096.0),
    "font_size": (6, 72), "opacity": (0.0, 1.0), "line_width": (1.0, 10.0),
    "td_needed_m": (0.0, 1e9), "td_low_m": (0.0, 1e9), "td_high_m": (0.0, 1e9),
    "td_fill_opacity": (0.0, 1.0), "td_sel_from": (0.0, 100.0), "td_sel_to": (0.0, 100.0),
    "move_amount": (0.0, 1e6), "rotate_angle": (-360.0, 360.0), "scale_factor": (1e-4, 1e4),
    "weld_dist": (0.0, 1e6), "stack_match": (50.0, 100.0), "stack_tiles": (-99, 99),
}

_CHOICES = {"resolution": RESOLUTIONS, "sel_mode": SEL_MODES, "move_unit": UNITS, "weld_unit": UNITS,
            "pivot": PIVOTS}


def _clean(key, value):
    """`value` converted to the type of the default and kept within limits; None if unusable."""
    default = DEFAULTS[key]
    try:
        if isinstance(default, bool):
            v = bool(value)
        elif isinstance(default, int):
            v = int(round(float(value)))
        elif isinstance(default, float):
            v = float(value)
            if v != v:  # NaN
                return None
        elif isinstance(default, str):
            v = str(value)
            if key in _CHOICES and v not in _CHOICES[key]:
                return None
            if key == "td_unit" and v not in core.TD_FACTOR:
                return None
        elif key.startswith("color_"):
            v = tuple(max(0.0, min(1.0, float(c))) for c in value)
            if len(v) != 3:
                return None
        else:  # material key lists
            v = tuple(str(k) for k in value)
    except (TypeError, ValueError):
        return None
    lim = LIMITS.get(key)
    if lim is not None:
        v = type(v)(max(lim[0], min(lim[1], v)))
    return v


class Settings(object):
    """Overlay settings as attributes (the names of the Blender add-on's settings, so the
    shared code reads them the same way). Change them with set(); listeners get the names."""

    def __init__(self, values=None):
        object.__setattr__(self, "_listeners", [])
        for k, v in DEFAULTS.items():
            object.__setattr__(self, k, v)
        if values:
            self.update(values, notify=False)

    def __setattr__(self, name, value):
        if name in DEFAULTS:
            self.set(**{name: value})
        else:
            object.__setattr__(self, name, value)

    def add_listener(self, fn):
        if fn not in self._listeners:
            self._listeners.append(fn)

    def remove_listener(self, fn):
        if fn in self._listeners:
            self._listeners.remove(fn)

    def set(self, **values):
        return self.update(values)

    def update(self, values, notify=True):
        """Apply known, valid values; returns the names that changed."""
        changed = []
        for k, v in values.items():
            if k not in DEFAULTS:
                continue
            v = _clean(k, v)
            if v is None or v == getattr(self, k):
                continue
            object.__setattr__(self, k, v)
            changed.append(k)
        # the range handles don't pass each other
        if self.td_sel_to < self.td_sel_from:
            if "td_sel_to" in changed and "td_sel_from" not in changed:
                object.__setattr__(self, "td_sel_from", self.td_sel_to)
                changed.append("td_sel_from")
            else:
                object.__setattr__(self, "td_sel_to", self.td_sel_from)
                changed.append("td_sel_to")
        if changed and notify:
            for fn in list(self._listeners):
                fn(tuple(changed))
        return tuple(changed)

    def values(self):
        return {k: getattr(self, k) for k in DEFAULTS}

    def reset(self, values=None):
        """All settings back to `values` (missing ones: factory defaults). This computer's
        settings (LOCAL) stay as they are."""
        target = dict(DEFAULTS)
        if values:
            for k, v in values.items():
                if k in DEFAULTS:
                    c = _clean(k, v)
                    if c is not None:
                        target[k] = c
        for k in LOCAL:
            target[k] = getattr(self, k)
        return self.update(target)

    # texel densities in the unit shown
    def td_factor(self):
        return core.TD_FACTOR.get(self.td_unit, 1.0)

    def td_label(self):
        return core.TD_LABEL.get(self.td_unit, "px/m")

    def thresholds(self):
        """(low, needed, high) in px/m."""
        return float(self.td_low_m), float(self.td_needed_m), float(self.td_high_m)

    # -- storage -----------------------------------------------------------------------------

    def to_text(self, keys=None):
        """The settings as text for fileInfo / optionVar: all but this computer's, or `keys`."""
        data = {k: (list(v) if isinstance(v, tuple) else v) for k, v in self.values().items()
                if (k in keys if keys is not None else k not in LOCAL)}
        data["_version"] = VERSION
        raw = json.dumps(data, sort_keys=True, separators=(",", ":")).encode("utf-8")
        return base64.b64encode(raw).decode("ascii")  # no quotes or backslashes for fileInfo

    @staticmethod
    def parse(text):
        """Values from to_text(), or None."""
        try:
            data = json.loads(base64.b64decode(str(text).encode("ascii")).decode("utf-8"))
        except Exception:
            return None
        return data if isinstance(data, dict) else None


def load_user_defaults():
    """Your defaults for new scenes (optionVar), or None."""
    try:
        from maya import cmds
        if cmds.optionVar(exists=OPTION_VAR):
            return Settings.parse(cmds.optionVar(q=OPTION_VAR))
    except Exception:
        pass
    return None


def save_user_defaults(settings):
    from maya import cmds
    values = Settings(settings.values())
    values.update({"checked": (), "hidden": ()}, notify=False)  # material names belong to a scene
    cmds.optionVar(stringValue=(OPTION_VAR, values.to_text()))


def clear_user_defaults():
    from maya import cmds
    if cmds.optionVar(exists=OPTION_VAR):
        cmds.optionVar(remove=OPTION_VAR)


def load_scene_values():
    """Settings saved with the open scene, or None."""
    try:
        from maya import cmds
        got = cmds.fileInfo(FILE_INFO_KEY, q=True)
    except Exception:
        return None
    if not got:
        return None
    return Settings.parse(got[0] if isinstance(got, (list, tuple)) else got)


def save_to_scene(settings):
    from maya import cmds
    cmds.fileInfo(FILE_INFO_KEY, settings.to_text())


def load_local():
    """This computer's settings (LOCAL), as far as they were saved."""
    try:
        from maya import cmds
        if cmds.optionVar(exists=LOCAL_VAR):
            data = Settings.parse(cmds.optionVar(q=LOCAL_VAR)) or {}
            return {k: data[k] for k in LOCAL if k in data}
    except Exception:
        pass
    return {}


def save_local(settings):
    try:
        from maya import cmds
        cmds.optionVar(stringValue=(LOCAL_VAR, settings.to_text(keys=LOCAL)))
    except Exception:
        pass


def initial_values():
    """For a scene: its saved settings, else your defaults, else the factory defaults - with
    this computer's own settings."""
    values = dict(load_scene_values() or load_user_defaults() or {})
    for k in LOCAL:
        values.pop(k, None)
    values.update(load_local())
    return values
