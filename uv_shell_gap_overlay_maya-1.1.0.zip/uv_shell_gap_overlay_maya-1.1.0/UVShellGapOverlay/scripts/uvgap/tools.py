# SPDX-License-Identifier: GPL-3.0-or-later
#
# UV Shell Gap Overlay for Maya - the UV tools: selecting components and overlapping shells
# from the UV view, cutting and welding, moving / rotating / scaling the selected UVs. Every
# edit is one of Maya's own UV commands (polyEditUV, polyMapCut, polyMapSew, polyMergeUV) in
# one undo step.
#
# Authors: Iurii Kruglov & Claude (Anthropic)

import numpy as np

from . import core, mayadata

try:
    import maya.api.OpenMaya as om
except Exception:  # outside Maya
    om = None


def info(msg):
    if om is not None:
        om.MGlobal.displayInfo("UV Gaps: " + msg)
    else:
        print("UV Gaps: " + msg)


def warn(msg):
    if om is not None:
        om.MGlobal.displayWarning("UV Gaps: " + msg)
    else:
        print("UV Gaps warning: " + msg)


def _plural(n, word):
    return "%d %s%s" % (n, word, "" if n == 1 else "s")


# ---------------------------------------------------------------------------
# What is selected
# ---------------------------------------------------------------------------

BUSY = "the shells are still being read: try again in a moment"


def selected_uvs(engine, whole_objects=True):
    """[(shape path, UV ids)] of what is selected: the UVs of selected components; with
    `whole_objects`, every UV of meshes selected as objects."""
    engine.sync()  # (what Maya has now, also while an update waits for edits to pause)
    out = []
    for path in engine.paths:
        hit = engine.arrays.get(path)
        if hit is None:
            continue
        A = hit[1]
        ids = engine.sels.get(path, np.zeros(0, dtype=np.int64))
        if ids is None:
            if not whole_objects:
                continue
            ids = np.unique(A.uv_id[A.uv_id >= 0])
        if len(ids):
            out.append((path, np.asarray(ids, dtype=np.int64)))
    return out


def uv_positions(engine, per_object):
    """(n, 2) UVs of [(path, UV ids)]."""
    pts = [engine.arrays[p][1].uv_table[ids] for p, ids in per_object if p in engine.arrays]
    return np.concatenate(pts) if pts else np.zeros((0, 2))


def selection_center(engine, per_object):
    P = uv_positions(engine, per_object)
    if not P.shape[0]:
        return None
    return (P.min(axis=0) + P.max(axis=0)) * 0.5


def shell_groups(engine, per_object):
    """[(per_object, pivot)]: the selected UVs split by shell, each with its shell's center
    (the middle of its selected UVs)."""
    geo, L = engine.geo, engine.geo.layer
    groups = {}
    oi = core.object_index(geo)
    for path, ids in per_object:
        A = engine.arrays[path][1]
        o = oi.get(path)
        shell = np.full(ids.size, -1, dtype=np.int64)
        if o is not None and L is not None:
            a, b = int(L.obj_pt_off[o]), int(L.obj_pt_off[o + 1])
            pu = L.pt_uvid[a:b].astype(np.int64)
            lut = np.full(int(max(pu.max(initial=0), ids.max(initial=0))) + 1, -1, dtype=np.int64)
            lut[pu] = L.pt_shell[a:b]
            shell = lut[ids]
        for s in np.unique(shell).tolist():
            sel = ids[shell == s]
            groups.setdefault(s, []).append((path, sel, A.uv_table[sel]))
    out = []
    for s, items in groups.items():
        P = np.concatenate([x[2] for x in items])
        out.append(([(p, i) for p, i, _x in items], tuple(((P.min(axis=0) + P.max(axis=0)) * 0.5).tolist())))
    return out


def _amount_uv(engine, amount, unit):
    """(du, dv) of an amount in UV units or texture pixels."""
    if unit == "PX":
        return amount / float(max(engine.W, 1)), amount / float(max(engine.H, 1))
    return float(amount), float(amount)


# ---------------------------------------------------------------------------
# Selecting
# ---------------------------------------------------------------------------

def shell_kind(engine):
    """Shells are selected as faces in face mode (ours or Maya's), else as UVs."""
    return "face" if engine.settings.sel_mode == "FACE" or mayadata.face_mode() else "uv"


def _overlap_data(engine):
    """(pairs, stacks) of the shown shells, or None when there are none."""
    engine.sync()
    if engine.geo_pending:  # (the shells shown aren't those of the meshes as they are now)
        warn(BUSY)
        return None
    if not engine.geo.nshells:
        warn("no shells shown")
        return None
    return engine.overlapping_pairs(), engine.current_stacks()


def select_overlapping(engine, mode="replace"):
    """Select the shells that overlap and aren't a stack: copies that don't fit, shells lying
    partly on others (with all the shells of the stacks involved)."""
    got = _overlap_data(engine)
    if got is None:
        return 0
    pairs, stacks = got
    shells = core.overlapping_shells(engine.geo, pairs, stacks)
    if not shells.size:
        info("no overlapping shells" + (" (stacks aside)" if stacks is not None else ""))
        if mode == "replace":
            engine.select_components([], "uv", "replace")
        return 0
    n = engine.select_shells(shells, mode, kind=shell_kind(engine))
    info("%s selected (%s)" % (_plural(n, "overlapping shell"), _plural(len(pairs), "overlapping pair")))
    return n


def select_stacked(engine, mode="replace"):
    """Select every shell that lies in a stack (shells sharing texture space on purpose)."""
    got = _overlap_data(engine)
    if got is None:
        return 0
    stacks = got[1]
    if stacks is None:
        warn("stacks are off: turn on Stacked Shells as One")
        return 0
    g = np.flatnonzero(stacks.size > 1)
    if not g.size:
        info("no stacked shells")
        return 0
    n = engine.select_shells(engine.geo.gap_shell[g], mode, kind=shell_kind(engine))
    info("%s selected in %s" % (_plural(n, "stacked shell"), _plural(stacks.counts()[0], "stack")))
    return n


def but_one(engine):
    """All-shell indices of every shell lying on another but one per stack or set of
    overlapping shells: the one that stays isn't flipped (where there is such a shell). With
    Only in the 0-1 Tile, only shells of that tile: copies moved away earlier are left alone."""
    got = _overlap_data(engine)
    if got is None:
        return np.zeros(0, dtype=np.int64)
    pairs, stacks = got
    geo = engine.geo
    shells = core.overlaps_but_one(geo, pairs, stacks)
    if engine.settings.stack_home_only and shells.size:
        gid = geo.sh_gid[shells]
        tile = geo.tile[np.maximum(gid, 0)]
        shells = shells[(gid >= 0) & (tile[:, 0] == 0) & (tile[:, 1] == 0)]
    return shells


def _where(engine):
    return " in the 0-1 tile" if engine.settings.stack_home_only else ""


def select_but_one(engine, mode="replace"):
    """Select all the shells lying on others but one of each stack / set of overlapping
    shells - an unflipped shell stays unselected."""
    shells = but_one(engine)
    if not shells.size:
        if engine.geo.nshells and not engine.geo_pending:
            info("no shells lie on each other" + _where(engine))
        return 0
    n = engine.select_shells(shells, mode, kind=shell_kind(engine))
    info("%s selected: one shell of every stack and overlap stays" % _plural(n, "shell"))
    return n


def move_but_one(engine):
    """Move all the shells lying on others but one of each stack / set of overlapping shells
    to another UDIM tile (Tiles: how many tiles along U), and select them. One undo step."""
    shells = but_one(engine)
    if not shells.size:
        if engine.geo.nshells and not engine.geo_pending:
            info("no shells lie on each other%s: nothing to move" % _where(engine))
        return 0
    tiles = int(engine.settings.stack_tiles)
    if not tiles:
        warn("Tiles is 0: nothing to move")
        return 0
    geo = engine.geo
    per = [(geo.obj_keys[i], uv) for i, (uv, _f) in enumerate(core.components_of_shells(geo, shells)) if uv.size]
    with mayadata.Chunk("move copies to another tile"):
        engine.select_shells(shells, "replace", kind="uv")
        mayadata.move_uvs(per, float(tiles), 0.0)
    engine.mesh_edited([p for p, _i in per])
    info("%s moved %d tile%s along U; one shell of every stack and overlap stays" % (
        _plural(int(shells.size), "shell"), tiles, "" if abs(tiles) == 1 else "s"))
    return int(shells.size)


def select_picked(engine, kind, per_object, mode):
    """Select picked components: kind 'uv', 'edge', 'face'; per_object [(path, ids)]."""
    engine.select_components([(p, ids) for p, ids in per_object if len(ids)], kind, mode)


def corner_edges(engine, corners):
    """[(path, mesh edge ids)] of layer corners (the edge from each corner to the next)."""
    L, geo = engine.geo.layer, engine.geo
    nxt = L.corner_next()
    out = []
    for o, local in core.per_object(L, corners, L.obj_corner_off):
        c = local + L.obj_corner_off[o]
        path = geo.obj_keys[o]
        faces = L.face_id[L.corner_face[c]]
        e = mayadata.edges_of_corners(path, faces, L.corner_vert[c], L.corner_vert[nxt[c]])
        out.append((path, np.unique(e[e >= 0])))
    return out


# ---------------------------------------------------------------------------
# Cut / weld
# ---------------------------------------------------------------------------

def cut(engine):
    """Cut the UVs along the selected edges (the border of selected faces, the edges between
    selected UVs)."""
    edges = mayadata.edges_to_cut(mayadata.selection_strings())
    if not edges:
        warn("nothing to cut: select edges, or faces to cut out")
        return 0
    mayadata.cut_edges(edges)
    engine.mesh_edited(engine.paths)
    info("cut along the selected edges")
    return len(edges)


def weld(engine):
    """Weld the selection: selected edges are sewn; selected UVs (faces, vertices) are merged
    where they belong to the same vertex, however far apart."""
    items = mayadata.selection_strings()
    edges = [s for s in items if ".e[" in s]
    if edges:
        mayadata.sew_edges(edges)
        engine.mesh_edited(engine.paths)
        info("sewed the selected edges")
        return len(edges)
    per = selected_uvs(engine, whole_objects=False)
    if not per:
        warn("nothing to weld: select edges or UVs")
        return 0
    mayadata.merge_uvs(per, 1e9)
    engine.mesh_edited([p for p, _i in per])
    info("welded the selected UVs")
    return len(per)


def weld_within(engine):
    """Merge UVs of the same vertex closer than the Weld distance (selected UVs, or every UV
    of meshes selected as objects)."""
    st = engine.settings
    per = selected_uvs(engine)
    if not per:
        warn("nothing to weld: select meshes or UVs")
        return 0
    d = _amount_uv(engine, st.weld_dist, st.weld_unit)
    dist = min(d)  # (a pixel is the smaller UV step on non-square textures)
    mayadata.merge_uvs(per, dist)
    engine.mesh_edited([p for p, _i in per])
    info("welded UVs closer than %g %s" % (st.weld_dist, "px" if st.weld_unit == "PX" else "UV"))
    return len(per)


# ---------------------------------------------------------------------------
# Move / rotate / scale
# ---------------------------------------------------------------------------

def _need(engine):
    per = selected_uvs(engine)
    if not per:
        warn("nothing selected: select UVs, faces, edges, shells or meshes")
    return per


def move(engine, du, dv, per=None):
    per = per if per is not None else _need(engine)
    if not per or not (du or dv):
        return 0
    mayadata.move_uvs(per, du, dv)
    engine.mesh_edited([p for p, _i in per])
    return len(per)


def move_step(engine, direction):
    """Move the selection by the Move amount: direction 'left', 'right', 'up' or 'down'."""
    st = engine.settings
    su, sv = _amount_uv(engine, st.move_amount, st.move_unit)
    du, dv = {"left": (-su, 0.0), "right": (su, 0.0), "up": (0.0, sv), "down": (0.0, -sv)}[direction]
    return move(engine, du, dv)


def _groups(engine, per, pivot=None):
    if engine.settings.pivot == "SHELL" and pivot is None:
        if engine.geo_pending:
            warn(BUSY)
            return []
        return shell_groups(engine, per)
    c = pivot if pivot is not None else selection_center(engine, per)
    return [(per, tuple(float(x) for x in c))] if c is not None else []


def rotate(engine, angle, per=None, pivot=None):
    """Rotate the selection by `angle` degrees, counterclockwise."""
    per = per if per is not None else _need(engine)
    if not per or not angle:
        return 0
    groups = _groups(engine, per, pivot)
    if not groups:
        return 0
    mayadata.rotate_uvs(groups, angle)
    engine.mesh_edited([p for p, _i in per])
    return len(groups)


def scale(engine, su, sv, per=None, pivot=None):
    per = per if per is not None else _need(engine)
    if not per or (su == 1.0 and sv == 1.0):
        return 0
    groups = _groups(engine, per, pivot)
    if not groups:
        return 0
    mayadata.scale_uvs(groups, su, sv)
    engine.mesh_edited([p for p, _i in per])
    return len(groups)
