# SPDX-License-Identifier: GPL-3.0-or-later
#
# UV Shell Gap Overlay for Maya - the UV view: the shown meshes' UV layout with the gap
# overlay, texel density colors, info blocks and labels, and the UV tools: selecting UVs,
# edges, faces or shells (click, drag a rectangle), moving / rotating / scaling the selection.
#
# ViewBase holds what both views share (navigation, picking, tools, label layout);
# PainterView draws with QPainter, GLView (glview.py) on the GPU.
#
# Navigation: wheel / Alt+RMB zoom, MMB / Alt+MMB pan, F frame selected, A frame all.
# Tools: Q select, W move, E rotate, R scale. What a click picks: 1 UV, 2 edge, 3 face, 4 shell.
# Shift toggles, Ctrl deselects, Ctrl+Shift adds (as in Maya). With a transform tool, dragging
# the manipulator transforms the selected UVs; a click or a drag beside it selects.
#
# Authors: Iurii Kruglov & Claude (Anthropic)

import math
import time
import traceback

import numpy as np

from . import core, tools
from .qtcompat import QtCore, QtGui, QtWidgets, Qt, color, event_pos, path_from_points, segments_path

BG = QtGui.QColor(43, 43, 43)
GRID = QtGui.QColor(255, 255, 255, 22)
GRID_TILE = QtGui.QColor(255, 255, 255, 60)
GRID_HOME = QtGui.QColor(255, 255, 255, 120)
WIRE = QtGui.QColor(190, 190, 190, 70)
BORDER = QtGui.QColor(225, 225, 225, 170)
SELECTED = QtGui.QColor(255, 160, 40, 230)
TEXT = QtGui.QColor(220, 220, 220)
SEL_RGB = (1.0, 0.63, 0.16)
PREVIEW_RGB = (0.35, 0.85, 1.0)
UV_STEPS = 16  # texel density fill: color steps per hue sextant
PICK_PX = 8.0  # how near a click must be to a UV or an edge
HANDLE_PX = 70.0  # the manipulator's arrows, the Rotate ring's radius
FREE_PX = 13.0    # half the manipulator's middle (dragging it moves / scales freely)
MAX_MARKS = 20000  # overlap crosses drawn at most (evenly thinned beyond)

TOOLS = ("select", "move", "rotate", "scale")
TOOL_KEYS = {Qt.Key.Key_Q: "select", Qt.Key.Key_W: "move", Qt.Key.Key_E: "rotate", Qt.Key.Key_R: "scale"}
MODE_KEYS = {Qt.Key.Key_1: "UV", Qt.Key.Key_2: "EDGE", Qt.Key.Key_3: "FACE", Qt.Key.Key_4: "SHELL",
             Qt.Key.Key_F9: "UV", Qt.Key.Key_F10: "EDGE", Qt.Key.Key_F11: "FACE", Qt.Key.Key_F12: "UV"}


class QtMetrics(object):
    """Text size for core.build_labels from a QFont."""

    def __init__(self, font):
        fm = QtGui.QFontMetricsF(font)
        self.th = float(fm.tightBoundingRect("0123456789").height()) or float(fm.ascent()) * 0.72
        self._adv = getattr(fm, "horizontalAdvance", None) or fm.width

    def width(self, text):
        return float(self._adv(text))


def _qcolor(rgb, a):
    return color(rgb, a)


def _groups(rgb, step=1.0 / 48.0):
    """(group of each color, the groups' colors): colors rounded to `step`."""
    q = np.clip(np.rint(np.asarray(rgb, dtype=np.float64).reshape(-1, 3) / step), 0, 63).astype(np.int64)
    if not q.shape[0]:
        return np.zeros(0, dtype=np.int64), np.zeros((0, 3))
    key = (q[:, 0] * 64 + q[:, 1]) * 64 + q[:, 2]
    uk, inv = np.unique(key, return_inverse=True)
    uq = np.column_stack((uk // 4096, (uk // 64) % 64, uk % 64)) * step
    return np.asarray(inv).reshape(-1), uq


def _rects(x, y, w, h):
    """QRectFs (top-left corners, sizes) from arrays or numbers."""
    n = max(np.size(x), np.size(y), np.size(w), np.size(h))
    cols = [np.broadcast_to(np.asarray(c, dtype=np.float64), (n,)).tolist() for c in (x, y, w, h)]
    return [QtCore.QRectF(a, b, c, d) for a, b, c, d in zip(*cols)]


def thin(P, limit=MAX_MARKS):
    """At most `limit` of the points, evenly spread."""
    if P.shape[0] <= limit:
        return P
    return P[np.linspace(0, P.shape[0] - 1, limit).astype(np.int64)]


def _flip_y(P, h):
    out = np.array(P, dtype=np.float64).reshape(-1, 2)
    out[:, 1] = h - out[:, 1]
    return out


class _Frame(object):
    """Everything drawn in widget pixels for one view of the data."""
    __slots__ = ("lines", "fills", "boxes", "arrows", "texts", "hl")


class SelDisplay(object):
    """The selection in layer terms: points, edges ((k, 2) point pairs), faces, gap shells to
    outline."""
    __slots__ = ("points", "edges", "faces", "shells")

    def __init__(self):
        self.points = np.zeros(0, dtype=np.int64)
        self.edges = np.zeros((0, 2), dtype=np.int64)
        self.faces = np.zeros(0, dtype=np.int64)
        self.shells = np.zeros(0, dtype=np.int64)


class Transform(object):
    """A move / rotate / scale being dragged (or just applied, until the edit comes back)."""
    __slots__ = ("kind", "per", "pts", "pivot", "pivots", "du", "dv", "angle", "su", "sv", "axis",
                 "start", "ref", "edges", "geo_version", "applied")

    def __init__(self, kind):
        self.kind = kind
        self.per = []
        self.pts = np.zeros(0, dtype=np.int64)    # layer points that move
        self.pivot = np.zeros(2)                  # the manipulator's pivot (UV)
        self.pivots = np.zeros((0, 2))            # per moving point (shell centers with Each Shell)
        self.du = self.dv = self.angle = 0.0
        self.su = self.sv = 1.0
        self.axis = None                          # None (free), 0 (U only), 1 (V only)
        self.start = None
        self.ref = None                           # Rotate: the direction the angle is counted from
        self.edges = np.zeros((0, 2), dtype=np.int64)  # UV edges touching moving points
        self.geo_version = -1
        self.applied = False

    def apply_to(self, P, pivots):
        """The transform applied to points P with their pivots."""
        if self.kind == "move":
            return P + (self.du, self.dv)
        d = P - pivots
        if self.kind == "rotate":
            a = math.radians(self.angle)
            c, s = math.cos(a), math.sin(a)
            return np.column_stack((d[:, 0] * c - d[:, 1] * s, d[:, 0] * s + d[:, 1] * c)) + pivots
        return d * (self.su, self.sv) + pivots

    def is_identity(self):
        return (self.kind == "move" and not (self.du or self.dv)) or (self.kind == "rotate" and not self.angle) or \
            (self.kind == "scale" and self.su == 1.0 and self.sv == 1.0)


class ViewBase(object):
    """Navigation, picking, tools and label layout shared by the views. The class using it is
    a QWidget (or QOpenGLWidget) that calls _init_view(engine)."""

    def _init_view(self, engine):
        self.engine = engine
        self.setMinimumSize(160, 160)
        self.setMouseTracking(True)
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        self.u0, self.v0, self.zoom = -0.08, -0.08, 300.0  # widget x = (u - u0) * zoom, y = h - (v - v0) * zoom
        self.tool = "select"
        self._framed_for = None
        self._drag = None
        self._press = None
        self._marquee = None
        self._xf = None
        self._hover = None
        self._labels = None
        self._frame = None
        self._sel_cache = None
        self._pivot_cache = None
        self._last_error = None
        self.last_draw_ms = 0.0
        engine.updated.connect(self._on_updated)

    # -- mapping ----------------------------------------------------------------------------

    def uv_transform(self):
        z, h = self.zoom, float(self.height())
        return QtGui.QTransform(z, 0.0, 0.0, -z, -self.u0 * z, h + self.v0 * z)

    def to_px(self, uv):
        """UV -> pixels with y up (the labels' layout space)."""
        uv = np.asarray(uv, dtype=np.float64).reshape(-1, 2)
        return np.column_stack(((uv[:, 0] - self.u0) * self.zoom, (uv[:, 1] - self.v0) * self.zoom))

    def to_widget(self, uv):
        """UV -> widget pixels (y down)."""
        p = self.to_px(uv)
        p[:, 1] = self.height() - p[:, 1]
        return p

    def to_uv(self, pos):
        return (self.u0 + pos.x() / self.zoom, self.v0 + (self.height() - pos.y()) / self.zoom)

    def frame_box(self, lo, hi, margin=0.06):
        w, h = max(1, self.width()), max(1, self.height())
        span = np.maximum(np.asarray(hi, dtype=float) - np.asarray(lo, dtype=float), 1e-6)
        z = min(w / (span[0] * (1 + 2 * margin)), h / (span[1] * (1 + 2 * margin)))
        self.zoom = float(np.clip(z, 1.0, 1e7))
        c = (np.asarray(lo, dtype=float) + np.asarray(hi, dtype=float)) * 0.5
        self.u0 = float(c[0] - w / self.zoom * 0.5)
        self.v0 = float(c[1] - h / self.zoom * 0.5)
        self.update()

    def frame_all(self):
        geo = self.engine.geo
        if geo.nshells:
            lo, hi = geo.bmin.min(axis=0), geo.bmax.max(axis=0)
            lo, hi = np.minimum(lo, 0.0), np.maximum(hi, 1.0)
            self.frame_box(lo, hi)
        else:
            self.frame_box((0.0, 0.0), (1.0, 1.0))

    def frame_selected(self):
        eng = self.engine
        P = tools.uv_positions(eng, tools.selected_uvs(eng, whole_objects=False))
        if P.shape[0]:
            lo, hi = P.min(axis=0), P.max(axis=0)
            pad = np.maximum(0.01 - (hi - lo), 0.0) * 0.5  # (a single UV isn't framed at full zoom)
            self.frame_box(lo - pad, hi + pad)
            return
        geo = eng.geo
        sel = eng.sel_shells[geo.gap_shell] if geo.nshells and eng.sel_shells.size == geo.sh_n else None
        if sel is None or not sel.any() or sel.all():
            self.frame_all()
            return
        self.frame_box(geo.bmin[sel].min(axis=0), geo.bmax[sel].max(axis=0))

    # -- data -------------------------------------------------------------------------------

    def _on_updated(self):
        geo, eng = self.engine.geo, self.engine
        if self._framed_for is None and geo.nshells:
            self._framed_for = eng.geo_version
            self.frame_all()
        xf = self._xf
        if xf is not None and xf.applied and not eng.geo_pending:
            self._xf = None  # the edit was read back: drop its preview
        self.update()

    def set_tool(self, tool):
        if self._drag is not None and self._drag[0] == "transform":
            return  # (not in the middle of a drag)
        if tool in TOOLS and tool != self.tool:
            self.tool = tool
            self.update()
            try:
                self.tool_changed(tool)
            except Exception:
                pass

    def tool_changed(self, tool):
        """(The panel replaces this to follow the tool.)"""

    def selection_display(self):
        """What is selected in Maya, in layer terms (SelDisplay), kept per selection."""
        eng = self.engine
        geo = eng.geo
        L = geo.layer
        key = (eng.geo_version, eng.sel_version, eng.settings.sel_mode)
        if self._sel_cache is not None and self._sel_cache[0] == key:
            return self._sel_cache[1]
        d = SelDisplay()
        if L is not None and L.nobj:
            sel = eng.selection
            oi = core.object_index(geo)
            pts, edges, faces = [], [], []
            nxt = L.corner_next()
            for path, comps in sel.comps.items():
                o = oi.get(path)
                if o is None:
                    continue
                if len(comps.get("uv", ())):
                    pts.append(core.points_of_uvs(L, o, comps["uv"]))
                if len(comps.get("vertex", ())):
                    pts.append(np.unique(L.corner_pt[core.corners_of_verts(L, o, comps["vertex"])]))
                if len(comps.get("face", ())):
                    faces.append(core.faces_of_ids(L, o, comps["face"]))
                ev = sel.edge_verts.get(path)
                if ev is not None and len(ev):
                    c = core.corners_of_edges(L, o, ev)
                    edges.append(np.column_stack((L.corner_pt[c], L.corner_pt[nxt[c]])))
            if pts:
                d.points = np.unique(np.concatenate(pts)).astype(np.int64)
            if edges:
                d.edges = np.concatenate(edges).astype(np.int64)
            if faces:
                d.faces = np.unique(np.concatenate(faces)).astype(np.int64)
            if eng.settings.sel_mode == "SHELL" and eng.component_selection and eng.sel_shells.size == geo.sh_n \
                    and geo.nshells:
                d.shells = np.flatnonzero(eng.sel_shells[geo.gap_shell])
        self._sel_cache = (key, d)
        return d

    def stacks(self):
        """The stacks of the geometry shown (core.Stacks), or None."""
        eng = self.engine
        s = eng.stacks
        if s is None or eng.stacks_key is None or eng.stacks_key[0] != eng.geo_version \
                or s.rep.size != eng.geo.nshells:
            return None
        return s

    def shown_once(self):
        """Per gap shell: whether it is drawn in fills (a stack is filled once, by the shell
        standing for it), and a key that changes with it."""
        eng = self.engine
        s = self.stacks()
        if s is None:
            return np.ones(eng.geo.nshells, dtype=bool), (eng.geo_version, None)
        return s.rep == np.arange(s.rep.size), eng.stacks_key

    def _style(self):
        st = self.engine.settings
        lw = max(1.0, float(st.line_width))
        fsize = max(4.0, float(st.font_size))
        dot = lw * 0.5 + 1.5
        xh = 4.0 + lw * 0.5
        return {"lw": lw, "fsize": fsize, "dot": dot, "xh": xh, "lift": xh + fsize * 0.9,
                "margin": 64.0, "pad": max(2.0, round(3.0))}

    def _font(self, fsize):
        f = QtGui.QFont(self.font())
        f.setPixelSize(int(round(fsize)))
        return f

    def _label_data(self, sty):
        eng, st, geo, meas = self.engine, self.engine.settings, self.engine.geo, self.engine.meas
        td_info = td_key = None
        if st.td_show and geo.sh_n and eng.td.size == geo.sh_n:
            thr = st.thresholds()
            td_info = (eng.td, st.td_label(), st.td_factor(), thr)
            td_key = (eng.td_key, st.td_unit, thr)
        info = (bool(st.info_show and st.show_scale), bool(st.info_show and st.show_orientation),
                bool(meas is not None and st.show_flipped))
        key = (meas.version if meas is not None else None, eng.geo_version, round(sty["fsize"], 3),
               float(st.min_px), float(st.needed_px), float(st.border_min_px), float(st.border_needed_px),
               tuple(st.color_zero), tuple(st.color_min), tuple(st.color_needed), tuple(st.color_overlap),
               tuple(st.color_flipped), td_key, info, eng.stacks_key, bool(st.info_show))
        if self._labels is None or self._labels[0] != key:
            lab = core.build_labels(geo, meas, st, QtMetrics(self._font(sty["fsize"])), td_info, info,
                                    self.stacks(), bool(st.info_show))
            self._labels = (key, lab)
        return self._labels

    def overlay_shown(self):
        st, geo = self.engine.settings, self.engine.geo
        return bool(geo.sh_n and (st.show or st.td_show or (st.info_show and st.show_orientation)))

    def label_frame(self, sty, alpha, lines=True):
        """Labels (boxes, arrows, texts) in widget pixels and, with `lines`, the gap lines and
        markers as QPainterPaths; reused while the view and the data stay the same."""
        st, meas = self.engine.settings, self.engine.meas
        key_lab, lab = self._label_data(sty)
        w, h = float(self.width()), float(self.height())
        fkey = (self.u0, self.v0, self.zoom, w, h, key_lab, round(alpha, 4), tuple(sorted(sty.items())),
                bool(st.declutter), bool(st.label_background), bool(st.show), lines)
        if self._frame is not None and self._frame[0] == fkey:
            return self._frame[1], lab
        margin = sty["margin"]
        fr = _Frame()
        fr.lines, fr.fills, fr.boxes, fr.arrows, fr.texts, fr.hl = [], [], None, [], [], None

        def add_lines(P, Q, rgb):
            P, Q = _flip_y(P, h), _flip_y(Q, h)
            inv, uq = _groups(rgb)
            for g in range(uq.shape[0]):
                m = inv == g
                fr.lines.append((_qcolor(uq[g], alpha), segments_path(P[m], Q[m])))

        if lines and st.show and meas is not None:
            ov = np.asarray(st.color_overlap, dtype=float)
            for p_uv, q_uv, rgb, axis in ((meas.p_uv, meas.q_uv, lab.gap_rgb, None),
                                          (meas.bp_uv, meas.bf_uv, lab.border_rgb, meas.baxis)):
                if not p_uv.size:
                    continue
                P, Q = self.to_px(p_uv), self.to_px(q_uv)
                vis = core.visible_segments(P, Q, w, h, margin)
                if not vis.any():
                    continue
                P, Q, rgb_v = P[vis], Q[vis], rgb[vis]
                add_lines(P, Q, rgb_v)
                # the dots: zero-length lines drawn with a square-capped pen (far faster in Qt
                # than tens of thousands of filled squares)
                D = np.repeat(_flip_y(P, h), 2, axis=0)
                inv, uq = _groups(rgb_v)
                types = np.tile(np.array([0, 1], dtype=np.int32), P.shape[0])
                for g in range(uq.shape[0]):
                    m = np.repeat(inv == g, 2)
                    fr.fills.append((_qcolor(uq[g], alpha), path_from_points(D[m], types[m])))
                if axis is not None:
                    T = core.tick_points(Q, axis[vis], sty["xh"])
                    add_lines(T[0::2], T[1::2], rgb_v)
            for uv in (meas.ov_uv, meas.cross_uv, meas.tile_mark_uv):
                if uv.size:
                    X = self.to_px(uv)
                    X = thin(X[core.in_region(X, w, h, margin)])
                    if X.size:
                        C = core.cross_points(X, sty["xh"])
                        add_lines(C[0::2], C[1::2], np.tile(ov, (C.shape[0] // 2, 1)))
        if lab.nlines.size:
            idx, boxes, tx, ty, ax, ay = core.place_labels(lab, self.to_px(lab.anchor), sty["lift"], sty["pad"],
                                                           w, h, st.declutter)
            if idx.size:
                if st.label_background:
                    R = boxes[idx]
                    fr.boxes = (QtGui.QColor.fromRgbF(0.0, 0.0, 0.0, 0.85 * alpha),
                                _rects(R[:, 0], h - R[:, 3], R[:, 2] - R[:, 0], R[:, 3] - R[:, 1]))
                sel = idx[np.isfinite(lab.icon[idx, 0])]
                if sel.size:
                    D = lab.icon[sel] * self.zoom  # uniform scale: UV directions stay directions
                    dn = np.hypot(D[:, 0], D[:, 1])
                    good = dn > 0.0
                    sel, D, dn = sel[good], D[good], dn[good]
                    if sel.size:
                        C = np.column_stack((ax[sel] - (lab.width[sel] - lab.icw[sel]) * 0.5, ay[sel]))
                        pts = _flip_y(core.arrow_points(C, D / dn[:, None], lab.icw[sel] * 0.9), h)
                        inv, uq = _groups(lab.icon_rgb[sel])
                        types = np.tile(np.array([0, 1, 1, 1, 1, 1, 1], dtype=np.int32), sel.size)
                        for g in range(uq.shape[0]):
                            m = np.repeat(inv == g, 7)
                            fr.arrows.append((_qcolor(uq[g], alpha), path_from_points(pts[m], types[m])))
                placed = np.zeros(lab.nlines.size, dtype=bool)
                placed[idx] = True
                li = np.flatnonzero(placed[lab.line_of]) if lab.line_of.size else np.zeros(0, dtype=np.int64)
                if li.size:
                    owner = lab.line_of[li]
                    xs = tx[owner].tolist()
                    ys = (h - (ty[owner] - lab.row[li] * lab.lh)).tolist()
                    cols = lab.rgb[li].tolist()
                    fr.texts = [(xs[k], ys[k], cols[k], lab.text[i]) for k, i in enumerate(li.tolist())]
        self._frame = (fkey, fr)
        return fr, lab

    def paint_labels(self, p, fr, sty, alpha):
        """Label boxes, orientation arrows and texts (QPainter, either view)."""
        st = self.engine.settings
        p.save()
        p.setPen(Qt.PenStyle.NoPen)
        p.setRenderHint(QtGui.QPainter.RenderHint.Antialiasing, False)
        if fr.boxes is not None:
            p.setBrush(fr.boxes[0])
            p.drawRects(fr.boxes[1])
        p.setRenderHint(QtGui.QPainter.RenderHint.Antialiasing, True)
        for qc, path in fr.arrows:
            p.fillPath(path, qc)
        if fr.texts:
            p.setFont(self._font(sty["fsize"]))
            shadow = not st.label_background
            sh = QtGui.QColor.fromRgbF(0.0, 0.0, 0.0, alpha)
            for x, y, rgb, text in fr.texts:
                if shadow:
                    p.setPen(sh)
                    p.drawText(QtCore.QPointF(x + 1.0, y + 1.0), text)
                p.setPen(_qcolor(rgb, alpha))
                p.drawText(QtCore.QPointF(x, y), text)
        p.restore()

    def grid_lines(self):
        """[(QColor, x0, y0, x1, y1)] in widget pixels: 0.1 lines, tile lines, the 0-1 tile."""
        w, h, z = float(self.width()), float(self.height()), self.zoom
        u_lo, u_hi = self.u0, self.u0 + w / z
        v_lo, v_hi = self.v0, self.v0 + h / z
        out = []
        step = 0.1
        if step * z >= 10.0 and (u_hi - u_lo) / step < 2000:
            for k in range(int(np.floor(u_lo / step)), int(np.ceil(u_hi / step)) + 1):
                if k % 10:
                    x = (k * step - self.u0) * z
                    out.append((GRID, x, 0.0, x, h))
            for k in range(int(np.floor(v_lo / step)), int(np.ceil(v_hi / step)) + 1):
                if k % 10:
                    y = h - (k * step - self.v0) * z
                    out.append((GRID, 0.0, y, w, y))
        if (u_hi - u_lo) < 400:
            for k in range(int(np.floor(u_lo)), int(np.ceil(u_hi)) + 1):
                x = (k - self.u0) * z
                out.append((GRID_TILE, x, 0.0, x, h))
            for k in range(int(np.floor(v_lo)), int(np.ceil(v_hi)) + 1):
                y = h - (k - self.v0) * z
                out.append((GRID_TILE, 0.0, y, w, y))
        x0, y1 = (0.0 - self.u0) * z, h - (0.0 - self.v0) * z
        for a, b, c, d in ((x0, y1, x0 + z, y1), (x0 + z, y1, x0 + z, y1 - z), (x0 + z, y1 - z, x0, y1 - z),
                           (x0, y1 - z, x0, y1)):
            out.append((GRID_HOME, a, b, c, d))
        return out

    # -- the transform being dragged -------------------------------------------------------------

    def preview(self):
        """(UV segments (P, Q), moving points (UV)) of the transform being dragged, or None."""
        xf, L = self._xf, self.engine.geo.layer
        if xf is None or L is None or not xf.pts.size:
            return None
        if xf.is_identity() and not xf.applied:
            return None
        moved = np.zeros(L.pts.shape[0], dtype=bool)
        moved[xf.pts] = True
        P = L.pts.copy()
        P[xf.pts] = xf.apply_to(L.pts[xf.pts], xf.pivots)
        E = xf.edges
        return (P[E[:, 0]], P[E[:, 1]]), P[xf.pts]

    def _start_transform(self, pos):
        eng = self.engine
        L = eng.geo.layer
        if L is None or eng.geo_pending:
            return False
        per = tools.selected_uvs(eng, whole_objects=False)  # (dragging needs selected components)
        if not per:
            return False
        xf = Transform(self.tool)
        xf.per = per
        oi = core.object_index(eng.geo)
        pts = [core.points_of_uvs(L, oi[p], ids) for p, ids in per if p in oi]
        xf.pts = np.unique(np.concatenate(pts)) if pts else np.zeros(0, dtype=np.int64)
        if not xf.pts.size:
            return False
        c = tools.selection_center(eng, per)
        xf.pivot = np.asarray(c if c is not None else L.pts[xf.pts].mean(axis=0), dtype=np.float64)
        xf.pivots = np.tile(xf.pivot, (xf.pts.size, 1))
        if xf.kind != "move" and eng.settings.pivot == "SHELL":
            sh = L.pt_shell[xf.pts]
            for s in np.unique(sh).tolist():
                m = sh == s
                P = L.pts[xf.pts[m]]
                xf.pivots[m] = (P.min(axis=0) + P.max(axis=0)) * 0.5
        moving = np.zeros(L.pts.shape[0], dtype=bool)
        moving[xf.pts] = True
        xf.edges = L.wire[moving[L.wire[:, 0]] | moving[L.wire[:, 1]]].astype(np.int64)
        hit = self._manip_hit(pos, xf.pivot)
        if hit is None:
            return False  # (a drag beside the manipulator selects)
        xf.axis = None if hit == "free" else hit
        xf.start = pos
        self._xf = xf
        return True

    def _manip_hit(self, pos, pivot):
        """What of the manipulator is under pos: 0 (the U handle), 1 (the V handle), "free"
        (its middle; anywhere inside the Rotate ring), None beside it."""
        c = self.to_widget(pivot)[0]
        x, y = pos.x() - c[0], pos.y() - c[1]
        if self.tool == "rotate":
            return "free" if math.hypot(x, y) <= HANDLE_PX + 8.0 else None
        if self.tool in ("move", "scale"):
            if abs(y) <= 8 and FREE_PX < x <= HANDLE_PX + 16:
                return 0
            if abs(x) <= 8 and FREE_PX < -y <= HANDLE_PX + 16:
                return 1
            if abs(x) <= FREE_PX and abs(y) <= FREE_PX:
                return "free"
        return None

    def _drag_transform(self, pos, mods):
        """Move: by the drag (Shift: along the nearer axis). Rotate: by the angle the drag
        sweeps around the pivot (Shift: steps of 15 degrees). Scale: a handle dragged twice as
        far from the pivot is twice the size along it; the middle scales both ways, twice
        per 100 pixels to the right or up (Shift: steps of 0.1)."""
        xf = self._xf
        start = xf.start
        shift = bool(mods & Qt.KeyboardModifier.ShiftModifier)
        dx, dy = pos.x() - start.x(), start.y() - pos.y()  # (y up)
        if xf.kind == "move":
            du, dv = dx / self.zoom, dy / self.zoom
            axis = xf.axis
            if axis is None and shift:
                axis = 0 if abs(du) >= abs(dv) else 1
            xf.du, xf.dv = (du if axis != 1 else 0.0), (dv if axis != 0 else 0.0)
        else:
            c = self.to_widget(xf.pivot)[0]
            a = (start.x() - c[0], c[1] - start.y())
            b = (pos.x() - c[0], c[1] - pos.y())
            if xf.kind == "rotate":
                if xf.ref is None:  # (a drag begun on the pivot counts from where it leaves it)
                    if math.hypot(*a) >= 6.0:
                        xf.ref = a
                    elif math.hypot(*b) >= 6.0:
                        xf.ref = b
                if xf.ref is not None:
                    ang = math.degrees(math.atan2(b[1], b[0]) - math.atan2(xf.ref[1], xf.ref[0]))
                    ang = (ang + 180.0) % 360.0 - 180.0
                    xf.angle = round(ang / 15.0) * 15.0 if shift else ang
            else:
                if xf.axis is None:
                    f = 2.0 ** ((dx + dy) / 100.0)
                else:
                    la, lb = a[xf.axis], b[xf.axis]
                    f = max(0.01, lb / la) if abs(la) > 1.0 else 1.0  # (never through the pivot: no flipping)
                if shift:
                    f = max(0.1, round(f * 10.0) / 10.0)
                xf.su = f if xf.axis != 1 else 1.0
                xf.sv = f if xf.axis != 0 else 1.0
        self.update()

    def _finish_transform(self):
        xf = self._xf
        eng = self.engine
        if xf is None or xf.is_identity():
            self._xf = None
            self.update()
            return
        try:
            if xf.kind == "move":
                tools.move(eng, xf.du, xf.dv, per=xf.per)
            elif xf.kind == "rotate":
                tools.rotate(eng, xf.angle, per=xf.per, pivot=None if eng.settings.pivot == "SHELL" else xf.pivot)
            else:
                tools.scale(eng, xf.su, xf.sv, per=xf.per, pivot=None if eng.settings.pivot == "SHELL" else xf.pivot)
            xf.applied = True
            xf.geo_version = eng.geo_version
        except Exception:
            print("[UV Shell Gap Overlay] transform failed:\n" + traceback.format_exc())
            self._xf = None
        self.update()

    # -- picking ----------------------------------------------------------------------------------

    @staticmethod
    def _mode(mods):
        shift = bool(mods & Qt.KeyboardModifier.ShiftModifier)
        ctrl = bool(mods & Qt.KeyboardModifier.ControlModifier)
        return "add" if (shift and ctrl) else "toggle" if shift else "deselect" if ctrl else "replace"

    def _pick(self, pos, mods, rect=None, whole_shell=False):
        """Select what a click at pos (or a rectangle, in widget pixels) picks; `whole_shell`:
        the shell under pos, whatever is being picked (a double click)."""
        eng = self.engine
        geo, L = eng.geo, eng.geo.layer
        mode = self._mode(mods)
        sel_mode = "SHELL" if whole_shell else eng.settings.sel_mode
        if whole_shell and mode == "toggle":
            mode = "add"  # (the first click of the two toggled what it hit already)
        if L is None or not L.nobj or eng.geo_pending:  # (what is shown isn't what Maya has now)
            return
        if rect is not None:
            (x0, y0), (x1, y1) = rect
            ua, va = self.to_uv(QtCore.QPointF(min(x0, x1), max(y0, y1)))
            ub, vb = self.to_uv(QtCore.QPointF(max(x0, x1), min(y0, y1)))
        else:
            u, v = self.to_uv(pos)
            r = PICK_PX / self.zoom
        try:
            if sel_mode == "SHELL":
                if rect is not None:
                    shells = core.shells_in_rect(L, ua, va, ub, vb)
                else:
                    f = core.pick_face(L, u, v)
                    shells = np.array([L.face_shell[f]]) if f >= 0 else np.zeros(0, dtype=np.int64)
                # stacked shells count as one: a stack is picked whole
                shells = core.whole_stacks(geo, shells, self.stacks())
                if shells.size or mode == "replace":
                    eng.select_shells(shells, mode, kind=tools.shell_kind(eng))
                return
            if sel_mode == "UV":
                pts = core.points_in_rect(L, ua, va, ub, vb) if rect is not None else \
                    np.array([i for i in [core.pick_point(L, u, v, r)] if i >= 0], dtype=np.int64)
                per = [(geo.obj_keys[o], L.pt_uvid[loc + L.obj_pt_off[o]])
                       for o, loc in core.per_object(L, pts, L.obj_pt_off)]
                tools.select_picked(eng, "uv", per, mode)
            elif sel_mode == "FACE":
                faces = core.faces_in_rect(L, ua, va, ub, vb) if rect is not None else \
                    np.array([i for i in [core.pick_face(L, u, v)] if i >= 0], dtype=np.int64)
                per = [(geo.obj_keys[o], L.face_id[loc + L.obj_face_off[o]])
                       for o, loc in core.per_object(L, faces, L.obj_face_off)]
                tools.select_picked(eng, "face", per, mode)
            elif sel_mode == "EDGE":
                edges = core.edges_in_rect(L, ua, va, ub, vb) if rect is not None else \
                    np.array([i for i in [core.pick_edge(L, u, v, r)] if i >= 0], dtype=np.int64)
                corners = core.corners_of_wire(L, edges)
                per = tools.corner_edges(eng, corners[corners >= 0])
                tools.select_picked(eng, "edge", per, mode)
        except Exception:
            print("[UV Shell Gap Overlay] select failed:\n" + traceback.format_exc())

    # -- interaction ------------------------------------------------------------------------------

    def wheelEvent(self, e):
        d = e.angleDelta().y()
        if not d:
            return
        self._zoom_at(event_pos(e), 1.15 ** (d / 120.0))

    def _zoom_at(self, pos, factor):
        u, v = self.to_uv(pos)
        self.zoom = float(np.clip(self.zoom * factor, 1.0, 1e7))
        self.u0 = u - pos.x() / self.zoom
        self.v0 = v - (self.height() - pos.y()) / self.zoom
        self.update()

    def mousePressEvent(self, e):
        pos = event_pos(e)
        alt = bool(e.modifiers() & Qt.KeyboardModifier.AltModifier)
        b = e.button()
        if b == Qt.MouseButton.MiddleButton:  # with or without Alt, as in Maya's UV Editor
            self._drag = ("pan", pos, self.u0, self.v0)
        elif alt and b == Qt.MouseButton.RightButton:
            self._drag = ("zoom", pos, self.zoom, self.to_uv(pos))
        elif b == Qt.MouseButton.LeftButton:
            if self._xf is not None and self._xf.applied and not self.engine.geo_pending:
                self._xf = None  # (an edit that didn't come back as a change)
            self._press = (pos, e.modifiers())
        else:
            e.ignore()

    def mouseMoveEvent(self, e):
        pos = event_pos(e)
        if self._drag is not None:
            kind, start = self._drag[0], self._drag[1]
            if kind == "pan":
                self.u0 = self._drag[2] - (pos.x() - start.x()) / self.zoom
                self.v0 = self._drag[3] + (pos.y() - start.y()) / self.zoom
            elif kind == "zoom":
                z0, (u, v) = self._drag[2], self._drag[3]
                f = 1.01 ** ((pos.x() - start.x()) - (pos.y() - start.y()))
                self.zoom = float(np.clip(z0 * f, 1.0, 1e7))
                self.u0 = u - start.x() / self.zoom
                self.v0 = v - (self.height() - start.y()) / self.zoom
            elif kind == "transform":
                self._drag_transform(pos, e.modifiers())
                return
            elif kind == "marquee":
                self._marquee = (self._marquee[0], (pos.x(), pos.y()))
            self.update()
            return
        if self._press is not None:
            start, mods = self._press
            if abs(pos.x() - start.x()) + abs(pos.y() - start.y()) > 4.0:
                self._press = None
                if self.tool != "select" and self._start_transform(start):
                    self._drag = ("transform", start)
                    self._drag_transform(pos, e.modifiers())
                else:
                    self._drag = ("marquee", start, mods)
                    self._marquee = ((start.x(), start.y()), (pos.x(), pos.y()))
                    self.update()
            return
        if self.tool != "select" and self._xf is None:
            c = self._manip_pivot()
            hover = self._manip_hit(pos, c) if c is not None else None
            if hover != self._hover:
                self._hover = hover
                self.update()

    def mouseReleaseEvent(self, e):
        if self._drag is not None:
            kind = self._drag[0]
            if kind == "transform":
                self._finish_transform()
            elif kind == "marquee":
                mods = self._drag[2]
                rect = self._marquee
                self._marquee = None
                self._pick(None, mods, rect)
            self._drag = None
            self.update()
            return
        if self._press is not None and e.button() == Qt.MouseButton.LeftButton:
            pos, mods = self._press
            self._press = None
            self._pick(pos, mods)

    def mouseDoubleClickEvent(self, e):
        """A double click selects the whole shell (as in Maya's UV Editor)."""
        if e.button() == Qt.MouseButton.LeftButton:
            self._press = None
            self._pick(event_pos(e), e.modifiers(), whole_shell=True)
        else:
            e.ignore()

    def enterEvent(self, e):
        """Keys go to the view the mouse is over (as with Maya's panels), unless a number or
        a text is being typed somewhere."""
        try:
            typing = isinstance(QtWidgets.QApplication.focusWidget(),
                                (QtWidgets.QLineEdit, QtWidgets.QAbstractSpinBox, QtWidgets.QTextEdit,
                                 QtWidgets.QPlainTextEdit))
            if not typing:
                self.setFocus(Qt.FocusReason.MouseFocusReason)
        except Exception:
            pass
        e.ignore()

    def _own_key(self, e):
        """Whether a key is one of the view's (no Ctrl / Alt / Meta held)."""
        if e.modifiers() & (Qt.KeyboardModifier.ControlModifier | Qt.KeyboardModifier.AltModifier |
                            Qt.KeyboardModifier.MetaModifier):
            return False
        k = e.key()
        return (k in TOOL_KEYS or k in MODE_KEYS or k in (Qt.Key.Key_F, Qt.Key.Key_A, Qt.Key.Key_Home)
                or (k == Qt.Key.Key_Escape and self._drag is not None))

    def event(self, e):
        # Maya's hotkeys (Q W E R, F, A, the F-keys...) are shortcuts: a widget gets such a key
        # itself only when it claims it here
        if e.type() == QtCore.QEvent.Type.ShortcutOverride and self._own_key(e):
            e.accept()
            return True
        return super(ViewBase, self).event(e)

    def keyPressEvent(self, e):
        if not self._own_key(e):
            QtWidgets.QWidget.keyPressEvent(self, e)  # (not ours: on to Maya)
            return
        k = e.key()
        if k == Qt.Key.Key_F:
            self.frame_selected()
        elif k == Qt.Key.Key_A:
            self.frame_all()
        elif k == Qt.Key.Key_Home:
            self.frame_box((0.0, 0.0), (1.0, 1.0))
        elif k in TOOL_KEYS:
            self.set_tool(TOOL_KEYS[k])
        elif k in MODE_KEYS:
            self.engine.settings.update({"sel_mode": MODE_KEYS[k]})
        elif k == Qt.Key.Key_Escape:  # (while dragging: cancel)
            self._drag = None
            self._xf = None
            self._marquee = None
            self.update()

    def contextMenuEvent(self, e):
        st = self.engine.settings
        menu = QtWidgets.QMenu(self)
        menu.addAction("Frame All (A)", self.frame_all)
        menu.addAction("Frame Selected (F)", self.frame_selected)
        menu.addAction("Frame 0-1 Tile (Home)", lambda: self.frame_box((0.0, 0.0), (1.0, 1.0)))
        menu.addSeparator()
        for key, label in (("show_wire", "UV Wireframe"), ("show_grid", "Grid")):
            act = menu.addAction(label)
            act.setCheckable(True)
            act.setChecked(bool(getattr(st, key)))
            act.toggled.connect(lambda on, k=key: st.update({k: on}))
        (getattr(menu, "exec", None) or menu.exec_)(e.globalPos())

    # -- overlays drawn with QPainter in both views ---------------------------------------------------

    def _manip_pivot(self):
        """The manipulator's pivot (UV): the middle of the selected UVs; None without a tool or
        a component selection."""
        if self.tool == "select":
            return None
        xf = self._xf
        if xf is not None:  # (the manipulator goes along with a move)
            return xf.pivot + (xf.du, xf.dv) if xf.kind == "move" else xf.pivot
        eng = self.engine
        key = (eng.geo_version, eng.sel_version)
        if self._pivot_cache is None or self._pivot_cache[0] != key:
            c = tools.selection_center(eng, tools.selected_uvs(eng, whole_objects=False))
            self._pivot_cache = (key, c)
        return self._pivot_cache[1]

    def paint_tool_overlay(self, p):
        """Marquee and manipulator."""
        p.save()
        p.setRenderHint(QtGui.QPainter.RenderHint.Antialiasing, True)
        if self._marquee is not None:
            (x0, y0), (x1, y1) = self._marquee
            pen = QtGui.QPen(QtGui.QColor(255, 255, 255, 200))
            pen.setStyle(Qt.PenStyle.DashLine)
            pen.setCosmetic(True)
            p.setPen(pen)
            p.setBrush(QtGui.QColor(255, 255, 255, 18))
            p.drawRect(QtCore.QRectF(min(x0, x1), min(y0, y1), abs(x1 - x0), abs(y1 - y0)))
        piv = self._manip_pivot()
        if piv is not None:
            c = self.to_widget(piv)[0]
            cx, cy = float(c[0]), float(c[1])
            xf = self._xf
            red, green, yellow = QtGui.QColor(240, 80, 80), QtGui.QColor(110, 220, 90), QtGui.QColor(255, 220, 60)
            axis = ("free" if xf.axis is None else xf.axis) if xf is not None else self._hover
            if self.tool in ("move", "scale"):
                for ax, col, dx, dy in ((0, red, 1.0, 0.0), (1, green, 0.0, -1.0)):
                    pen = QtGui.QPen(yellow if axis == ax else col)
                    pen.setWidthF(2.0)
                    p.setPen(pen)
                    p.drawLine(QtCore.QPointF(cx + dx * FREE_PX, cy + dy * FREE_PX),
                               QtCore.QPointF(cx + dx * HANDLE_PX, cy + dy * HANDLE_PX))
                    tip = QtCore.QPointF(cx + dx * HANDLE_PX, cy + dy * HANDLE_PX)
                    p.setBrush(yellow if axis == ax else col)
                    if self.tool == "move":
                        nx, ny = -dy, dx
                        poly = QtGui.QPolygonF([QtCore.QPointF(tip.x() + dx * 12, tip.y() + dy * 12),
                                                QtCore.QPointF(tip.x() + nx * 5, tip.y() + ny * 5),
                                                QtCore.QPointF(tip.x() - nx * 5, tip.y() - ny * 5)])
                        p.drawPolygon(poly)
                    else:
                        p.drawRect(QtCore.QRectF(tip.x() - 5, tip.y() - 5, 10, 10))
                pen = QtGui.QPen(yellow if axis == "free" else QtGui.QColor(230, 230, 230))
                pen.setWidthF(1.5)
                p.setPen(pen)
                p.setBrush(QtGui.QColor(255, 220, 60, 60) if axis == "free" else QtGui.QColor(255, 255, 255, 25))
                p.drawRect(QtCore.QRectF(cx - 9, cy - 9, 18, 18))
            else:
                pen = QtGui.QPen(yellow if axis == "free" else QtGui.QColor(90, 150, 255))
                pen.setWidthF(2.0)
                p.setPen(pen)
                p.setBrush(Qt.BrushStyle.NoBrush)
                p.drawEllipse(QtCore.QPointF(cx, cy), HANDLE_PX, HANDLE_PX)
                p.drawLine(QtCore.QPointF(cx - 5, cy), QtCore.QPointF(cx + 5, cy))
                p.drawLine(QtCore.QPointF(cx, cy - 5), QtCore.QPointF(cx, cy + 5))
            if xf is not None and not xf.applied:
                if xf.kind == "move":
                    text = "%+.4f, %+.4f UV  (%+.1f, %+.1f px)" % (xf.du, xf.dv, xf.du * self.engine.W,
                                                                   xf.dv * self.engine.H)
                elif xf.kind == "rotate":
                    text = "%+.1f°" % xf.angle
                else:
                    text = "× %.3f" % xf.su if xf.su == xf.sv else "× %.3f, %.3f" % (xf.su, xf.sv)
                p.setPen(QtGui.QColor(255, 255, 255))
                f = QtGui.QFont(self.font())
                f.setPixelSize(12)
                p.setFont(f)
                p.drawText(QtCore.QPointF(cx + 14, cy + 26), text)
        p.restore()

    def paint_hud(self, p):
        eng, geo = self.engine, self.engine.geo
        if not eng.paths:
            msg = "Select meshes (objects or components) to see their UVs"
        elif not geo.sh_n and not eng.stale:
            msg = "No UVs on the shown faces"
        else:
            msg = "%d object%s · %d shell%s · %d × %d px" % (
                len(eng.paths), "" if len(eng.paths) == 1 else "s", geo.sh_n, "" if geo.sh_n == 1 else "s",
                eng.W, eng.H)
        if eng.stale:
            msg += "  · %s…" % (eng.busy or "updating").lower()
        if eng.error:
            msg += "  · error (see the Script Editor)"
        p.setPen(TEXT)
        f = QtGui.QFont(self.font())
        f.setPixelSize(12)
        p.setFont(f)
        p.drawText(QtCore.QPointF(8.0, 18.0), msg)
        mode = {"UV": "UVs", "EDGE": "Edges", "FACE": "Faces", "SHELL": "Shells"}.get(eng.settings.sel_mode, "")
        tool = {"select": "Select", "move": "Move", "rotate": "Rotate", "scale": "Scale"}[self.tool]
        p.setPen(QtGui.QColor(200, 200, 200, 170))
        p.drawText(QtCore.QPointF(8.0, float(self.height()) - 8.0), "%s · %s" % (tool, mode))


class PainterView(ViewBase, QtWidgets.QWidget):
    """The UV view drawn with QPainter (when the GPU view isn't available)."""

    def __init__(self, engine, parent=None):
        QtWidgets.QWidget.__init__(self, parent)
        self.setAttribute(Qt.WidgetAttribute.WA_OpaquePaintEvent, True)
        self._uv_cache = {}
        self._td_cache = None
        self._range_cache = None
        self._init_view(engine)

    def _uv_paths(self):
        """UV-space paths of the geometry, built once per extraction."""
        eng, geo = self.engine, self.engine.geo
        once, okey = self.shown_once()
        key = (eng.geo_version, okey)
        c = self._uv_cache
        if c.get("key") != key:
            c.clear()
            c["key"] = key
            c["wire"] = segments_path(geo.wire_a, geo.wire_b) if geo.wire_a.size else None
            c["border"] = segments_path(geo.seg_a, geo.seg_b) if geo.seg_a.size else None
            # every shell's border loops, all wound one way (see core.fill_loops)
            c["fill_pts"], c["fill_types"] = core.fill_loops(geo)
            flip = geo.flipped & once  # (a stack with an unflipped shell isn't shown as flipped)
            if flip.any():
                m = flip[geo.seg_shell]
                c["flipped"] = path_from_points(c["fill_pts"][m], c["fill_types"][m])
                c["flipped_outline"] = segments_path(geo.seg_a[m], geo.seg_b[m])
            else:
                c["flipped"] = c["flipped_outline"] = None
        return c

    def _sel_paths(self):
        """UV-space paths of the selection: faces, edges, shell outlines; dots of points."""
        d = self.selection_display()
        geo, L = self.engine.geo, self.engine.geo.layer
        key = self._sel_cache[0]
        c = self._uv_cache
        if c.get("sel_key") == key:
            return c["sel"]
        out = {}
        if L is not None and d.faces.size:
            tri = L.tri[np.isin(L.tri_face, d.faces)]
            T = L.pts[tri]
            pts = T.reshape(-1, 2)
            types = np.tile(np.array([0, 1, 1], dtype=np.int32), tri.shape[0])
            out["faces"] = path_from_points(pts, types, winding=True)
        if L is not None and d.edges.size:
            out["edges"] = segments_path(L.pts[d.edges[:, 0]], L.pts[d.edges[:, 1]])
        if d.shells.size:
            m = np.isin(geo.seg_shell, d.shells)
            if m.any():
                out["shells"] = segments_path(geo.seg_a[m], geo.seg_b[m])
        out["points"] = L.pts[d.points] if L is not None and d.points.size else None
        c["sel_key"], c["sel"] = key, out
        return out

    def _td_paths(self):
        """Texel density fill: one path per color step (shell outlines, holes cut out)."""
        eng, geo, st = self.engine, self.engine.geo, self.engine.settings
        thr = st.thresholds()
        once, okey = self.shown_once()
        key = (eng.geo_version, eng.td_key, thr, okey)
        if self._td_cache is not None and self._td_cache[0] == key:
            return self._td_cache[1]
        out = []
        if geo.nshells and eng.td.size == geo.sh_n:
            lv_shell = core.td_levels(eng.td[geo.gap_shell], *thr, steps=UV_STEPS)
            lv_shell = np.where(once, lv_shell, -9)  # (a stack is filled once)
            lv_seg = lv_shell[geo.seg_shell]  # (loops are reversed in place: same shells per position)
            c = self._uv_paths()
            pts, types = c["fill_pts"], c["fill_types"]
            for lv in np.unique(lv_seg).tolist():
                if lv == -9:
                    continue
                m = lv_seg == lv
                rgb = core.level_rgb(np.array([lv]), UV_STEPS)[0]
                out.append((rgb, path_from_points(pts[m], types[m])))
        self._td_cache = (key, out)
        return out

    def _range_path(self):
        """Outlines of the shells inside the texel density range, or None (no narrower range)."""
        eng, geo, st = self.engine, self.engine.geo, self.engine.settings
        if not (st.td_range_highlight and geo.nshells and eng.td.size == geo.sh_n
                and (st.td_sel_from > 0.0 or st.td_sel_to < 100.0)):
            return None
        key = (eng.geo_version, eng.td_key, float(st.td_sel_from), float(st.td_sel_to))
        if self._range_cache is not None and self._range_cache[0] == key:
            return self._range_cache[1]
        path = None
        shells, bounds = core.shells_in_range(eng.td, st.td_sel_from / 100.0, st.td_sel_to / 100.0)
        if bounds is not None and shells.size:
            inside = np.zeros(geo.sh_n, dtype=bool)
            inside[shells] = True
            m = inside[geo.gap_shell][geo.seg_shell]
            if m.any():
                path = segments_path(geo.seg_a[m], geo.seg_b[m])
        self._range_cache = (key, path)
        return path

    def paintEvent(self, _event):
        t0 = time.perf_counter()
        p = QtGui.QPainter(self)
        try:
            p.fillRect(self.rect(), BG)
            self._paint(p)
            self._last_error = None
        except Exception:
            err = traceback.format_exc()
            if err != self._last_error:
                print("[UV Shell Gap Overlay] view error:\n" + err)
                self._last_error = err
        finally:
            p.end()
        self.last_draw_ms = (time.perf_counter() - t0) * 1000.0
        self.engine.timings["draw"] = self.last_draw_ms

    def _paint(self, p):
        eng, st = self.engine, self.engine.settings
        geo_dim = 0.35 if eng.geo_pending else 1.0
        meas_dim = 0.35 if eng.stale else 1.0
        if st.show_grid:
            p.save()
            for qc, x0, y0, x1, y1 in self.grid_lines():
                p.setPen(self._pen(qc, 1.0))
                p.drawLine(QtCore.QLineF(x0, y0, x1, y1))
            p.restore()
        uvp = self._uv_paths()
        sel = self._sel_paths() if st.show_selection else {}
        p.save()
        p.setTransform(self.uv_transform())
        p.setRenderHint(QtGui.QPainter.RenderHint.Antialiasing, False)  # (fills: the borders are drawn on top)
        p.setPen(Qt.PenStyle.NoPen)
        if st.td_show:
            a = float(st.td_fill_opacity) * geo_dim
            for rgb, path in self._td_paths():
                p.fillPath(path, _qcolor(rgb, a))
        meas_on = st.show and eng.meas is not None
        if meas_on and st.show_flipped and uvp.get("flipped") is not None:
            p.fillPath(uvp["flipped"], _qcolor(st.color_flipped, 0.22 * float(st.opacity) * meas_dim))
        if sel.get("faces") is not None:
            p.fillPath(sel["faces"], _qcolor(SEL_RGB, 0.35))
        if st.show_wire and uvp.get("wire") is not None:
            p.strokePath(uvp["wire"], self._pen(WIRE, 1.0))
        if uvp.get("border") is not None:
            p.strokePath(uvp["border"], self._pen(BORDER, 1.0))
        sty = self._style()
        hl = self._range_path()
        if hl is not None:
            p.setRenderHint(QtGui.QPainter.RenderHint.Antialiasing, True)
            p.strokePath(hl, self._pen(QtGui.QColor(255, 255, 255, int(230 * geo_dim)), sty["lw"] + 2.0))
        if sel.get("shells") is not None:
            p.strokePath(sel["shells"], self._pen(SELECTED, 1.5))
        if sel.get("edges") is not None:
            p.setRenderHint(QtGui.QPainter.RenderHint.Antialiasing, True)
            p.strokePath(sel["edges"], self._pen(SELECTED, 2.5))
        if meas_on and st.show_flipped and uvp.get("flipped_outline") is not None:
            p.setRenderHint(QtGui.QPainter.RenderHint.Antialiasing, True)
            p.strokePath(uvp["flipped_outline"], self._pen(_qcolor(st.color_flipped, float(st.opacity) * meas_dim),
                                                           sty["lw"]))
        pv = self.preview()
        if pv is not None:
            p.setRenderHint(QtGui.QPainter.RenderHint.Antialiasing, True)
            p.strokePath(segments_path(*pv[0]), self._pen(_qcolor(PREVIEW_RGB, 0.9), 1.5))
        p.restore()
        h = float(self.height())
        dots = []
        if sel.get("points") is not None:
            dots.append((sel["points"], SEL_RGB))
        if pv is not None:
            dots.append((pv[1], PREVIEW_RGB))
        for P, rgb in dots:
            X = self.to_px(P)
            X = X[core.in_region(X, float(self.width()), h, 8.0)]
            if X.size:
                D = np.repeat(_flip_y(X, h), 2, axis=0)
                pen = QtGui.QPen(_qcolor(rgb, 1.0))
                pen.setWidthF(5.0)
                pen.setCapStyle(Qt.PenCapStyle.SquareCap)
                p.strokePath(path_from_points(D, np.tile(np.array([0, 1], dtype=np.int32), X.shape[0])), pen)
        if self.overlay_shown():
            alpha = max(0.0, min(1.0, float(st.opacity))) * meas_dim
            if alpha > 0.0:
                fr, _lab = self.label_frame(sty, alpha)
                self._paint_lines(p, fr, sty)
                self.paint_labels(p, fr, sty, alpha)
        self.paint_tool_overlay(p)
        self.paint_hud(p)

    def _paint_lines(self, p, fr, sty):
        p.save()
        p.setRenderHint(QtGui.QPainter.RenderHint.Antialiasing, True)
        for qc, path in fr.lines:
            p.strokePath(path, self._pen(qc, sty["lw"]))
        p.setRenderHint(QtGui.QPainter.RenderHint.Antialiasing, False)  # (axis-aligned dots)
        for qc, path in fr.fills:
            pen = QtGui.QPen(qc)
            pen.setWidthF(2.0 * sty["dot"])
            pen.setCapStyle(Qt.PenCapStyle.SquareCap)
            p.strokePath(path, pen)
        p.restore()

    @staticmethod
    def _pen(qc, width):
        pen = QtGui.QPen(qc)
        pen.setCosmetic(True)
        pen.setWidthF(float(width))
        return pen


UVView = PainterView  # (the name 1.0 used)
