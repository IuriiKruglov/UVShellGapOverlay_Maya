# SPDX-License-Identifier: GPL-3.0-or-later
#
# UV Shell Gap Overlay for Maya - measuring core (NumPy only, no Maya imports)
#
# UV shells and their borders, pixel gaps between shells and to UDIM tile borders,
# overlaps, flipped shells, texel density, orientation and material sets, plus the
# layout of the labels and info blocks. Shared logic with the Blender add-on.
#
# Authors: Iurii Kruglov & Claude (Anthropic)

import numpy as np

# ---------------------------------------------------------------------------
# Tunables
# ---------------------------------------------------------------------------

UV_EPS = 1.0e-6          # inset (UV units) for shell-inside-shell probes
PX_EPS = 1.0e-3          # inset (texture px) for per-point overlap probes
TILE_EPS = 1.0e-6        # UV tolerance: a shell touching a tile line does not cross it
EDGE_FACING = 0.25       # a border point measures only toward what its outward normal faces:
                         # at most ~75 deg off the normal (cos >= 0.25), for tile edges and neighbors
CROSS_TOL = 1.0e-7       # parametric tolerance: meeting at segment ends is touching, not crossing
CHUNK = 1 << 20          # max candidate pairs per vectorized block (bounds memory use)
DENSE_CHUNK = 1 << 19    # max elements per dense distance block
MAX_GRID_ROWS = 1 << 23  # max (box, cell) rows when gridding shell bounding boxes
MAX_PIECES = 200000      # max segment pieces when gridding borders
PROBES_PER_SHELL = 8
MAX_CROSS_MARKS = 48     # crossing markers kept per overlapping shell pair / tile-crossing shell
ORIENT_MIN = 0.3         # an arrow needs the axis to lie this much along the shell (area-weighted, 0..1)
NO_MATERIAL = "(No Material)"
METERS_PER_UNIT = 0.01   # Maya's API works in centimeters, whatever unit the UI shows

_EMPTY2 = np.empty((0, 2))
_EMPTY_F = np.empty(0)
_EMPTY_I = np.empty(0, dtype=np.int64)
_KEY_OFF = 1 << 30
_KEY_MUL = 1 << 31
_TILE_OFF = 1 << 20
_TILE_MUL = 1 << 21

# texel density units: pixels per unit = pixels per meter * factor
TD_UNITS = (
    ('PX_CM', "px/cm", "Pixels per centimeter", 0.01),
    ('PX_M', "px/m", "Pixels per meter", 1.0),
    ('PX_IN', "px/in", "Pixels per inch", 0.0254),
    ('PX_FT', "px/ft", "Pixels per foot", 0.3048),
)
TD_FACTOR = {u[0]: u[3] for u in TD_UNITS}
TD_LABEL = {u[0]: u[1] for u in TD_UNITS}

SCALE_RGB = (1.0, 0.62, 0.25)          # object scale note
AXIS_RGB = {1: (1.0, 0.38, 0.38),      # orientation arrow colors, as Maya's axes: X red,
            2: (0.45, 0.88, 0.35),     # Y green,
            3: (0.35, 0.62, 1.0)}      # Z blue


def up_axes(up):
    """(component, sign) of the arrow axes in priority order. Y-up: the scene's up (+Y), then
    on shells lying flat, -Z (away from the front view). Z-up: +Z, then +Y."""
    return ((2, 1.0), (1, 1.0)) if str(up).lower() == 'z' else ((1, 1.0), (2, -1.0))


# ---------------------------------------------------------------------------
# One mesh, as arrays
# ---------------------------------------------------------------------------

class MeshArrays:
    """Raw data of one mesh. Face corners in face order: f_start / f_total index them.

    uv_id: UV id per corner (-1: unmapped); uv_table: UV of each UV id; loop_vert: mesh vertex
    per corner; co: vertex positions (object space, centimeters); matrix: 4x4 object -> world
    for column vectors (translation in the last column: Maya's MMatrix transposed);
    f_vis: faces shown; f_mat: material slot per face (-1: none) into mat_keys; uv_sel:
    corners whose UV (or face / vertex) is selected; scale: local scale of the transform."""
    __slots__ = ("name", "key", "uv_id", "uv_table", "loop_vert", "f_start", "f_total", "f_vis",
                 "f_mat", "mat_keys", "uv_sel", "sel_readable", "co", "matrix", "scale")

    def __init__(self):
        self.name = ""
        self.key = None
        self.sel_readable = True
        self.scale = (1.0, 1.0, 1.0)
        self.matrix = np.eye(4)
        self.mat_keys = []

    @staticmethod
    def build(name, counts, uv_counts, uv_ids, uv_u, uv_v, vert_ids, points, matrix=None,
              f_mat=None, mat_keys=(), uv_sel_ids=None, face_sel=None, vert_sel=None, scale=(1, 1, 1),
              key=None):
        """From the arrays Maya hands out: polygon vertex counts and vertex ids
        (MFnMesh.getVertices), UV counts and UV ids per face (getAssignedUVs; a face without
        UVs has count 0), the UV table (getUVs) and the points (getPoints)."""
        A = MeshArrays()
        A.name, A.key = name, key if key is not None else name
        counts = np.asarray(counts, dtype=np.int64)
        uv_counts = np.asarray(uv_counts, dtype=np.int64)
        A.f_total = counts
        A.f_start = np.zeros(counts.size, dtype=np.int64)
        if counts.size > 1:
            np.cumsum(counts[:-1], out=A.f_start[1:])
        L = int(counts.sum())
        A.loop_vert = np.asarray(vert_ids, dtype=np.int64).reshape(-1)[:L]
        mapped = uv_counts == counts
        uid = np.full(L, -1, dtype=np.int64)
        ids = np.asarray(uv_ids, dtype=np.int64).reshape(-1)
        if ids.size:
            corner_mapped = np.repeat(mapped, counts)
            # getAssignedUVs lists ids only for mapped faces, in face order
            uid[corner_mapped] = ids[:int(np.count_nonzero(corner_mapped))]
        A.uv_id = uid
        A.uv_table = np.column_stack((np.asarray(uv_u, dtype=np.float64), np.asarray(uv_v, dtype=np.float64)))
        A.f_vis = mapped & (counts >= 3)
        A.f_mat = np.full(counts.size, -1, dtype=np.int64) if f_mat is None else np.asarray(f_mat, dtype=np.int64)
        A.mat_keys = list(mat_keys)
        A.co = np.asarray(points, dtype=np.float64).reshape(-1, np.asarray(points).shape[-1] if np.ndim(points) > 1 else 3)[:, :3]
        A.matrix = np.eye(4) if matrix is None else np.asarray(matrix, dtype=np.float64).reshape(4, 4)
        A.scale = tuple(float(s) for s in scale)
        sel = np.zeros(L, dtype=bool)
        if uv_sel_ids is not None and len(uv_sel_ids):
            mask = np.zeros(max(int(A.uv_table.shape[0]), 1), dtype=bool)
            s = np.asarray(uv_sel_ids, dtype=np.int64)
            mask[s[(s >= 0) & (s < mask.size)]] = True
            sel |= (uid >= 0) & mask[np.maximum(uid, 0)]
        if face_sel is not None and len(face_sel):
            fm = np.zeros(counts.size, dtype=bool)
            s = np.asarray(face_sel, dtype=np.int64)
            fm[s[(s >= 0) & (s < fm.size)]] = True
            sel |= np.repeat(fm, counts)
        if vert_sel is not None and len(vert_sel):
            vm = np.zeros(max(int(A.co.shape[0]), 1), dtype=bool)
            s = np.asarray(vert_sel, dtype=np.int64)
            vm[s[(s >= 0) & (s < vm.size)]] = True
            sel |= vm[A.loop_vert]
        A.uv_sel = sel
        return A

    def world_points(self):
        M = self.matrix
        return self.co @ M[:3, :3].T + M[:3, 3]

    def copy(self):
        """A new MeshArrays sharing this one's arrays (to change the matrix while the old one is
        still in use)."""
        B = MeshArrays()
        for f in MeshArrays.__slots__:
            setattr(B, f, getattr(self, f))
        return B

    def select(self, uv_ids):
        """Selected UVs (UV ids); None: the whole object counts as selected."""
        if uv_ids is None:
            self.uv_sel = np.ones(self.uv_id.size, dtype=bool)
            self.sel_readable = False
            return
        mask = np.zeros(max(int(self.uv_table.shape[0]), 1), dtype=bool)
        s = np.asarray(uv_ids, dtype=np.int64).reshape(-1)
        mask[s[(s >= 0) & (s < mask.size)]] = True
        self.uv_sel = (self.uv_id >= 0) & mask[np.maximum(self.uv_id, 0)]
        self.sel_readable = True


def _same(a, b):
    return a is b or (a.shape == b.shape and bool(np.array_equal(a, b)))


def same_uv_data(A, B):
    """Whether two readings of a mesh have the same UVs, faces shown and materials: what the
    shells and the gaps depend on."""
    return (list(A.mat_keys) == list(B.mat_keys) and _same(A.f_total, B.f_total) and _same(A.uv_id, B.uv_id)
            and _same(A.uv_table, B.uv_table) and _same(A.f_vis, B.f_vis) and _same(A.f_mat, B.f_mat))


def same_3d_data(A, B):
    """Whether two readings of a mesh have the same points, faces and transform: what texel
    density and orientation depend on (with the UV data)."""
    return (tuple(A.scale) == tuple(B.scale) and _same(A.matrix, B.matrix) and _same(A.loop_vert, B.loop_vert)
            and _same(A.co, B.co))


# ---------------------------------------------------------------------------
# UV shells from the arrays (vectorized)
# ---------------------------------------------------------------------------

class _Shells:
    """Faces shown, grouped into UV shells. Corners are kept in compact order: shown faces in
    mesh order, corners in face order. vid: UV vertex (the mesh's UV id, renumbered) per corner."""
    __slots__ = ("fidx", "tot", "off", "lid", "lface", "nxt", "vid", "uvid", "vx", "vy",
                 "area2", "face_shell", "nshell")


def _shells(A, vis):
    S = _Shells()
    fidx = np.flatnonzero(vis)
    nf = fidx.size
    tot = A.f_total[fidx].astype(np.int64)
    off = _face_offsets(tot)
    L = int(tot.sum()) if nf else 0
    lid = np.repeat(A.f_start[fidx].astype(np.int64) - off, tot) + np.arange(L, dtype=np.int64)
    lface = np.repeat(np.arange(nf, dtype=np.int64), tot)
    nxt = np.arange(1, L + 1, dtype=np.int64)
    if nf:
        nxt[off + tot - 1] = off
    ids = A.uv_id[lid]
    if L:
        uniq, first_pos, inv = np.unique(ids, return_index=True, return_inverse=True)
        rank = np.argsort(first_pos, kind='stable')  # UV vertices numbered by first appearance
        new = np.empty(rank.size, dtype=np.int64)
        new[rank] = np.arange(rank.size)
        vid = new[np.asarray(inv).reshape(-1)]
        first = first_pos[rank]
        S.uvid = uniq[rank]
    else:
        vid = first = _EMPTY_I
        S.uvid = _EMPTY_I
    vx = A.uv_table[S.uvid, 0] if S.uvid.size else _EMPTY_F
    vy = A.uv_table[S.uvid, 1] if S.uvid.size else _EMPTY_F
    xa, ya = vx[vid], vy[vid]
    area2 = _face_sums_in_order(xa * ya[nxt] - xa[nxt] * ya, off, tot)
    # faces sharing a UV vertex belong to one shell
    b = lface[first][vid] if L else _EMPTY_I
    m = lface != b
    root = _components(nf, lface[m], b[m])
    is_root = root == np.arange(nf)  # roots are the first face of each shell, in face order
    label = np.cumsum(is_root) - 1
    S.fidx, S.tot, S.off, S.lid, S.lface, S.nxt = fidx, tot, off, lid, lface, nxt
    S.vid, S.vx, S.vy, S.area2 = vid, vx, vy, area2
    S.face_shell = label[root].astype(np.int64)
    S.nshell = int(np.count_nonzero(is_root))
    return S


def _gap_pieces(S, A, want_sel):
    """Ordered shell borders, per-shell selection and area, fan triangles of mirrored shells
    and every UV edge (wireframe): the input of the gap measurement and of the drawing."""
    vid, nxt, nv = S.vid, S.nxt, S.vx.size
    eb = vid[nxt]
    key = np.minimum(vid, eb) * max(nv, 1) + np.maximum(vid, eb)
    o = np.argsort(key, kind='stable')
    ks = key[o]
    brk = np.ones(ks.size, dtype=bool)
    if ks.size > 1:
        brk[1:] = ks[1:] != ks[:-1]
    run = np.cumsum(brk) - 1
    uses = np.empty(ks.size, dtype=np.int64)
    uses[o] = np.bincount(run)[run] if ks.size else run
    bk = np.flatnonzero(uses == 1)  # UV edges used by a single face
    b_face = S.lface[bk]
    fa = S.area2[b_face]
    b_sign = np.where(fa > 0.0, 1.0, np.where(fa < 0.0, -1.0, 0.0))
    ch_sh, ch_a, ch_b, ch_sg = _chain_all(S.face_shell[b_face], vid[bk], eb[bk], b_sign, S.nshell, nv)

    counts = np.bincount(ch_sh, minlength=S.nshell)
    shells_e = np.flatnonzero(counts)  # shells with a border, in shell order
    shell_area2 = np.bincount(S.face_shell, weights=S.area2, minlength=S.nshell)
    if not want_sel or not A.sel_readable:
        shell_sel = np.ones(S.nshell, dtype=bool)
    else:
        ls = A.uv_sel[S.lid]
        face_sel = np.logical_or.reduceat(ls, S.off) if S.off.size else np.zeros(0, dtype=bool)
        shell_sel = np.bincount(S.face_shell, weights=face_sel, minlength=S.nshell) > 0

    gid_of = np.full(S.nshell, -1, dtype=np.int64)
    gid_of[shells_e] = np.arange(shells_e.size)
    fsh = S.face_shell
    ff = np.flatnonzero((shell_area2[fsh] < 0.0) & (gid_of[fsh] >= 0))  # faces of mirrored shells
    nt = np.maximum(S.tot[ff] - 2, 0)
    tf = np.repeat(ff, nt)
    k = np.arange(int(nt.sum()), dtype=np.int64) - np.repeat(np.cumsum(nt) - nt, nt) + 1
    l0 = S.off[tf]
    v0, v1, v2 = vid[l0], vid[l0 + k], vid[l0 + k + 1]
    tris = np.stack((np.column_stack((S.vx[v0], S.vy[v0])), np.column_stack((S.vx[v1], S.vy[v1])),
                     np.column_stack((S.vx[v2], S.vy[v2]))), axis=1)
    wk = ks[brk]  # every UV edge once
    wa, wb = wk // max(nv, 1), wk % max(nv, 1)
    return {
        "wire_i": np.column_stack((wa, wb)).astype(np.int32),
        "shells": shells_e,
        "seg_a": np.column_stack((S.vx[ch_a], S.vy[ch_a])),
        "seg_b": np.column_stack((S.vx[ch_b], S.vy[ch_b])),
        "sign": ch_sg.astype(np.float64),
        "count": counts[shells_e],
        "sel": shell_sel[shells_e],
        "area2": shell_area2[shells_e],
        "tris": tris.reshape(-1, 3, 2),
        "tri_gid": gid_of[fsh[tf]],
        "wire_a": np.column_stack((S.vx[wa], S.vy[wa])),
        "wire_b": np.column_stack((S.vx[wb], S.vy[wb])),
    }


def _material_sets(keys):
    """(material keys without repeats, set id per slot): several slots holding the same
    material, or several empty ones, are one material set."""
    uniq = list(dict.fromkeys(keys))
    return uniq, np.asarray([uniq.index(k) for k in keys], dtype=np.int64)


def _face_material_keys(A):
    """Material key ids per face into a list of keys; faces without a material use ""."""
    keys = list(A.mat_keys) + [""]
    uniq, lut = _material_sets(keys)
    fm = np.where((A.f_mat < 0) | (A.f_mat >= len(A.mat_keys)), len(A.mat_keys), A.f_mat)
    return uniq, lut[fm]


def _cofactors(M):
    """_cofactor of every matrix of M (k, 3, 3), with the same arithmetic."""
    def cross(a, b):
        return np.stack((a[:, 1] * b[:, 2] - a[:, 2] * b[:, 1], a[:, 2] * b[:, 0] - a[:, 0] * b[:, 2],
                         a[:, 0] * b[:, 1] - a[:, 1] * b[:, 0]), axis=1)
    c0, c1, c2 = M[:, :, 0], M[:, :, 1], M[:, :, 2]
    return np.stack((cross(c1, c2), cross(c2, c0), cross(c0, c1)), axis=2)


def _xform3(V, M, idx=None):
    """M applied to the rows of V: out[k] = M @ V[k]. M: one 3x3 matrix, or one per object
    with idx telling each row's object. Element by element (no BLAS), so one mesh alone and
    the same mesh in a batch give the same bits."""
    out = np.empty((V.shape[0], 3))
    for i in range(3):
        if idx is None:
            m0, m1, m2 = M[i, 0], M[i, 1], M[i, 2]
        else:
            m0, m1, m2 = M[idx, i, 0], M[idx, i, 1], M[idx, i, 2]
        out[:, i] = V[:, 0] * m0 + V[:, 1] * m1 + V[:, 2] * m2
    return out


def _shell_orientation(S, A, M3, cx, cy, face_area, axes, face_obj=None):
    """Where the scene's up axis runs across each shell, as a unit direction in UV space.

    Each face's UV -> 3D mapping is fitted to its corners (least squares); the axis, projected
    onto the face, is taken back to UV space and weighted by how much of it lies along the face
    and by the face's area. Shells lying flat use the second axis instead.
    `axes`: ((component, sign), ...) in priority order (see up_axes).
    Returns directions (NaN: no arrow) and the axis per shell (0 none, component + 1)."""
    ns, fsh, lf = S.nshell, S.face_shell, S.lface
    du = S.vx[S.vid] - cx[lf]
    dv = S.vy[S.vid] - cy[lf]
    # world orientation and scale
    P = _xform3(A.co[A.loop_vert[S.lid]].astype(np.float64), M3, None if face_obj is None else face_obj[lf])
    dP = P - (np.add.reduceat(P, S.off, axis=0) / S.tot[:, None])[lf]
    suu = np.add.reduceat(du * du, S.off)
    suv = np.add.reduceat(du * dv, S.off)
    svv = np.add.reduceat(dv * dv, S.off)
    spu = np.add.reduceat(dP * du[:, None], S.off, axis=0)
    spv = np.add.reduceat(dP * dv[:, None], S.off, axis=0)
    orient = np.full((ns, 2), np.nan)
    axis = np.zeros(ns, dtype=np.int8)
    with np.errstate(divide='ignore', invalid='ignore', over='ignore'):
        det = suu * svv - suv * suv
        ok = det > 1e-12 * (suu + svv) ** 2
        Ju = (spu * svv[:, None] - spv * suv[:, None]) / det[:, None]  # dP/du
        Jv = (spv * suu[:, None] - spu * suv[:, None]) / det[:, None]  # dP/dv
        g11 = (Ju * Ju).sum(axis=1)
        g12 = (Ju * Jv).sum(axis=1)
        g22 = (Jv * Jv).sum(axis=1)
        gdet = g11 * g22 - g12 * g12
        ok &= gdet > 1e-12 * (g11 + g22) ** 2
        total = np.bincount(fsh, weights=face_area, minlength=ns)
        for comp, sign in axes:
            b1, b2 = Ju[:, comp] * sign, Jv[:, comp] * sign
            wu = (g22 * b1 - g12 * b2) / gdet  # UV step whose 3D image is the axis on the face
            wv = (g11 * b2 - g12 * b1) / gdet
            along = b1 * wu + b2 * wv          # squared length of the axis on the face, 0..1
            wn = np.hypot(wu, wv)
            good = ok & np.isfinite(wn) & (wn > 0.0) & (along > 0.0)
            wt = np.where(good, face_area * np.sqrt(np.clip(along, 0.0, 1.0)) / np.where(good, wn, 1.0), 0.0)
            vx = np.bincount(fsh, weights=np.where(good, wu, 0.0) * wt, minlength=ns)
            vy = np.bincount(fsh, weights=np.where(good, wv, 0.0) * wt, minlength=ns)
            mag = np.hypot(vx, vy)
            pick = (axis == 0) & (mag > 0.0) & (mag >= ORIENT_MIN * total)
            orient[pick, 0] = vx[pick] / mag[pick]
            orient[pick, 1] = vy[pick] / mag[pick]
            axis[pick] = comp + 1
    return orient, axis


def _shell_pieces(S, A, M3, fmat, want_3d, want_orient=False, axes=((1, 1.0), (2, -1.0)), face_obj=None):
    """Per shell: label point, UV area and material; with 3D data also the world area (texel
    density, in square meters) and, if wanted, the up direction in UV space. M3: the mesh's
    3x3 matrix, or one per object of a batch with face_obj, the object of each shown face."""
    uv_abs = np.abs(S.area2) * 0.5
    fsh, ns = S.face_shell, S.nshell
    # label point: centroid of the face nearest to the shell's area-weighted centroid,
    # which is always on the shell (also for rings and concave shells)
    xa, ya = S.vx[S.vid], S.vy[S.vid]
    cx = np.add.reduceat(xa, S.off) / S.tot
    cy = np.add.reduceat(ya, S.off) / S.tot
    w = np.bincount(fsh, weights=uv_abs, minlength=ns)
    n = np.bincount(fsh, minlength=ns)
    wx = np.bincount(fsh, weights=uv_abs * cx, minlength=ns)
    wy = np.bincount(fsh, weights=uv_abs * cy, minlength=ns)
    mx = np.bincount(fsh, weights=cx, minlength=ns) / n
    my = np.bincount(fsh, weights=cy, minlength=ns) / n
    with np.errstate(divide='ignore', invalid='ignore'):
        sx = np.where(w > 0.0, wx / w, mx)
        sy = np.where(w > 0.0, wy / w, my)
    d2 = (cx - sx[fsh]) ** 2 + (cy - sy[fsh]) ** 2
    o = np.lexsort((d2, fsh))
    nearest = o[np.concatenate(([True], fsh[o][1:] != fsh[o][:-1]))]
    out = {
        "nshell": ns,
        "uv_area": w,
        "anchor": np.column_stack((cx[nearest], cy[nearest])),
        "mat": _dominant(fsh, fmat, uv_abs, ns),
    }
    if want_3d:
        cof = _cofactor(M3) if face_obj is None else _cofactors(M3)
        wv = _xform3(_face_area_vectors(S, A), cof, face_obj)
        world = np.sqrt(wv[:, 0] * wv[:, 0] + wv[:, 1] * wv[:, 1] + wv[:, 2] * wv[:, 2]) * METERS_PER_UNIT ** 2
        out["world_area"] = np.bincount(fsh, weights=world, minlength=ns)
        if want_orient:
            out["orient"], out["axis"] = _shell_orientation(S, A, M3, cx, cy, world, axes, face_obj)
    return out


class Geometry:
    __slots__ = ("seg_a", "seg_b", "seg_sign", "seg_shell", "shell_off", "shell_sel",
                 "bmin", "bmax", "pairs", "nshells", "nfaces",
                 "shell_area", "flipped", "flip_tris", "flip_tri_shell",
                 "tile", "tile_cross", "tile_cross_pts",
                 "td_nshells", "td_uv_area", "td_world_area", "td_anchor",
                 # every shown shell (the arrays above cover the shells with a border, "gap shells")
                 "sh_n", "sh_obj", "sh_mat", "sh_anchor", "sh_orient", "sh_axis", "sh_gid",
                 "gap_shell", "shell_mat", "mat_keys", "mat_total", "mat_vis", "obj_names", "obj_keys",
                 "obj_scale", "wire_a", "wire_b", "obj_corner_uvid", "obj_corner_shell",
                 "obj_fidx", "obj_face_shell", "obj_serial", "obj_uvsig", "obj_parts", "src_serials", "layer")

    def __init__(self):
        self.seg_a = _EMPTY2
        self.seg_b = _EMPTY2
        self.seg_sign = _EMPTY_F
        self.seg_shell = _EMPTY_I
        self.shell_off = np.zeros(1, dtype=np.int64)
        self.shell_sel = np.empty(0, dtype=bool)
        self.bmin = _EMPTY2
        self.bmax = _EMPTY2
        self.pairs = None          # overlapping pairs (_Pairs), when computed for this geometry
        self.nshells = 0
        self.nfaces = 0
        self.shell_area = _EMPTY_F
        self.flipped = np.empty(0, dtype=bool)
        self.flip_tris = np.empty((0, 3, 2))
        self.flip_tri_shell = _EMPTY_I
        self.tile = np.empty((0, 2), dtype=np.int64)
        self.tile_cross = np.empty(0, dtype=bool)
        self.tile_cross_pts = {}
        self.td_nshells = 0
        self.td_uv_area = _EMPTY_F
        self.td_world_area = _EMPTY_F
        self.td_anchor = _EMPTY2
        self.sh_n = 0
        self.sh_obj = _EMPTY_I
        self.sh_mat = _EMPTY_I
        self.sh_anchor = _EMPTY2
        self.sh_orient = _EMPTY2
        self.sh_axis = np.empty(0, dtype=np.int8)
        self.sh_gid = _EMPTY_I
        self.gap_shell = _EMPTY_I
        self.shell_mat = _EMPTY_I
        self.mat_keys = []
        self.mat_total = _EMPTY_I
        self.mat_vis = _EMPTY_I
        self.obj_names = []
        self.obj_keys = []
        self.obj_scale = []
        self.wire_a = _EMPTY2
        self.wire_b = _EMPTY2
        self.obj_corner_uvid = []
        self.obj_corner_shell = []
        self.obj_fidx = []         # per object: mesh face ids of the shown faces
        self.obj_face_shell = []   # per object: shell (all-shell index) of each shown face
        self.obj_serial = []       # per object: serial number of its extraction (ObjectParts)
        self.obj_uvsig = []        # per object: what its UV data depends on (measurement caches)
        self.obj_parts = []        # per object: its ObjectParts
        self.src_serials = ()      # serial numbers of all parts assembled (also without shells)
        self.layer = None          # the UV layer (build_layer), when built


def selected_shells(geo, sel_by_key):
    """Shells (all-shell mask) with a selected UV. `sel_by_key`: per object key, the selected
    UV ids, or None when the whole object counts as selected (also for keys not listed)."""
    out = np.zeros(geo.sh_n, dtype=bool)
    for key, cu, cs in zip(geo.obj_keys, geo.obj_corner_uvid, geo.obj_corner_shell):
        if not cs.size:
            continue
        ids = sel_by_key.get(key)
        if ids is None:
            out[cs] = True
            continue
        ids = np.asarray(ids, dtype=np.int64).reshape(-1)
        ids = ids[ids >= 0]
        if not ids.size:
            continue
        mask = np.zeros(int(max(cu.max(initial=0), ids.max(initial=0))) + 1, dtype=bool)
        mask[ids] = True
        out[cs[mask[cu]]] = True
    return out


def apply_selection(geo, sel_by_key):
    """Set the selected shells of an extracted geometry (shell_sel, for Selected Shells Only)
    without extracting again. Returns the all-shell mask."""
    sel = selected_shells(geo, sel_by_key)
    if geo.gap_shell.size:
        geo.shell_sel = sel[geo.gap_shell]
    return sel


class ObjectParts:
    """One object's share of a Geometry (see extract_object): its shells, borders and per-shell
    data, with material ids local to the object (`uniq`: its material keys). `serial` tells
    extractions apart (caches key on it); `td`, `orient`: what was computed."""
    __slots__ = ("serial", "name", "key", "scale", "uniq", "total", "shown", "nfaces", "gap", "sh",
                 "corner_uvid", "corner_shell", "fidx", "face_shell", "td", "orient", "uv_sig",
                 "vid", "vxy", "tot", "corner_vert", "wire_i")


_SERIAL = [0]


def _next_serial():
    _SERIAL[0] += 1
    return _SERIAL[0]


def extract_object(A, want_sel=True, want_td=True, want_orient=False, axes=((1, 1.0), (2, -1.0)), hidden=(),
                   uv_sig=None):
    """The part of extract() that depends on one mesh only, so it can be kept while other
    meshes change. A tie between materials covering the same area of a shell goes to the
    object's first material slot. `uv_sig`: a value that changes whenever the mesh's UVs,
    faces or materials (or the hidden sets) change - gap measurements are kept by it, also
    across moves of the object; by default every extraction is new."""
    P = ObjectParts()
    P.serial = _next_serial()
    P.uv_sig = ("serial", P.serial) if uv_sig is None else uv_sig
    P.name, P.key, P.scale = A.name, A.key, tuple(A.scale)
    P.td, P.orient = bool(want_td), bool(want_td and want_orient)
    uniq, fkey = _face_material_keys(A)
    P.uniq = uniq
    vis = A.f_vis
    S = _shells(A, vis)
    hidden = set(hidden)
    if hidden and S.fidx.size:
        # whole shells, by the material covering most of each shell (as the list shows them)
        hid = np.asarray([k in hidden for k in uniq], dtype=bool)
        if hid.any():
            dom = _dominant(S.face_shell, fkey[S.fidx], np.abs(S.area2) * 0.5, S.nshell)
            gone = hid[dom][S.face_shell]
            if gone.any():
                vis = vis.copy()
                vis[S.fidx[gone]] = False
                S = _shells(A, vis)
    P.total = np.bincount(fkey[A.f_vis], minlength=len(uniq)).astype(np.int64)
    P.shown = np.bincount(fkey[vis], minlength=len(uniq)).astype(np.int64)
    P.nfaces = int(S.fidx.size)
    P.gap = P.sh = None
    if not S.fidx.size:
        return P
    P.gap = _gap_pieces(S, A, want_sel)
    P.sh = _shell_pieces(S, A, A.matrix[:3, :3], fkey[S.fidx], want_td, want_td and want_orient, axes)
    P.corner_uvid = S.uvid[S.vid]
    P.corner_shell = S.face_shell[S.lface]
    P.fidx = S.fidx
    P.face_shell = S.face_shell
    # for drawing and picking in the UV view: UV vertices, corners, faces, edges
    P.vid = S.vid.astype(np.int32)
    P.vxy = np.column_stack((S.vx, S.vy))
    P.tot = S.tot.astype(np.int32)
    P.corner_vert = A.loop_vert[S.lid].astype(np.int32)
    P.wire_i = P.gap.pop("wire_i")
    return P


BATCH_MESH_FACES = 20000    # meshes smaller than this are extracted together, in batches
BATCH_FACES = 300000        # of at most this many faces


def extract_many(meshes, want_sel=True, want_td=True, want_orient=False, axes=((1, 1.0), (2, -1.0)),
                 hidden=(), uv_sigs=None, cancelled=None):
    """extract_object for every mesh: [ObjectParts] in the same order, the same results. Small
    meshes are worked on together in one pass - a scene of a thousand small objects costs
    about as much as one mesh with their faces. `cancelled`: a function telling to stop
    (returns None then)."""
    out = [None] * len(meshes)
    sigs = list(uv_sigs) if uv_sigs is not None else [None] * len(meshes)
    batch, faces = [], 0

    def flush():
        if len(batch) == 1:
            i = batch[0]
            out[i] = extract_object(meshes[i], want_sel, want_td, want_orient, axes, hidden, sigs[i])
        elif batch:
            for i, P in zip(batch, _extract_batch([meshes[i] for i in batch], want_sel, want_td, want_orient,
                                                  axes, hidden, [sigs[i] for i in batch])):
                out[i] = P
        del batch[:]

    for i, A in enumerate(meshes):
        if cancelled is not None and cancelled():
            return None
        n = int(A.f_total.size)
        if n >= BATCH_MESH_FACES:
            out[i] = extract_object(A, want_sel, want_td, want_orient, axes, hidden, sigs[i])
            continue
        if batch and faces + n > BATCH_FACES:
            flush()
            faces = 0
        batch.append(i)
        faces += n
    flush()
    return out


def _extract_batch(meshes, want_sel, want_td, want_orient, axes, hidden, uv_sigs):
    """extract_object of several meshes at once: they are laid one after another as one mesh
    (UV ids and vertices renumbered), shells are found in one pass, and the results are cut
    back into one ObjectParts per mesh."""
    n = len(meshes)
    cnt = lambda f: np.array([f(A) for A in meshes], dtype=np.int64)  # noqa: E731
    nf, nl = cnt(lambda A: A.f_total.size), cnt(lambda A: A.loop_vert.size)
    nuv, nv = cnt(lambda A: A.uv_table.shape[0]), cnt(lambda A: A.co.shape[0])
    foff, loff = np.concatenate(([0], np.cumsum(nf))), np.concatenate(([0], np.cumsum(nl)))
    uoff, voff = np.concatenate(([0], np.cumsum(nuv))), np.concatenate(([0], np.cumsum(nv)))
    X = MeshArrays()
    X.f_total = np.concatenate([A.f_total for A in meshes]).astype(np.int64)
    X.f_start = np.concatenate([A.f_start + int(o) for A, o in zip(meshes, loff[:-1])]).astype(np.int64)
    X.loop_vert = np.concatenate([A.loop_vert + int(o) for A, o in zip(meshes, voff[:-1])]).astype(np.int64)
    X.uv_id = np.concatenate([np.where(A.uv_id >= 0, A.uv_id + int(o), -1) for A, o in zip(meshes, uoff[:-1])])
    X.uv_table = np.concatenate([A.uv_table for A in meshes]).reshape(-1, 2)
    X.co = np.concatenate([A.co for A in meshes]).reshape(-1, 3)
    X.f_vis = np.concatenate([A.f_vis for A in meshes])
    X.uv_sel = np.concatenate([A.uv_sel for A in meshes])
    X.sel_readable = True  # (meshes selected as a whole have every corner selected)
    fobj = np.repeat(np.arange(n, dtype=np.int64), nf)
    mats = [_face_material_keys(A) for A in meshes]
    fkey = np.concatenate([k for _u, k in mats])
    kbase = np.concatenate(([0], np.cumsum([len(u) for u, _k in mats])))
    M3 = np.stack([A.matrix[:3, :3] for A in meshes])

    vis = X.f_vis
    S = _shells(X, vis)
    hidden = set(hidden)
    if hidden and S.fidx.size:
        hid = np.array([k in hidden for u, _k in mats for k in u], dtype=bool)
        if hid.any():
            dom = _dominant(S.face_shell, fkey[S.fidx], np.abs(S.area2) * 0.5, S.nshell)
            sobj = np.zeros(S.nshell, dtype=np.int64)
            sobj[S.face_shell] = fobj[S.fidx]
            gone = hid[kbase[sobj] + dom][S.face_shell]
            if gone.any():
                vis = vis.copy()
                vis[S.fidx[gone]] = False
                S = _shells(X, vis)
    flat = kbase[fobj] + fkey
    total = np.bincount(flat[X.f_vis], minlength=int(kbase[-1]))
    shown = np.bincount(flat[vis], minlength=int(kbase[-1]))

    parts = []
    for i, A in enumerate(meshes):
        P = ObjectParts()
        P.serial = _next_serial()
        P.uv_sig = ("serial", P.serial) if uv_sigs[i] is None else uv_sigs[i]
        P.name, P.key, P.scale = A.name, A.key, tuple(A.scale)
        P.td, P.orient = bool(want_td), bool(want_td and want_orient)
        P.uniq = mats[i][0]
        P.total = total[kbase[i]:kbase[i + 1]].astype(np.int64)
        P.shown = shown[kbase[i]:kbase[i + 1]].astype(np.int64)
        P.nfaces = 0
        P.gap = P.sh = None
        parts.append(P)
    if not S.fidx.size:
        return parts

    fo = fobj[S.fidx]                                  # object of each shown face (ascending)
    gap = _gap_pieces(S, X, want_sel)
    sh = _shell_pieces(S, X, M3, fkey[S.fidx], want_td, want_td and want_orient, axes, face_obj=fo)
    every = np.arange(n + 1)
    f_off = np.searchsorted(fo, every)                 # shown faces of each object
    c_off = np.concatenate((S.off, [S.vid.size]))[f_off]   # their corners
    sobj = np.zeros(S.nshell, dtype=np.int64)
    sobj[S.face_shell] = fo                            # shells: numbered by their first face
    s_off = np.searchsorted(sobj, every)
    seen = np.maximum.accumulate(S.vid) + 1 if S.vid.size else S.vid   # UV vertices met so far
    v_off = np.where(c_off > 0, seen[np.maximum(c_off, 1) - 1], 0)
    g_off = np.searchsorted(gap["shells"], s_off)      # shells with a border
    seg_off = np.concatenate(([0], np.cumsum(gap["count"])))[g_off]
    t_off = np.searchsorted(sobj[gap["shells"]][gap["tri_gid"]], every) if gap["tri_gid"].size \
        else np.zeros(n + 1, dtype=np.int64)
    w_off = np.searchsorted(gap["wire_i"][:, 0], v_off)
    corner_uvid = S.uvid[S.vid]
    corner_shell = S.face_shell[S.lface]
    corner_vert = X.loop_vert[S.lid]
    vxy = np.column_stack((S.vx, S.vy))
    for i, P in enumerate(parts):
        f0, f1 = int(f_off[i]), int(f_off[i + 1])
        if f1 == f0:
            continue
        c0, c1, s0, s1 = int(c_off[i]), int(c_off[i + 1]), int(s_off[i]), int(s_off[i + 1])
        v0, v1, g0, g1 = int(v_off[i]), int(v_off[i + 1]), int(g_off[i]), int(g_off[i + 1])
        e0, e1, t0, t1 = int(seg_off[i]), int(seg_off[i + 1]), int(t_off[i]), int(t_off[i + 1])
        w0, w1 = int(w_off[i]), int(w_off[i + 1])
        P.nfaces = f1 - f0
        P.gap = {"shells": gap["shells"][g0:g1] - s0, "seg_a": gap["seg_a"][e0:e1], "seg_b": gap["seg_b"][e0:e1],
                 "sign": gap["sign"][e0:e1], "count": gap["count"][g0:g1], "sel": gap["sel"][g0:g1],
                 "area2": gap["area2"][g0:g1], "tris": gap["tris"][t0:t1], "tri_gid": gap["tri_gid"][t0:t1] - g0,
                 "wire_a": gap["wire_a"][w0:w1], "wire_b": gap["wire_b"][w0:w1]}
        P.sh = {"nshell": s1 - s0, "uv_area": sh["uv_area"][s0:s1], "anchor": sh["anchor"][s0:s1],
                "mat": sh["mat"][s0:s1]}
        if want_td:
            P.sh["world_area"] = sh["world_area"][s0:s1]
            if want_orient:
                P.sh["orient"], P.sh["axis"] = sh["orient"][s0:s1], sh["axis"][s0:s1]
        P.corner_uvid = corner_uvid[c0:c1] - int(uoff[i])
        P.corner_shell = corner_shell[c0:c1] - s0
        P.fidx = S.fidx[f0:f1] - int(foff[i])
        P.face_shell = S.face_shell[f0:f1] - s0
        P.vid = (S.vid[c0:c1] - v0).astype(np.int32)
        P.vxy = vxy[v0:v1]
        P.tot = S.tot[f0:f1].astype(np.int32)
        P.corner_vert = (corner_vert[c0:c1] - int(voff[i])).astype(np.int32)
        P.wire_i = (gap["wire_i"][w0:w1] - v0).astype(np.int32)
    return parts


def extract(meshes, want_sel=True, want_td=True, want_orient=False, axes=((1, 1.0), (2, -1.0)),
            hidden=()):
    """Shells, borders and per-shell data of the shown faces of `meshes` (MeshArrays).
    `hidden`: material keys whose shells are left out (a shell's material is the one covering
    most of its UV area)."""
    return assemble(extract_many(meshes, want_sel, want_td, want_orient, axes, hidden),
                    want_td, want_td and want_orient)


def assemble(parts, want_td=True, want_orient=False):
    """A Geometry from the objects' parts (extract_object), in order. Material ids are global:
    the order in which the keys first appear."""
    geo = Geometry()
    gaps, shs = [], []
    mat_id, mat_total, mat_vis = {}, [], []
    want_orient = want_td and want_orient and all(P.orient for P in parts if P.gap is not None)
    want_td = want_td and all(P.td for P in parts if P.gap is not None)

    for P in parts:
        ids = []
        for key in P.uniq:
            i = mat_id.get(key)
            if i is None:
                i = mat_id[key] = len(mat_total)
                mat_total.append(0)
                mat_vis.append(0)
            ids.append(i)
        ids = np.asarray(ids, dtype=np.int64)
        for k, i in enumerate(ids.tolist()):
            mat_total[i] += int(P.total[k])
            mat_vis[i] += int(P.shown[k])
        if P.gap is None:
            continue
        geo.nfaces += P.nfaces
        gaps.append(P.gap)
        p = dict(P.sh)
        p["mat"] = ids[p["mat"]]
        p["obj"] = len(geo.obj_names)
        shs.append(p)
        geo.obj_names.append(P.name)
        geo.obj_keys.append(P.key)
        geo.obj_scale.append(tuple(P.scale))
        geo.obj_serial.append(P.serial)
        geo.obj_uvsig.append(P.uv_sig)
        geo.obj_parts.append(P)

    geo.mat_keys = list(mat_id)
    geo.mat_total = np.asarray(mat_total, dtype=np.int64)
    geo.mat_vis = np.asarray(mat_vis, dtype=np.int64)
    geo.src_serials = tuple(P.serial for P in parts)
    if not shs:
        return geo
    base = np.cumsum([0] + [p["nshell"] for p in shs])
    n = geo.sh_n = int(base[-1])
    geo.sh_obj = np.repeat(np.asarray([p["obj"] for p in shs], dtype=np.int64), np.diff(base))
    geo.sh_mat = np.concatenate([p["mat"] for p in shs])
    geo.sh_anchor = np.concatenate([p["anchor"] for p in shs])
    geo.sh_gid = np.full(n, -1, dtype=np.int64)
    objs = geo.obj_parts
    geo.obj_corner_uvid = [P.corner_uvid for P in objs]
    geo.obj_corner_shell = [P.corner_shell + b for P, b in zip(objs, base[:-1].tolist())]
    geo.obj_fidx = [P.fidx for P in objs]
    geo.obj_face_shell = [P.face_shell + b for P, b in zip(objs, base[:-1].tolist())]
    if want_td:
        geo.td_nshells = n
        geo.td_uv_area = np.concatenate([p["uv_area"] for p in shs])
        geo.td_world_area = np.concatenate([p["world_area"] for p in shs])
        geo.td_anchor = geo.sh_anchor
    if want_td and want_orient:
        geo.sh_orient = np.concatenate([p["orient"] for p in shs])
        geo.sh_axis = np.concatenate([p["axis"] for p in shs])
    else:
        geo.sh_orient = np.full((n, 2), np.nan)
        geo.sh_axis = np.zeros(n, dtype=np.int8)
    geo.wire_a = np.concatenate([g["wire_a"] for g in gaps])
    geo.wire_b = np.concatenate([g["wire_b"] for g in gaps])

    S = int(sum(g["count"].size for g in gaps))
    if S == 0:
        return geo
    geo.gap_shell = np.concatenate([g["shells"] + b for g, b in zip(gaps, base[:-1])]).astype(np.int64)
    geo.sh_gid[geo.gap_shell] = np.arange(S)
    geo.shell_mat = geo.sh_mat[geo.gap_shell]
    gbase = np.cumsum([0] + [g["count"].size for g in gaps])
    geo.seg_a = np.concatenate([g["seg_a"] for g in gaps])
    geo.seg_b = np.concatenate([g["seg_b"] for g in gaps])
    geo.seg_sign = np.concatenate([g["sign"] for g in gaps])
    geo.shell_off = np.concatenate(([0], np.cumsum(np.concatenate([g["count"] for g in gaps])))).astype(np.int64)
    geo.shell_sel = np.concatenate([g["sel"] for g in gaps]).astype(bool)
    geo.seg_shell = np.repeat(np.arange(S, dtype=np.int64), np.diff(geo.shell_off))
    lo = np.minimum(geo.seg_a, geo.seg_b)
    hi = np.maximum(geo.seg_a, geo.seg_b)
    geo.bmin = np.minimum.reduceat(lo, geo.shell_off[:-1], axis=0)
    geo.bmax = np.maximum.reduceat(hi, geo.shell_off[:-1], axis=0)
    geo.nshells = S
    geo.shell_area = np.concatenate([g["area2"] for g in gaps]) * 0.5
    geo.flipped = geo.shell_area < 0.0
    geo.flip_tris = np.concatenate([g["tris"] for g in gaps]).astype(np.float64).reshape(-1, 3, 2)
    geo.flip_tri_shell = np.concatenate([g["tri_gid"] + b for g, b in zip(gaps, gbase[:-1])]).astype(np.int64)
    geo.tile = np.floor((geo.bmin + geo.bmax) * 0.5).astype(np.int64)
    geo.tile_cross = (np.floor(geo.bmin + TILE_EPS) < np.floor(geo.bmax - TILE_EPS)).any(axis=1)
    geo.tile_cross_pts = _tile_crossings(geo)
    return geo


# ---------------------------------------------------------------------------
# Shared with the Blender add-on: borders, overlaps, gap measurement, texel density,
# label placement
# ---------------------------------------------------------------------------

def _chain_border(edges):
    """Order border edges (a, b, sign) into continuous loops.

    `sign` tells on which side of a->b the shell interior lies (+1 left, -1 right,
    0 unknown); it is flipped when an edge has to be walked backwards.
    """
    out_map, in_map = {}, {}
    for i, (a, b, _s) in enumerate(edges):
        out_map.setdefault(a, []).append(i)
        in_map.setdefault(b, []).append(i)
    used = [False] * len(edges)
    ordered = []
    for i0 in range(len(edges)):
        if used[i0]:
            continue
        used[i0] = True
        a, b, s = edges[i0]
        ordered.append((a, b, s))
        start, cur = a, b
        while cur != start:
            nxt, rev = -1, False
            for j in out_map.get(cur, ()):
                if not used[j]:
                    nxt = j
                    break
            if nxt < 0:
                for j in in_map.get(cur, ()):
                    if not used[j]:
                        nxt, rev = j, True
                        break
            if nxt < 0:
                break  # open border (non-manifold UVs): start a new chain
            used[nxt] = True
            a2, b2, s2 = edges[nxt]
            if rev:
                ordered.append((b2, a2, -s2))
                cur = a2
            else:
                ordered.append((a2, b2, s2))
                cur = b2
    return ordered


def _face_offsets(tot):
    off = np.zeros(tot.size, dtype=np.int64)
    if tot.size > 1:
        np.cumsum(tot[:-1], out=off[1:])
    return off


def _components(n, a, b):
    """Connected components of n nodes joined by edges a-b; label = smallest node index."""
    p = np.arange(n, dtype=np.int64)
    while a.size:
        pa, pb = p[a], p[b]
        m = pa != pb
        if not m.any():
            break
        a, b, pa, pb = a[m], b[m], pa[m], pb[m]
        np.minimum.at(p, np.maximum(pa, pb), np.minimum(pa, pb))  # hook a root to a smaller one
        while True:  # pointer jumping until every node points at its root
            q = p[p]
            if np.array_equal(q, p):
                break
            p = q
    return p


def _face_sums_in_order(values, off, tot):
    """values[off : off + tot] summed per face, corner by corner in order (bit-exact with
    a plain Python loop, unlike numpy's pairwise sums)."""
    out = np.zeros(tot.size)
    if not tot.size:
        return out
    tmin, tmax = int(tot.min()), int(tot.max())
    for k in range(tmin):
        out += values[off + k]
    if tmax > tmin:
        order = np.argsort(-tot, kind='stable')
        neg_sorted = -tot[order]
        for k in range(tmin, tmax):
            idx = order[:int(np.searchsorted(neg_sorted, -k, side='left'))]  # faces with > k corners
            out[idx] += values[off[idx] + k]
    return out


def _chain_all(sh, a, b, sg, nshell, nv):
    """Border edges ordered into loops per shell, exactly like _chain_border: vectorized
    for shells whose border is a set of simple, consistently wound loops, _chain_border
    itself for the others (mixed winding, several loops meeting at a vertex)."""
    if not a.size:
        return sh, a, b, sg
    bad_v = (np.bincount(a, minlength=nv) != 1) | (np.bincount(b, minlength=nv) != 1)
    bad_shell = np.zeros(nshell, dtype=bool)
    bad_shell[sh[bad_v[a] | bad_v[b]]] = True
    pick = []
    se = np.flatnonzero(~bad_shell[sh])
    if se.size:
        ne = se.size
        ids = np.arange(ne, dtype=np.int64)
        start_of = np.full(nv, -1, dtype=np.int64)
        start_of[a[se]] = ids
        succ = start_of[b[se]]
        head, p, span = ids.copy(), succ.copy(), 1
        while span < ne:  # smallest edge index of each loop, by pointer doubling
            head = np.minimum(head, head[p])
            p = p[p]
            span *= 2
        s = succ.copy()
        pred = np.empty(ne, dtype=np.int64)
        pred[succ] = ids
        s[pred[head == ids]] = -1  # cut each loop just before its first edge
        d = (s >= 0).astype(np.int64)
        while True:  # list ranking: steps left to the end of the loop
            m = np.flatnonzero(s >= 0)
            if not m.size:
                break
            sm = s[m]
            d[m] += d[sm]
            s[m] = s[sm]
        g = se[np.lexsort((d[head] - d, head, sh[se]))]
        pick.append((sh[g], a[g], b[g], sg[g]))
    bad = np.flatnonzero(bad_shell[sh])
    if bad.size:
        bad = bad[np.argsort(sh[bad], kind='stable')]
        cut = np.flatnonzero(np.diff(sh[bad])) + 1
        for grp in np.split(bad, cut):
            chain = _chain_border(list(zip(a[grp].tolist(), b[grp].tolist(), sg[grp].tolist())))
            ca, cb, cs = zip(*chain)
            pick.append((np.full(len(chain), sh[grp[0]], dtype=np.int64),
                         np.asarray(ca, dtype=np.int64), np.asarray(cb, dtype=np.int64),
                         np.asarray(cs, dtype=np.float64)))
    sh2, a2, b2, sg2 = (np.concatenate(x) for x in zip(*pick))
    o = np.argsort(sh2, kind='stable')
    return sh2[o], a2[o], b2[o], sg2[o]


def _cofactor(M3):
    """Cofactor matrix: maps area (normal) vectors the way M maps points."""
    c0, c1, c2 = M3[:, 0], M3[:, 1], M3[:, 2]
    return np.column_stack((np.cross(c1, c2), np.cross(c2, c0), np.cross(c0, c1)))


def _face_area_vectors(S, A):
    """Newell area vector of each face, in object space."""
    P = A.co[A.loop_vert[S.lid]].astype(np.float64)
    if not S.off.size:
        return np.empty((0, 3))
    Q = P[S.nxt]
    C = np.empty_like(P)  # the cross product P x Q, as np.cross computes it (without its overhead)
    np.subtract(P[:, 1] * Q[:, 2], P[:, 2] * Q[:, 1], out=C[:, 0])
    np.subtract(P[:, 2] * Q[:, 0], P[:, 0] * Q[:, 2], out=C[:, 1])
    np.subtract(P[:, 0] * Q[:, 1], P[:, 1] * Q[:, 0], out=C[:, 2])
    return np.add.reduceat(C, S.off, axis=0) * 0.5


def _dominant(fsh, fmat, weight, ns):
    """The material of each shell: the one covering most of its UV area (then more faces, lower id)."""
    out = np.zeros(ns, dtype=np.int64)
    if not fsh.size:
        return out
    nm = int(fmat.max()) + 1
    key = fsh * nm + fmat
    o = np.argsort(key, kind='stable')
    k = key[o]
    starts = np.flatnonzero(np.r_[True, k[1:] != k[:-1]])
    area = np.add.reduceat(weight[o], starts)
    count = np.diff(np.r_[starts, k.size])
    ush, um = k[starts] // nm, k[starts] % nm
    o2 = np.lexsort((um, -count, -area, ush))
    first = np.r_[True, ush[o2][1:] != ush[o2][:-1]]
    out[ush[o2][first]] = um[o2][first]
    return out


def _tile_crossings(geo):
    """{shell: points} where the border of a shell spanning a tile line crosses that line (UV)."""
    out = {}
    for s in np.flatnonzero(geo.tile_cross).tolist():
        o0, o1 = int(geo.shell_off[s]), int(geo.shell_off[s + 1])
        a, b = geo.seg_a[o0:o1], geo.seg_b[o0:o1]
        found = []
        for axis in (0, 1):
            k0 = int(np.floor(geo.bmin[s, axis] + TILE_EPS)) + 1
            k1 = int(np.floor(geo.bmax[s, axis] - TILE_EPS))
            for k in range(k0, k1 + 1):
                da, db = a[:, axis] - k, b[:, axis] - k
                hit = (da < 0.0) != (db < 0.0)
                if hit.any():
                    t = da[hit] / (da[hit] - db[hit])
                    found.append(a[hit] + (b[hit] - a[hit]) * t[:, None])
        if found:
            pts = np.concatenate(found)
            if len(pts) > MAX_CROSS_MARKS:
                pts = pts[np.linspace(0, len(pts) - 1, MAX_CROSS_MARKS).astype(np.int64)]
            out[s] = pts
    return out


def _ranges(starts, ends):
    """Concatenate index ranges [starts[i], ends[i])."""
    starts = np.asarray(starts, dtype=np.int64)
    lens = np.asarray(ends, dtype=np.int64) - starts
    total = int(lens.sum())
    if total <= 0:
        return _EMPTY_I
    return np.arange(total, dtype=np.int64) + np.repeat(starts - (np.cumsum(lens) - lens), lens)


def _cell_rows(x0, y0, x1, y1, cell):
    gx0 = np.floor(x0 / cell)
    gy0 = np.floor(y0 / cell)
    return float(((np.floor(x1 / cell) - gx0 + 1) * (np.floor(y1 / cell) - gy0 + 1)).sum())


def _box_cells(x0, y0, x1, y1, cell):
    """(box index, cell key) rows for every grid cell each axis-aligned box touches."""
    gx0 = np.floor(x0 / cell).astype(np.int64)
    gy0 = np.floor(y0 / cell).astype(np.int64)
    wx = np.floor(x1 / cell).astype(np.int64) - gx0 + 1
    wy = np.floor(y1 / cell).astype(np.int64) - gy0 + 1
    cnt = wx * wy
    box = np.repeat(np.arange(gx0.size, dtype=np.int64), cnt)
    local = np.arange(box.size, dtype=np.int64) - np.repeat(np.cumsum(cnt) - cnt, cnt)
    w = wx[box]
    key = (gx0[box] + local % w + _KEY_OFF) * _KEY_MUL + (gy0[box] + local // w + _KEY_OFF)
    return box, key


class _Grid:
    """Items with bounding boxes, bucketed by the grid cells they touch."""
    __slots__ = ("cell", "keys", "items")

    def __init__(self, cell, items, lo, hi):
        box, key = _box_cells(lo[:, 0], lo[:, 1], hi[:, 0], hi[:, 1], cell)
        order = np.argsort(key, kind='stable')
        self.cell = cell
        self.keys = key[order]
        self.items = items[box[order]]

    def query(self, lo, hi):
        """Rows (query index, first position, count) into `items`, sorted by query index."""
        qbox, qkey = _box_cells(lo[:, 0], lo[:, 1], hi[:, 0], hi[:, 1], self.cell)
        first = np.searchsorted(self.keys, qkey, side='left')
        count = np.searchsorted(self.keys, qkey, side='right') - first
        return qbox, first, count


def _expand(qbox, first, count):
    """Candidate pairs (query index, position in grid items), grouped by query."""
    total = int(count.sum())
    q = np.repeat(qbox, count)
    pos = np.arange(total, dtype=np.int64) + np.repeat(first - (np.cumsum(count) - count), count)
    return q, pos


def _query_chunks(qbox, count, nq, limit=CHUNK):
    """(row0, row1) ranges covering whole queries with roughly `limit` pairs each."""
    per_q = np.bincount(qbox, weights=count, minlength=nq)
    csum = np.cumsum(per_q)
    q0 = 0
    while q0 < nq:
        base = csum[q0 - 1] if q0 else 0.0
        q1 = min(nq, max(q0 + 1, int(np.searchsorted(csum, base + limit, side='right'))))
        yield (int(np.searchsorted(qbox, q0, side='left')),
               int(np.searchsorted(qbox, q1, side='left')))
        q0 = q1


def _segment_pieces(A, B, L, cell):
    """Split segments into pieces no longer than `cell`: (segment index, piece lo, piece hi)."""
    D = B - A
    k = np.maximum(1, np.ceil(L / cell)).astype(np.int64)
    seg = np.repeat(np.arange(len(A), dtype=np.int64), k)
    j = (np.arange(seg.size, dtype=np.int64) - np.repeat(np.cumsum(k) - k, k)).astype(np.float64)
    kk = k[seg].astype(np.float64)
    p0 = A[seg] + D[seg] * (j / kk)[:, None]
    p1 = A[seg] + D[seg] * ((j + 1.0) / kk)[:, None]
    return seg, np.minimum(p0, p1), np.maximum(p0, p1)


def _shell_grid(bmin, bmax):
    ext = (bmax - bmin).max(axis=1)
    cell = max(float(np.median(ext)), float(ext.max()) * 1e-3, 1e-12)
    while _cell_rows(bmin[:, 0], bmin[:, 1], bmax[:, 0], bmax[:, 1], cell) > MAX_GRID_ROWS:
        cell *= 2.0
    return _Grid(cell, np.arange(len(bmin), dtype=np.int64), bmin, bmax)


def _slopes(A, B):
    D = B - A
    return np.divide(D[:, 0], D[:, 1], out=np.zeros(len(D)), where=D[:, 1] != 0.0)


class _Bands:
    """Border segments bucketed by shell and horizontal band: a ray from a point only crosses
    segments spanning the point's height, so only its band's segments need testing."""
    __slots__ = ("h", "y0", "nb", "keys", "seg")

    def __init__(self, A, B, seg_shell):
        lo = np.minimum(A[:, 1], B[:, 1])
        hi = np.maximum(A[:, 1], B[:, 1])
        self.y0 = float(lo.min()) if lo.size else 0.0
        span = float(hi.max()) - self.y0 if hi.size else 0.0
        # bands as tall as the mean segment: each segment lands in about two bands, a shell's
        # band holds a handful of its segments
        h = max(float(np.mean(hi - lo)) if lo.size else 0.0, span / (1 << 20), 1e-12)
        while lo.size and float(np.sum(np.floor((hi - self.y0) / h) - np.floor((lo - self.y0) / h) + 1.0)) > MAX_GRID_ROWS:
            h *= 2.0
        self.h = h
        self.nb = int(np.floor(span / h)) + 2
        b0 = np.floor((lo - self.y0) / h).astype(np.int64)
        cnt = np.floor((hi - self.y0) / h).astype(np.int64) - b0 + 1
        seg = np.repeat(np.arange(lo.size, dtype=np.int64), cnt)
        band = b0[seg] + (np.arange(seg.size, dtype=np.int64) - np.repeat(np.cumsum(cnt) - cnt, cnt))
        key = seg_shell[seg] * self.nb + band
        o = np.argsort(key, kind='stable')  # (segments of a band in border order)
        self.keys, self.seg = key[o], seg[o]

    def query(self, shells, py):
        """(first position, count) into seg of the segments of shells[i] in the band of py[i]."""
        band = np.clip(np.floor((py - self.y0) / self.h).astype(np.int64), 0, self.nb - 1)
        key = shells * self.nb + band
        first = np.searchsorted(self.keys, key, side='left')
        return first, np.searchsorted(self.keys, key, side='right') - first


def _probe_hits(pts, own, sgrid, bmin, bmax, A, B, slope, off, bands=None):
    """Every (point index, shell) where the point lies inside a shell other than own[point].

    Candidates come from shell bounding boxes; the even-odd rule over the
    candidate shell's border decides (holes count as outside) - over the segments in the
    point's band (_Bands), the only ones a horizontal ray can cross.
    Results are sorted by point index.
    """
    if len(pts) == 0:
        return _EMPTY_I, _EMPTY_I
    qbox, first, count = sgrid.query(pts, pts)  # a point touches exactly one cell
    q, pos = _expand(qbox, first, count)
    c = sgrid.items[pos]
    px, py = pts[q, 0], pts[q, 1]
    keep = ((c != own[q]) & (px >= bmin[c, 0]) & (px <= bmax[c, 0]) &
            (py >= bmin[c, 1]) & (py <= bmax[c, 1]))
    q, c = q[keep], c[keep]
    if not q.size:
        return _EMPTY_I, _EMPTY_I
    if bands is None:
        seg_shell = np.repeat(np.arange(off.size - 1, dtype=np.int64), np.diff(off))
        bands = _Bands(A, B, seg_shell)
    bfirst, nseg = bands.query(c, pts[q, 1])
    csum = np.cumsum(nseg)
    hp, hs = [], []
    i0 = 0
    while i0 < q.size:
        base = csum[i0 - 1] if i0 else 0
        i1 = min(q.size, max(i0 + 1, int(np.searchsorted(csum, base + CHUNK, side='right'))))
        qq, cc, ns = q[i0:i1], c[i0:i1], nseg[i0:i1]
        has = ns > 0
        qq, cc, ns, bf = qq[has], cc[has], ns[has], bfirst[i0:i1][has]
        if qq.size:
            seg = bands.seg[_ranges(bf, bf + ns)]
            row = np.repeat(qq, ns)
            ppx, ppy = pts[row, 0], pts[row, 1]
            ay, by = A[seg, 1], B[seg, 1]
            cross = ((ay > ppy) != (by > ppy)) & (ppx < A[seg, 0] + (ppy - ay) * slope[seg])
            odd = (np.add.reduceat(cross, np.cumsum(ns) - ns, dtype=np.int32) & 1).astype(bool)
            hp.append(qq[odd])
            hs.append(cc[odd])
        i0 = i1
    if not hp:
        return _EMPTY_I, _EMPTY_I
    return np.concatenate(hp), np.concatenate(hs)


def _candidate_segment_pairs(A, B, L, seg_shell):
    """Border segment pairs (i, j) of different shells sharing a grid cell; shell(i) < shell(j)."""
    M = len(A)
    cell = max(2.0 * float(np.median(L)), float(L.sum()) / MAX_PIECES, 1e-12)
    seg, plo, phi = _segment_pieces(A, B, L, cell)
    box, key = _box_cells(plo[:, 0], plo[:, 1], phi[:, 0], phi[:, 1], cell)
    order = np.argsort(key, kind='stable')
    key = key[order]
    item = seg[box[order]]
    n = key.size
    gstart = np.flatnonzero(np.r_[True, key[1:] != key[:-1]])
    gend = np.r_[gstart[1:], n]
    later = np.repeat(gend, gend - gstart) - np.arange(n) - 1  # entries after this one in its cell
    csum = np.cumsum(later)
    codes = []
    p0 = 0
    while p0 < n:
        base = csum[p0 - 1] if p0 else 0
        p1 = min(n, max(p0 + 1, int(np.searchsorted(csum, base + CHUNK, side='right'))))
        c = later[p0:p1]
        tot = int(c.sum())
        if tot:
            a = np.repeat(np.arange(p0, p1, dtype=np.int64), c)
            b = a + 1 + (np.arange(tot, dtype=np.int64) - np.repeat(np.cumsum(c) - c, c))
            i, j = item[a], item[b]
            si, sj = seg_shell[i], seg_shell[j]
            keep = si != sj
            i, j, swap = i[keep], j[keep], (si > sj)[keep]
            codes.append(np.where(swap, j, i) * M + np.where(swap, i, j))
        p0 = p1
    if not codes:
        return _EMPTY_I, _EMPTY_I
    code = np.unique(np.concatenate(codes))
    return code // M, code % M


def _pair_crossings(A, B, i, j):
    """Proper crossings of segment pairs (i[k], j[k]): (pair indices k, crossing points).

    Segments meeting only at their ends, or lying on each other, just touch."""
    ks, pts = [], []
    for k0 in range(0, i.size, CHUNK):
        ii, jj = i[k0:k0 + CHUNK], j[k0:k0 + CHUNK]
        p, q = A[ii], A[jj]
        r, s = B[ii] - p, B[jj] - q
        den = r[:, 0] * s[:, 1] - r[:, 1] * s[:, 0]
        qp = q - p
        with np.errstate(divide='ignore', invalid='ignore'):
            t = (qp[:, 0] * s[:, 1] - qp[:, 1] * s[:, 0]) / den
            u = (qp[:, 0] * r[:, 1] - qp[:, 1] * r[:, 0]) / den
        ok = np.abs(den) > 1e-9 * np.hypot(r[:, 0], r[:, 1]) * np.hypot(s[:, 0], s[:, 1])
        ok &= (t > CROSS_TOL) & (t < 1.0 - CROSS_TOL) & (u > CROSS_TOL) & (u < 1.0 - CROSS_TOL)
        if ok.any():
            sel = np.flatnonzero(ok)
            ks.append(k0 + sel)
            pts.append(p[sel] + r[sel] * t[sel][:, None])
    if not ks:
        return _EMPTY_I, _EMPTY2
    return np.concatenate(ks), np.concatenate(pts)


def _shell_probes(A, B, sign, off, eps):
    """Up to PROBES_PER_SHELL points per shell, just inside it next to spread-out border segments."""
    m = np.diff(off)
    k = np.minimum(PROBES_PER_SHELL, m)
    owner = np.repeat(np.arange(m.size, dtype=np.int64), k)
    j = (np.arange(owner.size, dtype=np.int64) - np.repeat(np.cumsum(k) - k, k)).astype(np.float64)
    kk, mm = k[owner], m[owner]
    step = np.where(kk > 1, (mm - 1) / np.maximum(kk - 1, 1), 0.0)
    idx = off[:-1][owner] + np.round(j * step).astype(np.int64)
    a = A[idx]
    d = B[idx] - a
    sg = sign[idx]
    ln = np.hypot(d[:, 0], d[:, 1])
    ok = (ln > 0.0) & (sg != 0.0)
    a, d, ln, sg, owner = a[ok], d[ok], ln[ok], sg[ok], owner[ok]
    inward = np.column_stack((-d[:, 1], d[:, 0])) * (sg / ln)[:, None]
    return a + d * 0.5 + inward * np.minimum(eps, 0.05 * ln)[:, None], owner


class _Pairs:
    """Overlapping shell pairs (s < c, gap-shell indices) in the order they are labeled: pairs
    whose borders cross (by s, c), then shells inside or stacked on another (in probe order).
    label: (k, 2) UV label points; crossing marks of pair i: cross_pts[cross_off[i]:cross_off[i + 1]].
    kind: 0 crossing borders, 1 inside; own / j / oth: for kind 1, the shell whose probe j lies
    inside shell oth (for ordering pairs measured in groups)."""
    __slots__ = ("s", "c", "label", "kind", "own", "j", "oth", "cross_off", "cross_pts")

    def __init__(self):
        self.s = self.c = self.kind = self.own = self.j = self.oth = _EMPTY_I
        self.label = _EMPTY2
        self.cross_off = np.zeros(1, dtype=np.int64)
        self.cross_pts = _EMPTY2

    def __len__(self):
        return int(self.s.size)

    def cross(self, i):
        return self.cross_pts[self.cross_off[i]:self.cross_off[i + 1]]

    def as_dict(self):
        """{(s, c): (label_uv, crossing_points_uv)}."""
        return {(int(s), int(c)): (self.label[i].copy(), self.cross(i).copy())
                for i, (s, c) in enumerate(zip(self.s.tolist(), self.c.tolist()))}


def _find_overlapping_pairs(geo):
    """Every overlapping shell pair (s < c), as _Pairs.

    Borders that cross -> overlap, labeled at the crossing nearest their center.
    No crossing, but a point just inside one shell lies inside the other -> the
    shell is contained in or stacked on the other, labeled at that point.
    Shells that only touch are not overlaps.
    """
    S = geo.nshells
    out = _Pairs()
    if S < 2:
        return out
    A, B, off, seg_shell = geo.seg_a, geo.seg_b, geo.shell_off, geo.seg_shell
    L = np.hypot(B[:, 0] - A[:, 0], B[:, 1] - A[:, 1])

    ccode, clabel, ccount, cpts = _EMPTY_I, _EMPTY2, _EMPTY_I, _EMPTY2
    i, j = _candidate_segment_pairs(A, B, L, seg_shell)
    if i.size:
        k, pts = _pair_crossings(A, B, i, j)
        if k.size:
            code = seg_shell[i[k]] * S + seg_shell[j[k]]
            order = np.argsort(code, kind='stable')
            code, pts = code[order], pts[order]
            starts = np.flatnonzero(np.r_[True, code[1:] != code[:-1]])
            cnt = np.diff(np.r_[starts, code.size])
            grp = np.repeat(np.arange(starts.size, dtype=np.int64), cnt)
            # label: the crossing nearest the crossings' center (the first of equally near ones);
            # the center summed point by point in order, as mean() does (np.add.reduceat sums
            # pairwise, which can tip a tie between symmetric crossings)
            ctr = np.column_stack((_face_sums_in_order(pts[:, 0], starts, cnt),
                                   _face_sums_in_order(pts[:, 1], starts, cnt))) / cnt[:, None]
            d2 = ((pts - ctr[grp]) ** 2).sum(axis=1)
            o = np.lexsort((d2, grp))
            first = o[np.r_[True, grp[o][1:] != grp[o][:-1]]]
            ccode, clabel = code[starts], pts[first]
            # marks: every crossing, or MAX_CROSS_MARKS spread evenly along the pair's crossings
            take = np.minimum(cnt, MAX_CROSS_MARKS)
            pos = np.arange(int(take.sum()), dtype=np.int64) - np.repeat(np.cumsum(take) - take, take)
            n_of = np.repeat(cnt, take)
            step = np.where(n_of > MAX_CROSS_MARKS, (n_of - 1.0) / (MAX_CROSS_MARKS - 1), 1.0)
            pick = (pos * step).astype(np.int64)  # (as np.linspace(0, n - 1, MAX_CROSS_MARKS))
            pick = np.where((n_of > MAX_CROSS_MARKS) & (pos == MAX_CROSS_MARKS - 1), n_of - 1, pick)
            cpts = pts[np.repeat(starts, take) + pick]
            ccount = take

    pcode, plabel, pown, pj, poth = _EMPTY_I, _EMPTY2, _EMPTY_I, _EMPTY_I, _EMPTY_I
    probes, owner = _shell_probes(A, B, geo.seg_sign, off, UV_EPS)
    if len(probes):
        hp, hs = _probe_hits(probes, owner, _shell_grid(geo.bmin, geo.bmax),
                             geo.bmin, geo.bmax, A, B, _slopes(A, B), off)
        if hp.size:
            s = owner[hp]
            code = np.minimum(s, hs) * S + np.maximum(s, hs)
            _u, f = np.unique(code, return_index=True)
            f = np.sort(f)  # first time each pair is seen, in probe order
            f = f[~np.isin(code[f], ccode)]
            if f.size:
                pcode, plabel = code[f], probes[hp[f]]
                pown, poth = s[f], hs[f]
                first_probe = np.searchsorted(owner, np.arange(S), side='left')
                pj = hp[f] - first_probe[pown]

    nc, npr = ccode.size, pcode.size
    code = np.concatenate((ccode, pcode))
    out.s, out.c = code // S, code % S
    out.label = np.concatenate((clabel, plabel)).reshape(-1, 2)
    out.kind = np.concatenate((np.zeros(nc, dtype=np.int64), np.ones(npr, dtype=np.int64)))
    out.own = np.concatenate((np.full(nc, -1, dtype=np.int64), pown))
    out.j = np.concatenate((np.full(nc, -1, dtype=np.int64), pj))
    out.oth = np.concatenate((np.full(nc, -1, dtype=np.int64), poth))
    out.cross_off = np.concatenate(([0], np.cumsum(np.concatenate((ccount, np.zeros(npr, dtype=np.int64)))))).astype(np.int64)
    out.cross_pts = cpts.reshape(-1, 2)
    return out


class _Measurement:
    __slots__ = ("p_uv", "q_uv", "dist", "src", "dst",
                 "bp_uv", "bf_uv", "bdist", "baxis", "bsrc",
                 "ov_uv", "ov_src", "pair_label_uv", "pair_label_pi", "cross_uv", "cross_pi",
                 "overlap_codes", "tile_mark_uv", "tile_label_uv", "tile_crossing",
                 "shells_total", "shells_sampled", "samples", "overlap_pairs", "version", "stacks")

    def __init__(self):
        self.p_uv = _EMPTY2          # shell-to-shell gaps: border point, nearest neighbor point
        self.q_uv = _EMPTY2
        self.dist = _EMPTY_F
        self.src = _EMPTY_I
        self.dst = _EMPTY_I
        self.bp_uv = _EMPTY2         # tile-border distances: border point, foot on the tile edge
        self.bf_uv = _EMPTY2
        self.bdist = _EMPTY_F
        self.baxis = _EMPTY_I        # 0: vertical tile edge (u = const), 1: horizontal (v = const)
        self.bsrc = _EMPTY_I
        self.ov_uv = _EMPTY2         # measurement points inside another shell
        self.ov_src = _EMPTY_I       # (their shells)
        self.pair_label_uv = _EMPTY2
        self.pair_label_pi = _EMPTY_I  # (their pairs: index into geo.pairs)
        self.cross_uv = _EMPTY2
        self.cross_pi = _EMPTY_I
        self.overlap_codes = _EMPTY_I  # overlapping pairs s * S + c (s < c), sorted
        self.tile_mark_uv = _EMPTY2  # where shells cross tile lines
        self.tile_label_uv = _EMPTY2
        self.tile_crossing = 0
        self.shells_total = 0
        self.shells_sampled = 0
        self.samples = 0
        self.overlap_pairs = 0
        self.version = 0
        self.stacks = None           # which shells were measured as one (Stacks), if any


def _shell_candidates(sh, lo, hi, A, B, L, seg_shell, tile_key=None):
    """Sorted pairs (row k, segment j): border segments of shells other than sh[k]
    (in the same group - tile and / or material - when tile_key is given) whose bounding
    box meets [lo[k], hi[k]]."""
    M = len(A)
    cell = max(0.5 * float(np.median((hi - lo).max(axis=1))), float(np.median(L)),
               float(L.sum()) / MAX_PIECES, 1e-9)
    while _cell_rows(lo[:, 0], lo[:, 1], hi[:, 0], hi[:, 1], cell) > MAX_GRID_ROWS:
        cell *= 2.0
    seg, plo, phi = _segment_pieces(A, B, L, cell)
    grid = _Grid(cell, seg, plo, phi)
    qbox, first, count = grid.query(lo, hi)
    codes = []
    for r0, r1 in _query_chunks(qbox, count, len(sh)):
        k, pos = _expand(qbox[r0:r1], first[r0:r1], count[r0:r1])
        j = grid.items[pos]
        keep = ((seg_shell[j] != sh[k]) &
                (np.minimum(A[j, 0], B[j, 0]) <= hi[k, 0]) & (np.maximum(A[j, 0], B[j, 0]) >= lo[k, 0]) &
                (np.minimum(A[j, 1], B[j, 1]) <= hi[k, 1]) & (np.maximum(A[j, 1], B[j, 1]) >= lo[k, 1]))
        if tile_key is not None:
            keep &= tile_key[seg_shell[j]] == tile_key[sh[k]]
        codes.append(k[keep] * M + j[keep])
    if not codes:
        return _EMPTY_I, _EMPTY_I
    code = np.unique(np.concatenate(codes))
    return code // M, code % M


def _dense_blocks(cand_k, cand_j, K, n):
    """Yield (rows, idx, valid): the candidate segments of several rows as one dense block.

    Rows with similar candidate counts share a power-of-two width (idx is padded,
    `valid` marks real entries), so a few large array operations cover every shell.
    """
    counts = np.bincount(cand_k, minlength=K)
    starts = np.cumsum(counts) - counts
    rows = np.flatnonzero(counts)
    if rows.size == 0:
        return
    width = np.left_shift(1, np.ceil(np.log2(counts[rows])).astype(np.int64))
    last = cand_j.size - 1
    for w in np.unique(width).tolist():
        rw = rows[width == w]
        step = max(1, DENSE_CHUNK // (n * w))
        col = np.arange(w)
        for c0 in range(0, rw.size, step):
            r = rw[c0:c0 + step]
            valid = col[None, :] < counts[r][:, None]
            idx = cand_j[np.minimum(starts[r][:, None] + col[None, :], last)]
            yield r, idx, valid


def _nearest_batched(P3, N3, cand_k, cand_j, A, D, L, R):
    """Nearest candidate border point within R, in front of the border, for every sample.

    P3, N3: (K, n, 2) sample points and outward normals of K shells.
    Returns (K, n) distance or inf, (K, n, 2) closest point, (K, n) segment index.
    """
    K, n = P3.shape[0], P3.shape[1]
    best = np.full((K, n), np.inf)
    bq = np.zeros((K, n, 2))
    bj = np.zeros((K, n), dtype=np.int64)
    if K == 0 or cand_k.size == 0:
        return best, bq, bj
    L2s = np.where(L > 0.0, L * L, 1.0)
    R2 = R * R * (1.0 + 1e-12)
    for r, idx, valid in _dense_blocks(cand_k, cand_j, K, n):
        ax, ay = A[idx, 0][:, None, :], A[idx, 1][:, None, :]
        dx, dy = D[idx, 0][:, None, :], D[idx, 1][:, None, :]
        px, py = P3[r, :, 0][:, :, None], P3[r, :, 1][:, :, None]
        # same arithmetic as t = clip(((p - a) . d) / |d|^2), v = a + t d - p, done in place
        t = np.subtract(px, ax)
        np.multiply(t, dx, out=t)
        vy = np.subtract(py, ay)
        np.multiply(vy, dy, out=vy)
        np.add(t, vy, out=t)
        np.divide(t, L2s[idx][:, None, :], out=t)
        np.clip(t, 0.0, 1.0, out=t)
        vx = np.multiply(t, dx)
        np.add(vx, ax, out=vx)
        np.subtract(vx, px, out=vx)
        np.multiply(t, dy, out=vy)
        np.add(vy, ay, out=vy)
        np.subtract(vy, py, out=vy)
        d2 = np.multiply(vx, vx)
        np.multiply(vy, vy, out=t)
        np.add(d2, t, out=d2)
        # padding, beyond R (not a neighbor), or not in front of the border: behind it would
        # measure through its own shell, sideways would run along its own edge
        np.multiply(vx, N3[r, :, 0][:, :, None], out=t)
        front = np.multiply(vy, N3[r, :, 1][:, :, None])
        np.add(t, front, out=t)
        np.sqrt(d2, out=front)
        np.multiply(front, EDGE_FACING, out=front)
        np.subtract(front, 1e-9, out=front)
        bad = t < front
        bad |= d2 > R2
        bad |= ~valid[:, None, :]
        d2[bad] = np.inf
        jj = d2.argmin(axis=2)[:, :, None]
        best[r] = np.take_along_axis(d2, jj, 2)[:, :, 0]
        bq[r, :, 0] = np.take_along_axis(vx, jj, 2)[:, :, 0] + P3[r, :, 0]
        bq[r, :, 1] = np.take_along_axis(vy, jj, 2)[:, :, 0] + P3[r, :, 1]
        bj[r] = np.take_along_axis(idx, jj[:, :, 0], 1)
    return np.sqrt(best), bq, bj


def _border_distances(P3, N3, edges, cand_k, cand_j, A, D, R):
    """Distance from each sample to the nearest edge of its shell's tile that the border
    faces (within R), unless a shell border - its own or another's - lies in between.

    P3, N3: (K, n, 2) points and outward normals; edges: (K, 4) tile lines x0, x1, y0, y1.
    Returns (K, n) distance or inf, (K, n, 2) foot point on the edge, (K, n) edge axis
    (0 = vertical line u = const, 1 = horizontal line v = const).
    """
    K, n = P3.shape[0], P3.shape[1]
    px, py = P3[:, :, 0], P3[:, :, 1]
    nx, ny = N3[:, :, 0], N3[:, :, 1]
    x0, x1 = edges[:, 0][:, None], edges[:, 1][:, None]
    y0, y1 = edges[:, 2][:, None], edges[:, 3][:, None]
    d = np.stack((px - x0, x1 - px, py - y0, y1 - py), axis=2)
    facing = np.stack((-nx, nx, -ny, ny), axis=2) >= EDGE_FACING
    d = np.where(facing & (d <= R), np.maximum(d, 0.0), np.inf)
    e = d.argmin(axis=2)
    dist = np.take_along_axis(d, e[:, :, None], 2)[:, :, 0]
    F = np.empty((K, n, 2))
    F[:, :, 0] = np.where(e == 0, x0, np.where(e == 1, x1, px))
    F[:, :, 1] = np.where(e == 2, y0, np.where(e == 3, y1, py))
    axis = (e >= 2).astype(np.int64)
    if cand_k.size and np.isfinite(dist).any():
        for r, idx, valid in _dense_blocks(cand_k, cand_j, K, n):
            live = np.isfinite(dist[r])
            if not live.any():
                continue
            ppx, ppy = px[r][:, :, None], py[r][:, :, None]
            rx = (F[r, :, 0] - px[r])[:, :, None]
            ry = (F[r, :, 1] - py[r])[:, :, None]
            ax, ay = A[idx, 0][:, None, :], A[idx, 1][:, None, :]
            sx, sy = D[idx, 0][:, None, :], D[idx, 1][:, None, :]
            qpx, qpy = ax - ppx, ay - ppy
            den = rx * sy - ry * sx
            with np.errstate(divide='ignore', invalid='ignore'):
                t = (qpx * sy - qpy * sx) / den
                u = (qpx * ry - qpy * rx) / den
            hit = np.abs(den) > 1e-12 * np.hypot(rx, ry) * np.hypot(sx, sy)
            hit &= (t > 1e-6) & (t <= 1.0 + 1e-9) & (u >= -1e-9) & (u <= 1.0 + 1e-9)
            hit &= valid[:, None, :]
            blocked = hit.any(axis=2) & live
            dist[r] = np.where(blocked, np.inf, dist[r])
    return dist, F, axis


def _measure(geo, W, H, points, shift, radius, selected_only, tiles=False, same_mat=False):
    m = _Measurement()
    S = geo.nshells
    m.shells_total = S
    if S == 0:
        return m
    mat = geo.shell_mat if same_mat and geo.shell_mat.size == S else None
    scale = np.array((float(W), float(H)))
    A = geo.seg_a * scale
    B = geo.seg_b * scale
    D = B - A
    L = np.hypot(D[:, 0], D[:, 1])
    Ls = np.where(L > 0.0, L, 1.0)
    inward = np.column_stack((-D[:, 1], D[:, 0])) * (geo.seg_sign / Ls)[:, None]
    off = geo.shell_off
    seg_shell = geo.seg_shell
    bmin, bmax = geo.bmin * scale, geo.bmax * scale
    R = max(0.0, float(radius))
    n = max(1, int(points))
    tile_key = ((geo.tile[:, 0] + _TILE_OFF) * _TILE_MUL + geo.tile[:, 1] + _TILE_OFF) if tiles else None
    group = tile_key  # gaps are measured only within a group: same tile and / or same material
    if mat is not None:
        group = mat if group is None else group * (int(mat.max()) + 1) + mat

    # evenly spaced points along each shell's whole border (all loops), shifted along it
    cum0 = np.concatenate(([0.0], np.cumsum(L)))
    start = cum0[off[:-1]]
    total = cum0[off[1:]] - start
    act = total > 1e-9
    if selected_only:
        act &= geo.shell_sel
    sh = np.flatnonzero(act)
    covered = _EMPTY_I  # pairs (s * S + c) with a measurement point of one inside the other
    if sh.size:
        frac = (np.arange(n, dtype=np.float64) + (float(shift) % 1.0)) / n
        T = (start[sh][:, None] + total[sh][:, None] * frac[None, :]).ravel()
        s_of = np.repeat(sh, n)
        g = np.searchsorted(cum0, T, side='right') - 1
        g = np.clip(g, off[s_of], off[s_of + 1] - 1)
        f = np.clip((T - cum0[g]) / Ls[g], 0.0, 1.0)
        P = A[g] + D[g] * f[:, None]
        m.shells_sampled = int(sh.size)
        m.samples = int(P.shape[0])

        # 1) overlap: the point, nudged into its own shell, lies inside another shell.
        #    Step off the segment ends first: at a corner, the inward normal of one
        #    edge runs along the other edge and could land on a touching neighbor's border.
        end = np.minimum(2.0 * PX_EPS / Ls[g], 0.5)
        probe = A[g] + D[g] * np.clip(f, end, 1.0 - end)[:, None] + inward[g] * PX_EPS
        hp, hs = _probe_hits(probe, s_of, _shell_grid(bmin, bmax), bmin, bmax, A, B, _slopes(A, B), off)
        if mat is not None and hp.size:  # shells of other materials use another texture
            keep = mat[s_of[hp]] == mat[hs]
            hp, hs = hp[keep], hs[keep]
        ov = np.zeros(P.shape[0], dtype=bool)
        if hp.size:
            ov[hp] = True
            a = s_of[hp]
            covered = np.unique(np.minimum(a, hs) * S + np.maximum(a, hs))
            m.ov_uv = P[ov] / scale
            m.ov_src = s_of[ov]

        # 2) gap: nearest border point of another shell within the radius, in front of this border
        #    (not searched from shells whose points all lie inside other shells: overlaps)
        P3 = P.reshape(-1, n, 2)
        N3 = (-inward[g]).reshape(-1, n, 2)
        live = ~ov.reshape(-1, n).all(axis=1)
        rows = np.flatnonzero(live)
        ck = cj = _EMPTY_I
        if rows.size:
            ck, cj = _shell_candidates(sh[rows], bmin[sh[rows]] - R, bmax[sh[rows]] + R, A, B, L, seg_shell, group)
            ck = rows[ck]
        if R > 0.0:
            dist, Q, j = _nearest_batched(P3, N3, ck, cj, A, D, L, R)
            dist, Q, j = dist.ravel(), Q.reshape(-1, 2), j.ravel()
            hit = np.flatnonzero(np.isfinite(dist) & ~ov)
            m.p_uv = P[hit] / scale
            m.q_uv = Q[hit] / scale
            m.dist = dist[hit]
            m.src = s_of[hit]
            m.dst = seg_shell[j[hit]]

        # 3) tile border: shells within R of an edge of their own tile, measured where the
        #    border faces that edge and no shell border lies in between
        if tiles and R > 0.0:
            tl = geo.tile[sh].astype(np.float64)
            edges = np.column_stack((tl[:, 0] * W, (tl[:, 0] + 1.0) * W, tl[:, 1] * H, (tl[:, 1] + 1.0) * H))
            room = np.minimum(np.minimum(bmin[sh, 0] - edges[:, 0], edges[:, 1] - bmax[sh, 0]),
                              np.minimum(bmin[sh, 1] - edges[:, 2], edges[:, 3] - bmax[sh, 1]))
            near = np.flatnonzero((room <= R) & ~geo.tile_cross[sh] & live)
            if near.size:
                M = len(A)
                remap = np.full(sh.size, -1, dtype=np.int64)
                remap[near] = np.arange(near.size)
                keep = remap[ck] >= 0
                own = sh[near]
                own_len = off[own + 1] - off[own]
                code = np.unique(np.concatenate((
                    remap[ck[keep]] * M + cj[keep],
                    np.repeat(np.arange(near.size, dtype=np.int64), own_len) * M
                    + _ranges(off[own], off[own + 1]))))
                bd, F, axis = _border_distances(P3[near], N3[near], edges[near], code // M, code % M, A, D, R)
                ok = np.isfinite(bd) & ~ov.reshape(-1, n)[near]
                if ok.any():
                    m.bp_uv = P3[near][ok] / scale
                    m.bf_uv = F[ok] / scale
                    m.bdist = bd[ok]
                    m.baxis = axis[ok]
                    m.bsrc = np.repeat(own, n).reshape(-1, n)[ok]

    prs = geo.pairs if geo.pairs is not None else _find_overlapping_pairs(geo)
    k = np.arange(len(prs), dtype=np.int64)
    if selected_only and k.size:
        k = k[geo.shell_sel[prs.s] | geo.shell_sel[prs.c]]
    if mat is not None and k.size:
        k = k[mat[prs.s[k]] == mat[prs.c[k]]]
    pcode = prs.s[k] * S + prs.c[k]
    m.overlap_codes = np.union1d(covered, pcode).astype(np.int64)
    m.overlap_pairs = int(m.overlap_codes.size)
    lab = k[~np.isin(pcode, covered)]  # no measurement point caught these overlaps: label them anyway
    if lab.size:
        m.pair_label_uv = prs.label[lab]
        m.pair_label_pi = lab
    if k.size:
        n_cross = prs.cross_off[k + 1] - prs.cross_off[k]
        if n_cross.any():
            m.cross_uv = prs.cross_pts[_ranges(prs.cross_off[k], prs.cross_off[k + 1])]
            m.cross_pi = np.repeat(k, n_cross)
    if tiles:
        _tile_marks(geo, selected_only, m)
    return m


def _tile_marks(geo, selected_only, m):
    """Marks and labels of the shells crossing a tile line."""
    if not geo.tile_cross_pts:
        return
    tmarks, tlabels = [], []
    for s, pts in geo.tile_cross_pts.items():
        if selected_only and not geo.shell_sel[s]:
            continue
        tmarks.append(pts)
        tlabels.append(pts[0])
    m.tile_crossing = len(tlabels)
    if tlabels:
        m.tile_mark_uv = np.concatenate(tmarks)
        m.tile_label_uv = np.array(tlabels, dtype=np.float64).reshape(-1, 2)


def _td_values(uv_area, world_area, W, H, scale):
    """Texel density in px/m per shell: sqrt(texture pixels covered / square meters).
    NaN where a shell has no 3D area."""
    wa = np.asarray(world_area, dtype=np.float64) * (scale * scale)
    with np.errstate(divide='ignore', invalid='ignore'):
        td = np.sqrt(np.asarray(uv_area, dtype=np.float64) * (float(W) * float(H)) / wa)
    td[~np.isfinite(td)] = np.nan
    return td


def _td_base(uv_area, world_area):
    """sqrt(UV area / world area) per shell, the texture-independent part of the texel
    density: px/m = this * sqrt(W * H) / unit scale. -1 where a shell has no 3D area."""
    with np.errstate(divide='ignore', invalid='ignore'):
        b = np.sqrt(np.asarray(uv_area, dtype=np.float64) / np.asarray(world_area, dtype=np.float64))
    b[~np.isfinite(b)] = -1.0
    return b


def _td_factor(W, H, scale):
    return float(np.sqrt(float(W) * float(H))) / float(scale)


def _td_rgb(td, low, needed, high):
    """Red at Low and below, green at Needed, blue at High and above; the hue runs through
    yellow and cyan in between. Shells without a density are gray."""
    td = np.asarray(td, dtype=np.float64)
    t = np.ones(td.shape)
    with np.errstate(invalid='ignore', divide='ignore'):
        below = td < needed
        above = td > needed
        if needed > low:
            t[below] = np.clip((td[below] - low) / (needed - low), 0.0, 1.0)
        else:
            t[below] = 0.0
        if high > needed:
            t[above] = 1.0 + np.clip((td[above] - needed) / (high - needed), 0.0, 1.0)
        else:
            t[above] = 2.0
    h = t * 2.0  # hue in 60 degree steps: 0 red, 1 yellow, 2 green, 3 cyan, 4 blue
    rgb = np.column_stack((np.clip(np.abs(h - 3.0) - 1.0, 0.0, 1.0),
                           np.clip(2.0 - np.abs(h - 2.0), 0.0, 1.0),
                           np.clip(2.0 - np.abs(h - 4.0), 0.0, 1.0)))
    rgb[~np.isfinite(td)] = 0.5
    return rgb


def _fmt_td(v, unit):
    if v >= 99.95:
        return "%.0f %s" % (v, unit)
    if v >= 9.995:
        return "%.1f %s" % (v, unit)
    return "%.2f %s" % (v, unit)


def _td_stats(td, thr):
    """(shells, min, median, max, below low, above high) in px/m, for the panels."""
    ok = td[np.isfinite(td)]
    if not ok.size:
        return (int(td.size), None, None, None, 0, 0)
    low, _needed, high = thr
    return (int(td.size), float(ok.min()), float(np.median(ok)), float(ok.max()),
            int(np.count_nonzero(ok <= low)), int(np.count_nonzero(ok >= high)))


def _td_range_bounds(td, f0, f1):
    """(lo, hi) in px/m: fractions f0..f1 of the lowest..highest finite density; None if none."""
    ok = td[np.isfinite(td)]
    if not ok.size:
        return None
    tmin, tmax = float(ok.min()), float(ok.max())
    span = tmax - tmin
    eps = max(span, abs(tmax), 1e-12) * 1e-9  # the shells at the ends are always in range
    return tmin + span * float(f0) - eps, tmin + span * float(f1) + eps


def _gradient(d, min_px, needed_px, c_zero, c_min, c_needed):
    """0 px -> c_zero, Minimal -> c_min, Needed and above -> c_needed."""
    lo = max(0.0, float(min_px))
    hi = max(lo + 1e-6, float(needed_px))
    t1 = np.clip(d / lo, 0.0, 1.0) if lo > 0.0 else np.ones_like(d)
    t2 = np.clip((d - lo) / (hi - lo), 0.0, 1.0)
    below = c_zero + (c_min - c_zero) * t1[:, None]
    above = c_min + (c_needed - c_min) * t2[:, None]
    return np.where((d < lo)[:, None], below, above)


def _fmt_px(d):
    return ("%.0f px" % d) if d >= 99.95 else ("%.1f px" % d)


def _fmt_scale(s):
    """'2' for a uniform scale, '1 x 2 x 1' otherwise; None when the scale is 1."""
    if all(abs(c - 1.0) <= 1e-5 for c in s):
        return None
    parts = [("%.3f" % c).rstrip("0").rstrip(".") for c in s]
    parts = ["0" if p in ("-0", "") else p for p in parts]
    return parts[0] if parts[0] == parts[1] == parts[2] else " × ".join(parts)


def _clashes(grid, gx0, gx1, gy0, gy1, x0, y0, x1, y1):
    for gx in range(gx0, gx1 + 1):
        for gy in range(gy0, gy1 + 1):
            for r in grid.get((gx, gy), ()):
                if x0 < r[2] and x1 > r[0] and y0 < r[3] and y1 > r[1]:
                    return True
    return False


COARSE_OVER = 1500  # with more labels in view, only the first one of each label-sized cell is tried


def _place_labels(lab, anchor_px, lift, pad, rw, rh, declutter, coarse_over=COARSE_OVER):
    """Labels to draw (indices, priority order) and, per label, its box, the left end of its
    text, its first baseline and its center. Decluttering keeps a label only when it doesn't
    cover one placed before it; with very many labels in view (`coarse_over`) a first pass
    keeps one label per label-sized screen cell, which bounds the work."""
    ax = anchor_px[:, 0]
    ay = anchor_px[:, 1] + lab.lifted * lift
    hw = lab.width * 0.5
    th = lab.th
    tall = th + (np.maximum(lab.nlines, 1) - 1) * lab.lh  # first line's top to last line's baseline
    x0, x1 = ax - hw - pad, ax + hw + pad
    y0, y1 = ay - tall * 0.5 - th * 0.3 - pad * 0.5, ay + tall * 0.5 + pad
    idx = np.flatnonzero((x1 >= 0.0) & (x0 <= rw) & (y1 >= 0.0) & (y0 <= rh))
    if declutter and idx.size > 1:
        cw = max(1.0, float(np.median(x1[idx] - x0[idx])))
        ch = max(1.0, float(np.median(y1[idx] - y0[idx])))
        if idx.size > coarse_over:
            # coarse pass: the first label (by priority) in each label-sized screen cell
            cell_key = ((np.floor(ax[idx] / cw).astype(np.int64) + _KEY_OFF) * _KEY_MUL +
                        np.floor(ay[idx] / ch).astype(np.int64) + _KEY_OFF)
            _unique, first = np.unique(cell_key, return_index=True)
            idx = idx[np.sort(first)]
        # exact pass (over the survivors)
        cell = 2.0 * max(cw, ch)
        grid = {}
        keep = []
        X0, Y0, X1, Y1 = x0[idx].tolist(), y0[idx].tolist(), x1[idx].tolist(), y1[idx].tolist()
        for k, i in enumerate(idx.tolist()):
            a0, b0, a1, b1 = X0[k], Y0[k], X1[k], Y1[k]
            gx0, gx1, gy0, gy1 = int(a0 // cell), int(a1 // cell), int(b0 // cell), int(b1 // cell)
            if _clashes(grid, gx0, gx1, gy0, gy1, a0, b0, a1, b1):
                continue
            rect = (a0, b0, a1, b1)
            for gx in range(gx0, gx1 + 1):
                for gy in range(gy0, gy1 + 1):
                    grid.setdefault((gx, gy), []).append(rect)
            keep.append(i)
        idx = np.asarray(keep, dtype=np.int64)
    tx = ax - hw + np.where(np.isfinite(lab.icon[:, 0]), lab.icw + th * 0.35, 0.0)
    ty = ay + tall * 0.5 - th
    return idx, np.column_stack((x0, y0, x1, y1)), tx, ty, ax, ay


def _arrow_verts(C, D, size):
    """Triangles (shaft + head) of arrows centered on C, pointing along the unit vectors D,
    `size` long (one value or one per arrow)."""
    size = np.broadcast_to(np.asarray(size, dtype=np.float64), (C.shape[0],))[:, None]
    N = np.column_stack((-D[:, 1], D[:, 0]))
    tip = C + D * (size * 0.5)
    neck = tip - D * (size * 0.45)
    tail = C - D * (size * 0.5)
    sw = N * np.maximum(0.8, size * 0.08)
    hw = N * (size * 0.3)
    pts = np.stack((tail + sw, tail - sw, neck - sw, tail + sw, neck - sw, neck + sw,
                    neck + hw, neck - hw, tip), axis=1)
    v = np.zeros((pts.shape[0] * 9, 3), dtype=np.float32)
    v[:, :2] = pts.reshape(-1, 2)
    return v


# ---------------------------------------------------------------------------
# Public names for the other modules
# ---------------------------------------------------------------------------

Measurement = _Measurement
Pairs = _Pairs
td_values = _td_values
td_base = _td_base
td_factor = _td_factor
td_rgb = _td_rgb
fmt_td = _fmt_td
td_stats = _td_stats
td_range_bounds = _td_range_bounds
gradient = _gradient
fmt_px = _fmt_px
fmt_scale = _fmt_scale
place_labels = _place_labels
ranges = _ranges


# ---------------------------------------------------------------------------
# Measuring material by material, keeping results between measurements
# ---------------------------------------------------------------------------

class MeasureCache:
    """Results kept between measurements, per group of shells (one material, or all shells):
    stacks and overlapping pairs by the group's content, gap measurements by content and
    settings. Entries not used in the last `keep` measurements are dropped."""

    def __init__(self, keep=3):
        self.keep = int(keep)
        self.call = 0
        self.pairs = {}
        self.meas = {}
        self.stacks = {}
        self.stats = (0, 0)  # groups measured / groups, in the last measurement

    def begin(self):
        self.call += 1

    def get(self, table, key):
        hit = table.get(key)
        if hit is None:
            return None
        table[key] = (hit[0], self.call)
        return hit[0]

    def put(self, table, key, value):
        table[key] = (value, self.call)

    def trim(self):
        old = self.call - self.keep
        for table in (self.pairs, self.meas, self.stacks):
            for k in [k for k, (_v, c) in table.items() if c <= old]:
                del table[k]

    def clear(self):
        self.pairs.clear()
        self.meas.clear()
        self.stacks.clear()


def shell_groups(geo, same_mat):
    """[(material key or None, gap-shell indices, ascending)]: one group per material when
    shells of other materials don't count (Same Material Only), else one group of all shells."""
    S = geo.nshells
    if not S:
        return []
    if not same_mat or geo.shell_mat.size != S:
        return [(None, np.arange(S, dtype=np.int64))]
    order = np.argsort(geo.shell_mat, kind='stable')
    m = geo.shell_mat[order]
    starts = np.flatnonzero(np.r_[True, m[1:] != m[:-1]])
    ends = np.r_[starts[1:], S]
    return [(geo.mat_keys[int(m[a])], order[a:b]) for a, b in zip(starts.tolist(), ends.tolist())]


def _group_sig(geo, gkey, g):
    """What a group's shells depend on: its material and the UV data of its objects."""
    objs = np.unique(geo.sh_obj[geo.gap_shell[g]])
    return (gkey, tuple(geo.obj_uvsig[i] for i in objs.tolist()))


def with_selection(geo, shell_sel):
    """A shallow copy of geo with other selected shells (shell_sel, per gap shell)."""
    out = Geometry()
    for f in Geometry.__slots__:
        setattr(out, f, getattr(geo, f))
    out.shell_sel = np.asarray(shell_sel, dtype=bool)
    return out


def sub_geometry(geo, g):
    """The gap shells g (ascending gap-shell indices) as a Geometry of their own: what the
    gap measurement and the overlap search need."""
    sub = Geometry()
    S = geo.nshells
    whole = g.size == S
    if whole:
        sub.seg_a, sub.seg_b, sub.seg_sign = geo.seg_a, geo.seg_b, geo.seg_sign
        sub.shell_off, sub.seg_shell = geo.shell_off, geo.seg_shell
    else:
        seg = _ranges(geo.shell_off[g], geo.shell_off[g + 1])
        cnt = geo.shell_off[g + 1] - geo.shell_off[g]
        sub.seg_a, sub.seg_b, sub.seg_sign = geo.seg_a[seg], geo.seg_b[seg], geo.seg_sign[seg]
        sub.shell_off = np.concatenate(([0], np.cumsum(cnt))).astype(np.int64)
        sub.seg_shell = np.repeat(np.arange(g.size, dtype=np.int64), cnt)
    for f in ("shell_sel", "bmin", "bmax", "shell_mat", "tile", "tile_cross", "shell_area", "flipped"):
        a = getattr(geo, f)
        setattr(sub, f, a if whole else a[g])
    sub.nshells = int(g.size)
    sub.tile_cross_pts = {}  # (tile crossings: marked once for all groups)
    return sub


# ---------------------------------------------------------------------------
# Stacks: shells lying on each other on purpose (copies of a part sharing texture space)
# ---------------------------------------------------------------------------

STACK_MATCH = 0.999      # shells covering each other at least this much are one stack
_STACK_SAMPLES = 256     # border samples per shell when two shells are compared by distance
_STACK_ROUNDS = 16
_STACK_WINDOW = 64


class Stacks:
    """Per gap shell: `rep`, the shell that stands for its stack in the measurements (itself
    when it lies alone; a shell that isn't flipped where the stack has one), `size`, the
    number of shells in its stack, and `nflip`, how many of them are flipped."""
    __slots__ = ("rep", "size", "nflip")

    def __init__(self, n=0):
        self.rep = np.arange(n, dtype=np.int64)
        self.size = np.ones(n, dtype=np.int64)
        self.nflip = np.zeros(n, dtype=np.int64)

    def unique(self):
        """Gap shells that stand for themselves: every stack once."""
        return np.flatnonzero(self.rep == np.arange(self.rep.size))

    def copies(self):
        """Gap shells lying on their stack's representative: all but one of every stack."""
        return np.flatnonzero(self.rep != np.arange(self.rep.size))

    def members(self, reps):
        """Every shell of the stacks of `reps`."""
        pick = np.zeros(self.rep.size, dtype=bool)
        pick[np.asarray(reps, dtype=np.int64)] = True
        return np.flatnonzero(pick[self.rep])

    def counts(self):
        """(stacks of two or more shells, shells in them)."""
        u = self.unique()
        big = self.size[u] > 1
        return int(np.count_nonzero(big)), int(self.size[u][big].sum())


def _border_offsets(A, B, L, off, s, c):
    """Per pair (s[k], c[k]): the distance from s's border to c's border, summed along s's
    border - about the area between the two borders where they nearly coincide. Borders are
    sampled at segment middles (at most _STACK_SAMPLES per shell)."""
    out = np.zeros(s.size)
    if not s.size:
        return out
    D = B - A
    L2 = np.where(L > 0.0, L * L, 1.0)
    ns, mc = off[s + 1] - off[s], off[c + 1] - off[c]
    stride = np.maximum(1, -(-ns // _STACK_SAMPLES))
    nsamp = -(-ns // stride)
    cls = np.ceil(np.log2(nsamp)).astype(np.int64) * 64 + np.ceil(np.log2(mc)).astype(np.int64)
    for k in np.unique(cls).tolist():
        rows = np.flatnonzero(cls == k)
        NS, MC = int(nsamp[rows].max()), int(mc[rows].max())
        step = max(1, DENSE_CHUNK // (NS * MC))
        cs, cm = np.arange(NS), np.arange(MC)
        for r0 in range(0, rows.size, step):
            r = rows[r0:r0 + step]
            si = off[s[r]][:, None] + cs[None, :] * stride[r][:, None]
            vs = cs[None, :] < nsamp[r][:, None]
            si = np.where(vs, si, off[s[r]][:, None])
            P = A[si] + D[si] * 0.5                              # (K, NS, 2) border samples of s
            w = np.where(vs, L[si], 0.0)
            # each sample stands for its share of the whole border
            wsum = w.sum(axis=1)
            w = w * np.where(wsum > 0.0, _shell_perimeter(L, off, s[r]) / np.where(wsum > 0.0, wsum, 1.0), 0.0)[:, None]
            ci = off[c[r]][:, None] + cm[None, :]
            vc = cm[None, :] < mc[r][:, None]
            ci = np.where(vc, ci, off[c[r]][:, None])
            ax, ay = A[ci, 0][:, None, :], A[ci, 1][:, None, :]
            dx, dy = D[ci, 0][:, None, :], D[ci, 1][:, None, :]
            px, py = P[:, :, 0][:, :, None], P[:, :, 1][:, :, None]
            t = np.clip(((px - ax) * dx + (py - ay) * dy) / L2[ci][:, None, :], 0.0, 1.0)
            vx, vy = ax + t * dx - px, ay + t * dy - py
            d2 = vx * vx + vy * vy
            d2[np.broadcast_to(~vc[:, None, :], d2.shape)] = np.inf
            out[r] = (np.sqrt(d2.min(axis=2)) * w).sum(axis=1)
    return out


def _shell_perimeter(L, off, shells):
    csum = np.concatenate(([0.0], np.cumsum(L)))
    return csum[off[shells + 1]] - csum[off[shells]]


def _stack_matcher(sub, match):
    """A function (s, c) -> which pairs of shells cover each other by at least `match`."""
    A, B, off = sub.seg_a, sub.seg_b, sub.shell_off
    L = np.hypot(B[:, 0] - A[:, 0], B[:, 1] - A[:, 1])
    n = sub.nshells
    all_shells = np.arange(n, dtype=np.int64)
    perim = _shell_perimeter(L, off, all_shells)
    area = np.abs(sub.shell_area)
    slack = 1.0 - float(match)
    # how far two borders may be apart on average before they differ by half the allowed area
    eps = np.maximum(slack * area / np.where(perim > 0.0, perim, 1.0), 1e-9)
    # border vertices sorted within each shell: copies list the same vertices
    order = np.lexsort((A[:, 1], A[:, 0], sub.seg_shell))
    V = A[order]

    def matches(s, c):
        ok = np.zeros(s.size, dtype=bool)
        if not s.size:
            return ok
        ns, nc = off[s + 1] - off[s], off[c + 1] - off[c]
        big = np.maximum(area[s], area[c])
        near = np.abs(area[s] - area[c]) <= 2.0 * slack * big + 1e-18
        same = np.flatnonzero(near & (ns == nc))
        if same.size:
            ia, ib = _ranges(off[s[same]], off[s[same] + 1]), _ranges(off[c[same]], off[c[same] + 1])
            d = np.abs(V[ia] - V[ib]).max(axis=1)
            worst = np.maximum.reduceat(d, np.cumsum(ns[same]) - ns[same])
            ok[same] = worst <= np.minimum(eps[s[same]], eps[c[same]])
        rest = np.flatnonzero(near & ~ok & (big > 0.0))
        if rest.size:
            rs, rc = s[rest], c[rest]
            delta = np.maximum(_border_offsets(A, B, L, off, rs, rc), _border_offsets(A, B, L, off, rc, rs))
            ok[rest] = (area[rs] + area[rc] - delta) >= 2.0 * float(match) * big[rest]
        return ok
    return matches


def _find_stacks(sub, match):
    """Stacks among the shells of `sub`: (rep, size, nflip) per shell (local indices)."""
    n = sub.nshells
    st = Stacks(n)
    if n < 2:
        st.nflip = sub.flipped.astype(np.int64) if sub.flipped.size == n else st.nflip
        return st
    matches = _stack_matcher(sub, match)
    box = np.column_stack((sub.bmin, sub.bmax))
    # 1) shells with the same bounds (rounded): each is compared with the first of them; those
    #    that differ from it are compared among themselves next
    key = np.rint(box / 1e-6).astype(np.int64)
    ea, eb = [], []
    todo = np.arange(n, dtype=np.int64)
    for _round in range(_STACK_ROUNDS):
        if todo.size < 2:
            break
        k = key[todo]
        o = np.lexsort((todo, k[:, 3], k[:, 2], k[:, 1], k[:, 0]))
        u, kk = todo[o], k[o]
        first = np.r_[True, (kk[1:] != kk[:-1]).any(axis=1)]
        leader = u[np.maximum.accumulate(np.where(first, np.arange(u.size), 0))]
        s, c = leader[~first], u[~first]
        if not s.size:
            break
        ok = matches(s, c)
        ea.append(s[ok])
        eb.append(c[ok])
        todo = c[~ok]
    comp = _components(n, np.concatenate(ea) if ea else _EMPTY_I, np.concatenate(eb) if eb else _EMPTY_I)
    # 2) stacks whose bounds differ by less than the match allows (copies that aren't exact):
    #    each is compared with the next ones along U, then along V (shells lined up along one
    #    of them are many; along both, only shells lying on each other)
    tol = np.maximum(2.0 * (1.0 - float(match)) * (sub.bmax - sub.bmin), 1e-9)
    for axis in (0, 1):
        roots = np.flatnonzero(comp == np.arange(n))
        if roots.size < 2:
            break
        o = np.argsort(sub.bmin[roots, axis], kind='stable')
        r = roots[o]
        xs = sub.bmin[r, axis]
        hi = np.searchsorted(xs, xs + tol[r, axis], side='right')
        cnt = np.minimum(hi - np.arange(r.size) - 1, _STACK_WINDOW)
        tot = int(cnt.sum())
        if not tot:
            continue
        i = np.repeat(np.arange(r.size, dtype=np.int64), cnt)
        j = i + 1 + (np.arange(tot, dtype=np.int64) - np.repeat(np.cumsum(cnt) - cnt, cnt))
        a, b = r[i], r[j]
        t = np.maximum(tol[a], tol[b])
        keep = ((np.abs(box[a] - box[b]) <= np.concatenate((t, t), axis=1)).all(axis=1) &
                ((key[a] != key[b]).any(axis=1)))
        a, b = a[keep], b[keep]
        ok = matches(a, b)
        if ok.any():
            ea.append(a[ok])
            eb.append(b[ok])
            comp = _components(n, np.concatenate(ea), np.concatenate(eb))
    # the stack's representative: a shell that isn't flipped where there is one, then the first
    flipped = sub.flipped if sub.flipped.size == n else np.zeros(n, dtype=bool)
    idx = np.arange(n, dtype=np.int64)
    o = np.lexsort((idx, flipped, comp))
    firsts = o[np.r_[True, comp[o][1:] != comp[o][:-1]]]
    rep_of_comp = np.empty(n, dtype=np.int64)
    rep_of_comp[comp[firsts]] = firsts
    st.rep = rep_of_comp[comp]
    st.size = np.bincount(st.rep, minlength=n)[st.rep]
    st.nflip = np.bincount(st.rep, weights=flipped, minlength=n).astype(np.int64)[st.rep]
    return st


def _grouped(geo, same_mat, stack_match, cache):
    """[(signature, shells measured (ascending gap-shell indices), Stacks of the group or
    None, all the group's shells)]: per material (or for all shells), with stacks reduced to
    their representatives when `stack_match` is given."""
    out = []
    for gkey, g in shell_groups(geo, same_mat):
        sig = _group_sig(geo, gkey, g)
        if stack_match is None:
            out.append((sig, g, None, g))
            continue
        skey = (sig, round(float(stack_match), 9))
        st = cache.get(cache.stacks, skey) if cache is not None else None
        if st is None:
            st = _find_stacks(sub_geometry(geo, g), stack_match)
            if cache is not None:
                cache.put(cache.stacks, skey, st)
        out.append((skey, g[st.unique()], st, g))
    return out


def _merge_stacks(geo, grouped):
    st = Stacks(geo.nshells)
    if geo.flipped.size == geo.nshells:
        st.nflip = geo.flipped.astype(np.int64)
    for _sig, _gu, local, g in grouped:
        if local is not None:
            st.rep[g] = g[local.rep]
            st.size[g] = local.size
            st.nflip[g] = local.nflip
    return st


def find_stacks(geo, same_mat, stack_match=STACK_MATCH, cache=None):
    """Stacks of the geometry (Stacks, over the gap shells): of the same material only when
    `same_mat`."""
    if cache is not None:
        cache.begin()
    grouped = _grouped(geo, same_mat, stack_match, cache)
    if cache is not None:
        cache.trim()
    return _merge_stacks(geo, grouped)


def _merge_pairs(S, parts):
    """Global _Pairs from per-group ones: parts [(g, pairs)]. Returns (pairs, index of each
    group's pairs in the result)."""
    out = _Pairs()
    if not parts:
        return out, []
    s = np.concatenate([g[p.s] for g, p in parts])
    c = np.concatenate([g[p.c] for g, p in parts])
    kind = np.concatenate([p.kind for _g, p in parts])
    key = np.concatenate([np.where(p.kind == 0, g[p.s] * S + g[p.c],
                                   (g[np.maximum(p.own, 0)] * PROBES_PER_SHELL + p.j) * S + g[np.maximum(p.oth, 0)])
                          for g, p in parts])
    o = np.lexsort((key, kind))
    inv = np.empty(o.size, dtype=np.int64)
    inv[o] = np.arange(o.size)
    out.s, out.c, out.kind = s[o], c[o], kind[o]
    out.label = np.concatenate([p.label for _g, p in parts]).reshape(-1, 2)[o]
    own = np.concatenate([np.where(p.own >= 0, g[np.maximum(p.own, 0)], -1) for g, p in parts])
    oth = np.concatenate([np.where(p.oth >= 0, g[np.maximum(p.oth, 0)], -1) for g, p in parts])
    out.own, out.oth = own[o], oth[o]
    out.j = np.concatenate([p.j for _g, p in parts])[o]
    lo = np.concatenate([p.cross_off[:-1] for _g, p in parts])
    hi = np.concatenate([p.cross_off[1:] for _g, p in parts])
    base = np.repeat(np.cumsum([0] + [p.cross_pts.shape[0] for _g, p in parts])[:-1], [len(p) for _g, p in parts])
    lo, hi = (lo + base)[o], (hi + base)[o]
    pts = np.concatenate([p.cross_pts for _g, p in parts]).reshape(-1, 2)
    out.cross_pts = pts[_ranges(lo, hi)]
    out.cross_off = np.concatenate(([0], np.cumsum(hi - lo))).astype(np.int64)
    offs = np.cumsum([0] + [len(p) for _g, p in parts])
    return out, [inv[a:b] for a, b in zip(offs[:-1].tolist(), offs[1:].tolist())]


def _group_pairs(geo, grouped, cache):
    out = []
    for sig, g, _st, _all in grouped:
        prs = cache.get(cache.pairs, sig) if cache is not None else None
        if prs is None:
            prs = _find_overlapping_pairs(sub_geometry(geo, g))
            if cache is not None:
                cache.put(cache.pairs, sig, prs)
        out.append((sig, g, prs))
    return out


def overlap_pairs(geo, same_mat, cache=None, stack_match=None):
    """Overlapping shell pairs (_Pairs, gap-shell indices), of the same material only when
    `same_mat`. With `stack_match`, stacks count as one shell (their representative): the
    pairs are the overlaps that aren't stacks."""
    if cache is not None:
        cache.begin()
    parts = _group_pairs(geo, _grouped(geo, same_mat, stack_match, cache), cache)
    if cache is not None:
        cache.trim()
    return _merge_pairs(geo.nshells, [(g, p) for _s, g, p in parts])[0]


def measure(geo, W, H, points, shift, radius, selected_only, tiles=False, same_mat=False, cache=None,
            stack_match=None):
    """Gaps, tile-border distances and overlaps. With `same_mat`, every material is measured
    on its own (shells of other materials use another texture), which is the same as
    filtering by material but skips the work between materials. With `stack_match` (0..1),
    shells covering each other at least that much are a stack - copies sharing texture space
    on purpose - and are measured as one shell: the result's `stacks` tells which.
    `cache`: a MeasureCache, to measure again only the groups that changed."""
    S = geo.nshells
    if S == 0:
        m = _Measurement()
        return m
    if cache is not None:
        cache.begin()
    grouped = _grouped(geo, same_mat, stack_match, cache)
    stacks = _merge_stacks(geo, grouped) if stack_match is not None else None
    sel = geo.shell_sel
    if stacks is not None and selected_only and sel.size == S:
        # a stack is selected when one of its shells is
        sel = np.bincount(stacks.rep, weights=sel, minlength=S)[stacks.rep] > 0
    parts = []
    computed = 0
    for sig, g, prs in _group_pairs(geo, grouped, cache):
        msig = (sig, int(W), int(H), int(points), float(shift), float(radius), bool(selected_only), bool(tiles),
                sel[g].tobytes() if selected_only else None)
        m = cache.get(cache.meas, msig) if cache is not None else None
        if m is None:
            sub = sub_geometry(geo, g)
            sub.pairs = prs
            if selected_only:
                sub.shell_sel = sel[g]
            m = _measure(sub, W, H, points, shift, radius, selected_only, tiles, False)
            computed += 1
            if cache is not None:
                cache.put(cache.meas, msig, m)
        parts.append((g, prs, m))
    if cache is not None:
        cache.stats = (computed, len(grouped))
        cache.trim()
    out = _merge_measurements(geo, parts)
    out.stacks = stacks
    if tiles:
        _tile_marks(with_selection(geo, sel) if selected_only else geo, selected_only, out)
    return out


def _merge_measurements(geo, parts):
    """One measurement from per-group ones (parts [(g, pairs, measurement)]), in the order a
    measurement of all shells at once lists its results."""
    S = geo.nshells
    m = _Measurement()
    m.shells_total = S
    if not parts:
        return m
    ms = [pm for _g, _p, pm in parts]
    m.shells_sampled = sum(pm.shells_sampled for pm in ms)
    m.samples = sum(pm.samples for pm in ms)
    m.overlap_pairs = sum(pm.overlap_pairs for pm in ms)

    def cat(name, shape2=False):
        arrs = [getattr(pm, name) for pm in ms]
        out = np.concatenate(arrs) if arrs else (_EMPTY2 if shape2 else _EMPTY_F)
        return out.reshape(-1, 2) if shape2 else out

    def by_shell(name):
        return np.concatenate([g[getattr(pm, name)] for g, _p, pm in parts]).astype(np.int64)

    # results of one shell stay together and in order; shells in global order
    src = by_shell("src")
    o = np.argsort(src, kind='stable')
    m.src, m.dst = src[o], by_shell("dst")[o]
    m.p_uv, m.q_uv, m.dist = cat("p_uv", True)[o], cat("q_uv", True)[o], cat("dist")[o]
    bsrc = by_shell("bsrc")
    o = np.argsort(bsrc, kind='stable')
    m.bsrc = bsrc[o]
    m.bp_uv, m.bf_uv, m.bdist = cat("bp_uv", True)[o], cat("bf_uv", True)[o], cat("bdist")[o]
    m.baxis = np.concatenate([pm.baxis for pm in ms]).astype(np.int64)[o]
    ov_src = by_shell("ov_src")
    o = np.argsort(ov_src, kind='stable')
    m.ov_src, m.ov_uv = ov_src[o], cat("ov_uv", True)[o]

    prs, gidx = _merge_pairs(S, [(g, p) for g, p, _m in parts])
    pi = np.concatenate([gi[pm.pair_label_pi] for gi, pm in zip(gidx, ms)]).astype(np.int64)
    o = np.argsort(pi, kind='stable')
    m.pair_label_pi, m.pair_label_uv = pi[o], cat("pair_label_uv", True)[o]
    ci = np.concatenate([gi[pm.cross_pi] for gi, pm in zip(gidx, ms)]).astype(np.int64)
    o = np.argsort(ci, kind='stable')
    m.cross_pi, m.cross_uv = ci[o], cat("cross_uv", True)[o]
    codes = []
    for g, _p, pm in parts:
        n = g.size
        c = pm.overlap_codes
        codes.append(g[c // max(n, 1)] * S + g[c % max(n, 1)])
    m.overlap_codes = np.unique(np.concatenate(codes).astype(np.int64))
    return m


# ---------------------------------------------------------------------------
# Shapes for drawing (pixel space, y up; the view flips y)
# ---------------------------------------------------------------------------

def segment_points(P, Q):
    """(2n, 2): P0, Q0, P1, Q1, ... - one line per pair."""
    v = np.empty((2 * P.shape[0], 2))
    v[0::2] = P
    v[1::2] = Q
    return v


def rect_points(R):
    """(4n, 2): the corners of rectangles (x0, y0, x1, y1), one closed quad each."""
    x0, y0, x1, y1 = R[:, 0], R[:, 1], R[:, 2], R[:, 3]
    return np.stack((np.column_stack((x0, y0)), np.column_stack((x1, y0)),
                     np.column_stack((x1, y1)), np.column_stack((x0, y1))), axis=1).reshape(-1, 2)


def square_points(C, h):
    return rect_points(np.column_stack((C[:, 0] - h, C[:, 1] - h, C[:, 0] + h, C[:, 1] + h)))


def cross_points(C, h):
    """(4n, 2): two lines per point."""
    cx, cy = C[:, 0], C[:, 1]
    return np.stack((np.column_stack((cx - h, cy - h)), np.column_stack((cx + h, cy + h)),
                     np.column_stack((cx - h, cy + h)), np.column_stack((cx + h, cy - h))), axis=1).reshape(-1, 2)


def tick_points(C, axis, h):
    """(2n, 2): short ticks along the tile edge at the foot points (the end cap of border lines)."""
    vert = axis == 0
    a = np.column_stack((np.where(vert, C[:, 0], C[:, 0] - h), np.where(vert, C[:, 1] - h, C[:, 1])))
    b = np.column_stack((np.where(vert, C[:, 0], C[:, 0] + h), np.where(vert, C[:, 1] + h, C[:, 1])))
    return segment_points(a, b)


def arrow_points(C, D, size):
    """(7n, 2): outlines of arrows centered on C, pointing along the unit vectors D, `size`
    long (one value or one per arrow): tail, along the shaft, the head, back to the tail."""
    size = np.broadcast_to(np.asarray(size, dtype=np.float64), (C.shape[0],))[:, None]
    N = np.column_stack((-D[:, 1], D[:, 0]))
    tip = C + D * (size * 0.5)
    neck = tip - D * (size * 0.45)
    tail = C - D * (size * 0.5)
    sw = N * np.maximum(0.8, size * 0.08)
    hw = N * (size * 0.3)
    return np.stack((tail - sw, neck - sw, neck - hw, tip, neck + hw, neck + sw, tail + sw),
                    axis=1).reshape(-1, 2)


def in_region(C, rw, rh, margin):
    return ((C[:, 0] >= -margin) & (C[:, 0] <= rw + margin) &
            (C[:, 1] >= -margin) & (C[:, 1] <= rh + margin))


def visible_segments(P, Q, rw, rh, margin):
    return ((np.maximum(P[:, 0], Q[:, 0]) >= -margin) & (np.minimum(P[:, 0], Q[:, 0]) <= rw + margin) &
            (np.maximum(P[:, 1], Q[:, 1]) >= -margin) & (np.minimum(P[:, 1], Q[:, 1]) <= rh + margin))


def loop_starts(geo):
    """Indices of the border segments that start a loop (outer border or hole): the borders
    are ordered loop by loop, so a segment that doesn't start where the previous one ended
    starts a new loop. Ends with the segment count."""
    n = geo.seg_a.shape[0]
    if not n:
        return np.zeros(1, dtype=np.int64)
    brk = np.ones(n, dtype=bool)
    if n > 1:
        brk[1:] = (geo.seg_a[1:] != geo.seg_b[:-1]).any(axis=1)
    brk[geo.shell_off[:-1]] = True
    return np.concatenate((np.flatnonzero(brk), [n])).astype(np.int64)


def fill_loops(geo):
    """(points, element types: 0 starts a loop, 1 continues it) of every shell's border loops,
    for filled paths. Mirrored shells' loops are reversed, so every shell winds the same way:
    a shell and its mirrored twin stacked on it (a common way to share texture between halves)
    don't cancel out under the non-zero fill rule; holes still wind against their shell."""
    starts = loop_starts(geo)
    n = int(starts[-1])
    if not n:
        return _EMPTY2, np.zeros(0, dtype=np.int32)
    lens = np.diff(starts)
    loop = np.repeat(np.arange(lens.size), lens)
    pos = np.arange(n, dtype=np.int64) - starts[:-1][loop]
    rev = geo.flipped[geo.seg_shell[starts[:-1]]][loop] if geo.flipped.size else np.zeros(n, dtype=bool)
    src = np.where(rev, starts[:-1][loop] + lens[loop] - 1 - pos, np.arange(n, dtype=np.int64))
    return geo.seg_a[src], (pos != 0).astype(np.int32)


# ---------------------------------------------------------------------------
# Labels and info blocks
# ---------------------------------------------------------------------------

class Labels:
    """Label boxes in priority order - one or more text lines, optionally an arrow (per-shell
    info blocks) - plus line colors; rebuilt only when the measurement or the style changes.

    Per label: anchor (UV), lifted, nlines, width (content, px), icon (UV direction, NaN: none),
    icon_rgb, icw (arrow column width: as tall as the block, at least iw). Per text line: text,
    rgb, line_of (label), row. th: text height, lh: line pitch."""
    __slots__ = ("anchor", "lifted", "nlines", "width", "icon", "icon_rgb", "icw",
                 "text", "rgb", "line_of", "row", "th", "lh", "iw", "gap_rgb", "border_rgb")


class TextMetrics:
    """Text size for label layout: th, the height of the digits, and width(text), in pixels.
    This one estimates them from the font size; the view passes the real font's metrics."""

    def __init__(self, size):
        self.size = float(size)
        self.th = self.size * 0.72

    def width(self, text):
        return len(text) * self.size * 0.56


STACK_RGB = (0.78, 0.78, 0.82)  # the "x N" line of a stack's info block


def build_labels(geo, meas, st, metrics, td_info, info=None, stacks=None, stack_lines=True):
    """`metrics`: TextMetrics-like (th, width(text)). `td_info`: (densities in px/m, unit label,
    factor from px/m, (low, needed, high)) or None. `info`: (show object scale, show orientation
    arrows, show Flipped) for the per-shell info blocks; by default Flipped follows the gap
    overlay and the other two are off. `stacks` (Stacks): a stack gets one block, on the shell
    standing for it - with `stack_lines`, telling the number of shells in it. What differs
    between a stack's shells shows in that block: the span of their densities ("256 - 512
    px/m": copies of different size in the scene), "Scale varies"."""
    lab = Labels()
    lab.th = th = float(metrics.th)
    lab.lh = th * 1.45
    lab.iw = th * 1.7
    c0 = np.array(st.color_zero[:], dtype=np.float64)
    c1 = np.array(st.color_min[:], dtype=np.float64)
    c2 = np.array(st.color_needed[:], dtype=np.float64)
    c_ov = np.array(st.color_overlap[:], dtype=np.float64)
    c_fl = tuple(float(c) for c in st.color_flipped[:])
    if meas is not None:
        lab.gap_rgb = _gradient(meas.dist, st.min_px, st.needed_px, c0, c1, c2)
        lab.border_rgb = _gradient(meas.bdist, st.border_min_px, st.border_needed_px, c0, c1, c2)
    else:
        lab.gap_rgb = lab.border_rgb = np.empty((0, 3))
    if info is None:
        info = (False, False, meas is not None and bool(st.show_flipped))
    show_scale, show_orient, show_flip = info

    # problems first (tile crossings, overlaps), then the shells' info blocks (those with a
    # warning first), then distances by severity
    anchors, lifted, icons, icon_rgb, lines = [], [], [], [], []

    def add(pts, text, rgb, lift):
        k = len(pts)
        if k:
            anchors.append(np.asarray(pts, dtype=np.float64).reshape(-1, 2))
            lifted.append(np.full(k, 1.0 if lift else 0.0))
            icons.append(np.full((k, 2), np.nan))
            icon_rgb.append(np.zeros((k, 3)))
            rgbs = (np.tile(rgb, (k, 1)) if np.ndim(rgb) == 1 else np.asarray(rgb)).tolist()
            txts = [text] * k if isinstance(text, str) else text
            lines.extend([[(t, tuple(c))] for t, c in zip(txts, rgbs)])

    if meas is not None:
        add(meas.tile_label_uv, "Crosses tile", c_ov, True)
        add(meas.pair_label_uv, "Overlap", c_ov, True)
        add(meas.ov_uv, "Overlap", c_ov, True)

    n = geo.sh_n
    if n:
        has = np.zeros(n, dtype=bool)
        warn = np.zeros(n, dtype=bool)
        td_ok = np.zeros(n, dtype=bool)
        td_txt = td_col = None
        if td_info is not None and len(td_info[0]) == n:
            td, unit, factor, thr = td_info
            td_ok = np.isfinite(td)
            ok = np.flatnonzero(td_ok)
            td_txt = dict(zip(ok.tolist(), [_fmt_td(v, unit) for v in (td[ok] * factor).tolist()]))
            td_col = dict(zip(ok.tolist(), map(tuple, (_td_rgb(td[ok], *thr) * 0.55 + 0.45).tolist())))
            has |= td_ok  # lighter colors: readable on the dark box
        scale_on = np.zeros(n, dtype=bool)
        otxt = []
        if show_scale and geo.obj_scale:
            otxt = [_fmt_scale(s) for s in geo.obj_scale]
            scale_on = np.asarray([t is not None for t in otxt], dtype=bool)[geo.sh_obj]
            has |= scale_on
            warn |= scale_on
        flip = np.zeros(n, dtype=bool)
        if show_flip and geo.flipped.size and geo.gap_shell.size == geo.flipped.size:
            flip[geo.gap_shell] = geo.flipped
            has |= flip
            warn |= flip
        arrow = (geo.sh_axis > 0) if show_orient and geo.sh_axis.size == n else np.zeros(n, dtype=bool)
        has |= arrow
        stack_txt = {}
        scale_varies = np.zeros(n, dtype=bool)
        if stacks is not None and stacks.rep.size == geo.nshells and geo.gap_shell.size == geo.nshells:
            copies = geo.gap_shell[stacks.copies()]
            mem = geo.gap_shell                    # every gap shell, and the shell standing for it
            rep_of = geo.gap_shell[stacks.rep]
            stacked = stacks.size[stacks.rep] > 1
            if td_txt is not None and stacked.any():
                # the densities of a stack's shells: one number when they agree, else their span
                lo, hi = np.full(n, np.inf), np.full(n, -np.inf)
                m = stacked & td_ok[mem]
                np.minimum.at(lo, rep_of[m], td[mem[m]])
                np.maximum.at(hi, rep_of[m], td[mem[m]])
                for a in np.flatnonzero(np.isfinite(lo)).tolist():
                    if hi[a] > lo[a] * 1.005:
                        td_txt[a] = "%s – %s" % (_fmt_td(lo[a] * factor, "").strip(), _fmt_td(hi[a] * factor, unit))
                        warn[a] = True
                    else:
                        td_txt[a] = _fmt_td(lo[a] * factor, unit)
                    td_col[a] = tuple((_td_rgb(np.array([lo[a]]), *thr)[0] * 0.55 + 0.45).tolist())
                    td_ok[a] = has[a] = True
            if show_scale and otxt and stacked.any():
                codes = {}
                code = np.asarray([codes.setdefault(t, len(codes)) for t in otxt], dtype=np.int64)[geo.sh_obj]
                lo_c, hi_c = np.full(n, len(codes), dtype=np.int64), np.full(n, -1, dtype=np.int64)
                np.minimum.at(lo_c, rep_of[stacked], code[mem[stacked]])
                np.maximum.at(hi_c, rep_of[stacked], code[mem[stacked]])
                scale_varies = hi_c > lo_c
                scale_varies[copies] = False
                has |= scale_varies
                warn |= scale_varies
            has[copies] = False  # (they lie under the shell standing for their stack)
            warn[copies] = False
            u = stacks.unique()
            u = u[stacks.size[u] > 1] if stack_lines else u[:0]
            for g, k, nf in zip(u.tolist(), stacks.size[u].tolist(), stacks.nflip[u].tolist()):
                a = int(geo.gap_shell[g])
                # (a flipped stack says Flipped itself: all its shells are)
                stack_txt[a] = "× %d" % k if (nf == 0 or nf == k) else "× %d (%d flipped)" % (k, nf)
            if stack_txt:
                has[np.fromiter(stack_txt, dtype=np.int64, count=len(stack_txt))] = True
        order = np.concatenate((np.flatnonzero(has & warn), np.flatnonzero(has & ~warn)))
        if order.size:
            obj = geo.sh_obj.tolist()
            for i in order.tolist():
                ln = []
                if td_ok[i]:
                    ln.append((td_txt[i], td_col[i]))
                if i in stack_txt:
                    ln.append((stack_txt[i], STACK_RGB))
                if scale_varies[i]:
                    ln.append(("Scale varies", SCALE_RGB))
                elif scale_on[i]:
                    ln.append(("Scale " + otxt[obj[i]], SCALE_RGB))
                if flip[i]:
                    ln.append(("Flipped", c_fl))
                lines.append(ln)
            k = order.size
            anchors.append(geo.sh_anchor[order])
            lifted.append(np.zeros(k))
            ic = np.full((k, 2), np.nan)
            icr = np.zeros((k, 3))
            a = arrow[order]
            if a.any():
                ic[a] = geo.sh_orient[order][a]
                icr[a] = np.asarray([AXIS_RGB.get(c, (0.8, 0.8, 0.8)) for c in geo.sh_axis[order][a].tolist()])
            icons.append(ic)
            icon_rgb.append(icr)

    if meas is not None:
        d_all = np.concatenate((meas.dist, meas.bdist))
        if d_all.size:
            severity = np.concatenate((meas.dist / max(float(st.needed_px), 1e-6),
                                       meas.bdist / max(float(st.border_needed_px), 1e-6)))
            order = np.argsort(severity, kind='stable')
            mids = np.concatenate(((meas.p_uv + meas.q_uv) * 0.5, (meas.bp_uv + meas.bf_uv) * 0.5))
            add(mids[order], [_fmt_px(x) for x in d_all[order].tolist()],
                np.concatenate((lab.gap_rgb, lab.border_rgb))[order], False)

    nlab = len(lines)
    lab.anchor = np.concatenate(anchors) if anchors else _EMPTY2
    lab.lifted = np.concatenate(lifted) if lifted else _EMPTY_F
    lab.icon = np.concatenate(icons) if icons else _EMPTY2
    lab.icon_rgb = np.concatenate(icon_rgb) if icon_rgb else np.empty((0, 3))
    counts = np.asarray([len(x) for x in lines], dtype=np.int64)
    lab.nlines = counts
    flat = [t for x in lines for t in x]
    lab.text = [t for t, _c in flat]
    lab.rgb = np.asarray([c for _t, c in flat], dtype=np.float64).reshape(-1, 3)
    lab.line_of = np.repeat(np.arange(nlab, dtype=np.int64), counts)
    lab.row = np.arange(len(flat), dtype=np.int64) - np.repeat(np.cumsum(counts) - counts, counts)
    widths = {t: float(metrics.width(t)) for t in set(lab.text)}
    maxw = np.zeros(nlab)
    if flat:
        np.maximum.at(maxw, lab.line_of, np.asarray([widths[t] for t in lab.text], dtype=np.float64))
    has_icon = np.isfinite(lab.icon[:, 0]) if nlab else np.zeros(0, dtype=bool)
    tall = th + (np.maximum(counts, 1) - 1) * lab.lh
    lab.icw = np.where(has_icon, np.maximum(lab.iw, tall), 0.0)
    lab.width = maxw + lab.icw + np.where(has_icon & (counts > 0), th * 0.35, 0.0)
    return lab


# ---------------------------------------------------------------------------
# Shell data for the panel: material sets, density ranges, Low / High auto-fill
# ---------------------------------------------------------------------------

class Published:
    __slots__ = ("key", "td", "k", "mat", "mat_keys", "mat_total", "mat_vis", "stats", "tmin", "tmax")


def material_label(key):
    return key if key else NO_MATERIAL


def published(key, td, k, mat, mat_keys, mat_total, mat_vis):
    """Per-shell densities (px/m, for the density factor `k`) and materials, with per-material
    statistics: (shells shown, lowest density, highest density, faces, faces shown)."""
    p = Published()
    p.key = key
    p.td = np.asarray(td, dtype=np.float64)
    p.k = float(k)
    p.mat = np.asarray(mat, dtype=np.int64)
    p.mat_keys = list(mat_keys)
    p.mat_total = np.asarray(mat_total, dtype=np.int64)
    p.mat_vis = np.asarray(mat_vis, dtype=np.int64)
    nm = len(p.mat_keys)
    ok = np.isfinite(p.td)
    counts = np.bincount(p.mat, minlength=nm) if p.mat.size else np.zeros(nm, dtype=np.int64)
    lo = np.full(nm, np.inf)
    hi = np.full(nm, -np.inf)
    if ok.any():
        np.minimum.at(lo, p.mat[ok], p.td[ok])
        np.maximum.at(hi, p.mat[ok], p.td[ok])
    p.stats = {mk: (int(counts[i]), float(lo[i]) if np.isfinite(lo[i]) else None,
                    float(hi[i]) if np.isfinite(hi[i]) else None, int(p.mat_total[i]), int(p.mat_vis[i]))
               for i, mk in enumerate(p.mat_keys)}
    p.tmin = float(p.td[ok].min()) if ok.any() else None
    p.tmax = float(p.td[ok].max()) if ok.any() else None
    return p


def publish_geometry(geo, W, H, key=None):
    """Published shells of an extracted geometry (texture W x H, Maya's centimeters)."""
    td = _td_values(geo.td_uv_area, geo.td_world_area, W, H, 1.0) if geo.td_nshells else np.full(geo.sh_n, np.nan)
    return published(key, td, _td_factor(W, H, 1.0), geo.sh_mat, geo.mat_keys, geo.mat_total, geo.mat_vis)


def listed_materials(pub):
    """Material keys for the Materials list: those with faces on the shown objects, by name,
    faces without a material last."""
    shown = [k for k, (_n, _lo, _hi, faces, _fv) in pub.stats.items() if faces > 0]
    shown.sort(key=lambda k: (k == "", material_label(k).lower()))
    return shown


def td_range_of(pub, checked):
    """(lowest, highest) density of the shells in the checked material sets (all shells when
    none is checked), or None."""
    if pub is None or not pub.td.size:
        return None
    mask = np.isfinite(pub.td)
    if checked:
        chk = set(checked)
        ids = [i for i, k in enumerate(pub.mat_keys) if k in chk]
        mask &= np.isin(pub.mat, ids)
    if not mask.any():
        return None
    vals = pub.td[mask]
    return float(vals.min()), float(vals.max())


def auto_range(pub, checked, kc):
    """(low, high) of the checked sets for the density factor kc, or None."""
    rng = td_range_of(pub, checked)
    if rng is None or not pub.k > 0.0:
        return None
    f = kc / pub.k
    return rng[0] * f, rng[1] * f


def shells_of_sets(geo, keys):
    """Shells (all-shell indices) whose material - the one covering most of the shell's UV
    area - is one of `keys`."""
    ids = [i for i, k in enumerate(geo.mat_keys) if k in set(keys)]
    if not geo.sh_n or not ids:
        return _EMPTY_I
    return np.flatnonzero(np.isin(geo.sh_mat, ids))


def shells_in_range(td, f0, f1):
    """Shells whose density is within fractions f0..f1 of the lowest..highest density."""
    bounds = _td_range_bounds(td, f0, f1)
    if bounds is None:
        return _EMPTY_I, None
    with np.errstate(invalid='ignore'):
        return np.flatnonzero((td >= bounds[0]) & (td <= bounds[1])), bounds


def flipped_shells(geo):
    """All-shell indices of the mirrored shells."""
    if not geo.gap_shell.size:
        return _EMPTY_I
    return geo.gap_shell[geo.flipped]


def components_of_shells(geo, shells):
    """Per object: (UV ids, face ids) of the given shells (all-shell indices)."""
    pick = np.zeros(max(geo.sh_n, 1), dtype=bool)
    shells = np.asarray(shells, dtype=np.int64)
    pick[shells[(shells >= 0) & (shells < geo.sh_n)]] = True
    out = []
    for cu, cs, fi, fs in zip(geo.obj_corner_uvid, geo.obj_corner_shell, geo.obj_fidx, geo.obj_face_shell):
        uv = np.unique(cu[pick[cs]]) if cs.size else _EMPTY_I
        faces = fi[pick[fs]] if fs.size else _EMPTY_I
        out.append((uv, faces))
    return out


def shell_at(geo, u, v):
    """The shell (all-shell index) under the UV point (u, v), or -1: inside an odd number of
    its border loops; the smallest of several."""
    if not geo.nshells:
        return -1
    a, b = geo.seg_a, geo.seg_b
    with np.errstate(divide='ignore', invalid='ignore'):
        cross = (a[:, 1] > v) != (b[:, 1] > v)
        t = (v - a[:, 1]) / (b[:, 1] - a[:, 1])
        x = a[:, 0] + t * (b[:, 0] - a[:, 0])
    hit = cross & (x > u)
    odd = (np.bincount(geo.seg_shell[hit], minlength=geo.nshells) % 2) == 1
    cand = np.flatnonzero(odd)
    if not cand.size:
        return -1
    g = int(cand[np.argmin(np.abs(geo.shell_area[cand]))])
    return int(geo.gap_shell[g])


# ---------------------------------------------------------------------------
# The UV layer: what the UV view draws and picks (points, edges, faces, triangles)
# ---------------------------------------------------------------------------

class UVLayer:
    """The shown faces of all objects as one set of arrays, objects one after another.

    pts (N, 2): a point per (object, UV id) used by the shown faces; pt_obj, pt_uvid, pt_shell
    (all-shell index). Faces: face_obj, face_id (the mesh's face id), face_shell, face_off
    (into the corners). Corners: corner_pt (point), corner_vert (mesh vertex), corner_face.
    wire (E, 2): point pairs, every UV edge once. tri (T, 3): fan triangles, tri_face.
    obj_*_off: where each object's points / faces / corners start (one more entry at the end)."""
    __slots__ = ("pts", "pt_obj", "pt_uvid", "pt_shell", "face_obj", "face_id", "face_shell", "face_off",
                 "corner_pt", "corner_vert", "corner_face", "wire", "tri", "tri_face",
                 "obj_pt_off", "obj_face_off", "obj_corner_off", "nobj", "_fbox", "_cnext")

    def __init__(self):
        self.pts = _EMPTY2
        self.pt_obj = self.pt_uvid = self.pt_shell = np.zeros(0, dtype=np.int32)
        self.face_obj = self.face_id = self.face_shell = np.zeros(0, dtype=np.int32)
        self.face_off = np.zeros(1, dtype=np.int64)
        self.corner_pt = self.corner_vert = self.corner_face = np.zeros(0, dtype=np.int32)
        self.wire = np.zeros((0, 2), dtype=np.int32)
        self.tri = np.zeros((0, 3), dtype=np.int32)
        self.tri_face = np.zeros(0, dtype=np.int32)
        self.obj_pt_off = self.obj_face_off = self.obj_corner_off = np.zeros(1, dtype=np.int64)
        self.nobj = 0
        self._fbox = None
        self._cnext = None

    def corner_next(self):
        """The next corner of each corner's face."""
        if self._cnext is None:
            n = self.corner_pt.size
            nxt = np.arange(1, n + 1, dtype=np.int64)
            if self.face_off.size > 1:
                last = self.face_off[1:] - 1
                nxt[last] = self.face_off[:-1]
            self._cnext = nxt
        return self._cnext

    def face_boxes(self):
        """(F, 4) UV bounds of the faces: u0, v0, u1, v1."""
        if self._fbox is None:
            P = self.pts[self.corner_pt]
            if self.face_obj.size:
                st = self.face_off[:-1]
                self._fbox = np.column_stack((np.minimum.reduceat(P[:, 0], st), np.minimum.reduceat(P[:, 1], st),
                                              np.maximum.reduceat(P[:, 0], st), np.maximum.reduceat(P[:, 1], st)))
            else:
                self._fbox = np.zeros((0, 4))
        return self._fbox

    def face_centers(self):
        if not self.face_obj.size:
            return _EMPTY2
        P = self.pts[self.corner_pt]
        st = self.face_off[:-1]
        n = np.diff(self.face_off).astype(np.float64)
        return np.column_stack((np.add.reduceat(P[:, 0], st) / n, np.add.reduceat(P[:, 1], st) / n))


def build_layer(geo):
    """The UV layer of an assembled geometry (from its objects' parts)."""
    L = UVLayer()
    objs = geo.obj_parts
    L.nobj = len(objs)
    if not objs:
        return L
    npt = np.array([P.vxy.shape[0] for P in objs], dtype=np.int64)
    nfa = np.array([P.fidx.size for P in objs], dtype=np.int64)
    nco = np.array([P.vid.size for P in objs], dtype=np.int64)
    L.obj_pt_off = np.concatenate(([0], np.cumsum(npt)))
    L.obj_face_off = np.concatenate(([0], np.cumsum(nfa)))
    L.obj_corner_off = np.concatenate(([0], np.cumsum(nco)))
    shell_base = np.concatenate(([0], np.cumsum([P.sh["nshell"] for P in objs])))
    L.pts = np.concatenate([P.vxy for P in objs])
    L.pt_obj = np.repeat(np.arange(len(objs), dtype=np.int32), npt)
    L.corner_pt = np.concatenate([P.vid + int(b) for P, b in zip(objs, L.obj_pt_off[:-1].tolist())]).astype(np.int32)
    L.corner_vert = np.concatenate([P.corner_vert for P in objs]).astype(np.int32)
    L.face_obj = np.repeat(np.arange(len(objs), dtype=np.int32), nfa)
    L.face_id = np.concatenate([P.fidx for P in objs]).astype(np.int32)
    L.face_shell = np.concatenate([P.face_shell + int(b) for P, b in zip(objs, shell_base[:-1].tolist())]).astype(np.int32)
    tot = np.concatenate([P.tot for P in objs]).astype(np.int64)
    L.face_off = np.concatenate(([0], np.cumsum(tot))).astype(np.int64)
    L.corner_face = np.repeat(np.arange(tot.size, dtype=np.int32), tot)
    # UV id and shell per point (a UV vertex belongs to one shell)
    L.pt_uvid = np.zeros(L.pts.shape[0], dtype=np.int32)
    L.pt_uvid[L.corner_pt] = np.concatenate([P.corner_uvid for P in objs]).astype(np.int32)
    L.pt_shell = np.zeros(L.pts.shape[0], dtype=np.int32)
    L.pt_shell[L.corner_pt] = L.face_shell[L.corner_face]
    L.wire = np.concatenate([P.wire_i + int(b) for P, b in zip(objs, L.obj_pt_off[:-1].tolist())]).astype(np.int32)
    # fan triangles (0, k, k + 1) of every face
    nt = np.maximum(tot - 2, 0)
    tf = np.repeat(np.arange(tot.size, dtype=np.int64), nt)
    k = np.arange(int(nt.sum()), dtype=np.int64) - np.repeat(np.cumsum(nt) - nt, nt) + 1
    c0 = L.face_off[:-1][tf]
    L.tri = np.column_stack((L.corner_pt[c0], L.corner_pt[c0 + k], L.corner_pt[c0 + k + 1])).astype(np.int32)
    L.tri_face = tf.astype(np.int32)
    return L


# -- picking --------------------------------------------------------------------------------

def pick_point(L, u, v, radius):
    """The UV point nearest to (u, v) within radius (UV units), or -1."""
    if not L.pts.shape[0]:
        return -1
    d2 = (L.pts[:, 0] - u) ** 2 + (L.pts[:, 1] - v) ** 2
    i = int(np.argmin(d2))
    return i if d2[i] <= radius * radius else -1


def points_in_rect(L, u0, v0, u1, v1):
    P = L.pts
    return np.flatnonzero((P[:, 0] >= u0) & (P[:, 0] <= u1) & (P[:, 1] >= v0) & (P[:, 1] <= v1))


def _seg_dist2(P, A, B):
    D = B - A
    L2 = (D * D).sum(axis=1)
    t = np.clip(((P - A) * D).sum(axis=1) / np.where(L2 > 0.0, L2, 1.0), 0.0, 1.0)
    Q = A + D * t[:, None]
    return ((P - Q) ** 2).sum(axis=1)


def pick_edge(L, u, v, radius):
    """The UV edge (index into wire) nearest to (u, v) within radius, or -1."""
    if not L.wire.shape[0]:
        return -1
    A, B = L.pts[L.wire[:, 0]], L.pts[L.wire[:, 1]]
    near = np.flatnonzero((np.minimum(A[:, 0], B[:, 0]) <= u + radius) & (np.maximum(A[:, 0], B[:, 0]) >= u - radius) &
                          (np.minimum(A[:, 1], B[:, 1]) <= v + radius) & (np.maximum(A[:, 1], B[:, 1]) >= v - radius))
    if not near.size:
        return -1
    d2 = _seg_dist2(np.array([[u, v]]), A[near], B[near])
    i = int(np.argmin(d2))
    return int(near[i]) if d2[i] <= radius * radius else -1


def edges_in_rect(L, u0, v0, u1, v1):
    """UV edges (indices into wire) whose middle lies in the rectangle."""
    M = (L.pts[L.wire[:, 0]] + L.pts[L.wire[:, 1]]) * 0.5
    return np.flatnonzero((M[:, 0] >= u0) & (M[:, 0] <= u1) & (M[:, 1] >= v0) & (M[:, 1] <= v1))


def edge_corners(L, a, b):
    """Corners whose edge (to the next corner of the face) joins points a and b, either way."""
    nxt = L.corner_next()
    c, n = L.corner_pt, L.corner_pt[nxt]
    return np.flatnonzero(((c == a) & (n == b)) | ((c == b) & (n == a)))


def corners_of_wire(L, edges):
    """Per UV edge (indices into wire): one corner whose edge it is (-1 if none)."""
    edges = np.asarray(edges, dtype=np.int64)
    out = np.full(edges.size, -1, dtype=np.int64)
    if not edges.size:
        return out
    nv = max(int(L.pts.shape[0]), 1)
    nxt = L.corner_next()
    c, n = L.corner_pt.astype(np.int64), L.corner_pt[nxt].astype(np.int64)
    ck = np.minimum(c, n) * nv + np.maximum(c, n)
    w = L.wire[edges].astype(np.int64)
    wk = np.minimum(w[:, 0], w[:, 1]) * nv + np.maximum(w[:, 0], w[:, 1])
    o = np.argsort(ck, kind='stable')
    pos = np.searchsorted(ck[o], wk)
    ok = (pos < ck.size) & (ck[o][np.minimum(pos, ck.size - 1)] == wk)
    out[ok] = o[pos[ok]]
    return out


def pick_face(L, u, v):
    """The face whose UVs contain (u, v) (the smallest of several), or -1."""
    if not L.face_obj.size:
        return -1
    box = L.face_boxes()
    cand = np.flatnonzero((box[:, 0] <= u) & (box[:, 2] >= u) & (box[:, 1] <= v) & (box[:, 3] >= v))
    if not cand.size:
        return -1
    tsel = np.flatnonzero(np.isin(L.tri_face, cand))
    T = L.pts[L.tri[tsel]]  # (t, 3, 2)
    a, b, c = T[:, 0], T[:, 1], T[:, 2]

    def side(p, q):
        return (q[:, 0] - p[:, 0]) * (v - p[:, 1]) - (q[:, 1] - p[:, 1]) * (u - p[:, 0])
    s1, s2, s3 = side(a, b), side(b, c), side(c, a)
    inside = ((s1 >= 0) & (s2 >= 0) & (s3 >= 0)) | ((s1 <= 0) & (s2 <= 0) & (s3 <= 0))
    hit = np.unique(L.tri_face[tsel[inside]])
    if not hit.size:
        return -1
    area = (box[hit, 2] - box[hit, 0]) * (box[hit, 3] - box[hit, 1])
    return int(hit[np.argmin(area)])


def faces_in_rect(L, u0, v0, u1, v1):
    """Faces whose center lies in the rectangle."""
    C = L.face_centers()
    return np.flatnonzero((C[:, 0] >= u0) & (C[:, 0] <= u1) & (C[:, 1] >= v0) & (C[:, 1] <= v1))


def shells_in_rect(L, u0, v0, u1, v1):
    """Shells (all-shell indices) with a point in the rectangle."""
    return np.unique(L.pt_shell[points_in_rect(L, u0, v0, u1, v1)])


def per_object(L, idx, off):
    """Group indices (points, faces or corners) by object: [(object, indices relative to the
    object's start)] in object order. `off`: the matching obj_*_off."""
    idx = np.unique(np.asarray(idx, dtype=np.int64))
    out = []
    if not idx.size:
        return out
    obj = np.searchsorted(off, idx, side='right') - 1
    cut = np.flatnonzero(np.diff(obj)) + 1
    for grp in np.split(idx, cut):
        o = int(obj[np.searchsorted(idx, grp[0])])
        out.append((o, grp - off[o]))
    return out


# -- what is selected, in layer terms --------------------------------------------------------

def object_index(geo):
    """{object key: object index} of an assembled geometry."""
    return {k: i for i, k in enumerate(geo.obj_keys)}


def points_of_uvs(L, o, uv_ids):
    """Layer points of object o with these UV ids."""
    a, b = int(L.obj_pt_off[o]), int(L.obj_pt_off[o + 1])
    ids = np.asarray(uv_ids, dtype=np.int64)
    if not ids.size or a == b:
        return np.zeros(0, dtype=np.int64)
    pu = L.pt_uvid[a:b].astype(np.int64)
    top = int(max(pu.max(), ids.max())) + 1
    mask = np.zeros(top, dtype=bool)
    mask[ids[ids >= 0]] = True
    return np.flatnonzero(mask[pu]) + a


def faces_of_ids(L, o, face_ids):
    """Layer faces of object o with these mesh face ids."""
    a, b = int(L.obj_face_off[o]), int(L.obj_face_off[o + 1])
    ids = np.asarray(face_ids, dtype=np.int64)
    if not ids.size or a == b:
        return np.zeros(0, dtype=np.int64)
    fi = L.face_id[a:b].astype(np.int64)
    top = int(max(fi.max(), ids.max())) + 1
    mask = np.zeros(top, dtype=bool)
    mask[ids[ids >= 0]] = True
    return np.flatnonzero(mask[fi]) + a


def corners_of_verts(L, o, vert_ids):
    """Layer corners of object o on these mesh vertices."""
    a, b = int(L.obj_corner_off[o]), int(L.obj_corner_off[o + 1])
    ids = np.asarray(vert_ids, dtype=np.int64)
    if not ids.size or a == b:
        return np.zeros(0, dtype=np.int64)
    cv = L.corner_vert[a:b].astype(np.int64)
    top = int(max(cv.max(), ids.max())) + 1
    mask = np.zeros(top, dtype=bool)
    mask[ids[ids >= 0]] = True
    return np.flatnonzero(mask[cv]) + a


def corners_of_edges(L, o, vert_pairs):
    """Layer corners of object o whose face edge (to the next corner) joins one of these mesh
    vertex pairs (either way)."""
    a, b = int(L.obj_corner_off[o]), int(L.obj_corner_off[o + 1])
    vp = np.asarray(vert_pairs, dtype=np.int64).reshape(-1, 2)
    if not vp.size or a == b:
        return np.zeros(0, dtype=np.int64)
    nxt = L.corner_next()[a:b]
    c, n = L.corner_vert[a:b].astype(np.int64), L.corner_vert[nxt].astype(np.int64)
    nv = int(max(c.max(), vp.max())) + 1
    ck = np.minimum(c, n) * nv + np.maximum(c, n)
    ek = np.minimum(vp[:, 0], vp[:, 1]) * nv + np.maximum(vp[:, 0], vp[:, 1])
    return np.flatnonzero(np.isin(ck, ek)) + a


# -- overlapping shells ---------------------------------------------------------------------------

def overlapping_shells(geo, pairs, stacks=None):
    """All-shell indices of the shells in an overlapping pair; with `stacks`, every shell of
    the stacks involved."""
    if pairs is None or not len(pairs):
        return _EMPTY_I
    g = np.unique(np.concatenate((pairs.s, pairs.c)))
    if stacks is not None:
        g = stacks.members(g)
    return geo.gap_shell[g]


def whole_stacks(geo, shells, stacks):
    """The shells (all-shell indices) with every shell of their stacks."""
    shells = np.unique(np.asarray(shells, dtype=np.int64))
    if stacks is None or not shells.size or stacks.rep.size != geo.nshells:
        return shells
    gid = geo.sh_gid[shells]
    ok = gid >= 0
    if not ok.any():
        return shells
    mates = geo.gap_shell[stacks.members(stacks.rep[gid[ok]])]
    return np.unique(np.concatenate((shells, mates)))


def stack_copies(geo, stacks):
    """All-shell indices of the copies in stacks: every stacked shell but the one standing
    for its stack (one that isn't flipped, where the stack has one)."""
    if stacks is None:
        return _EMPTY_I
    return geo.gap_shell[stacks.copies()]


def overlaps_but_one(geo, pairs, stacks=None):
    """Shells to move away so that no shell lies on another: of every stack, and of every set
    of overlapping shells, one stays. Which: one that isn't flipped where there is one, then
    the one standing for the most shells (a stack before a single shell lying on it), then the
    largest, then the first. (Greedy: shells are kept in that order unless they overlap one
    kept already; a stack goes or stays as the shell standing for it does, its copies always
    go.) All-shell indices."""
    S = geo.nshells
    moved = np.zeros(S, dtype=bool)
    if stacks is not None:
        moved[stacks.copies()] = True
    if pairs is not None and len(pairs):
        s, c = pairs.s, pairs.c
        inv = np.unique(np.concatenate((s, c)))
        flipped = geo.flipped[inv] if geo.flipped.size else np.zeros(inv.size, dtype=bool)
        area = np.abs(geo.shell_area[inv]) if geo.shell_area.size else np.zeros(inv.size)
        top = float(area.max()) if area.size else 0.0
        # (copies have the same area up to rounding: sizes compared to six digits)
        size = np.rint(area / top * 1e6) if top > 0.0 else np.zeros(inv.size)
        count = stacks.size[inv] if stacks is not None else np.ones(inv.size, dtype=np.int64)
        order = inv[np.lexsort((inv, -size, -count, flipped))]
        nbr = {}
        for a, b in zip(s.tolist(), c.tolist()):
            nbr.setdefault(a, []).append(b)
            nbr.setdefault(b, []).append(a)
        kept, gone = set(), []
        for g in order.tolist():
            if any(x in kept for x in nbr.get(g, ())):
                gone.append(g)
            else:
                kept.add(g)
        if gone:
            gone = np.asarray(gone, dtype=np.int64)
            moved[stacks.members(gone) if stacks is not None else gone] = True
    return geo.gap_shell[np.flatnonzero(moved)]


# ---------------------------------------------------------------------------
# Texel density colors in steps (the 3D view draws one mesh per step)
# ---------------------------------------------------------------------------

TD_STEPS = 8  # color steps per hue sextant (red -> yellow -> green -> cyan -> blue: 4 sextants)


def td_levels(td, low, needed, high, steps=TD_STEPS):
    """Color step per density (0 .. 4 * steps; -1: no density): the hue of td_rgb, rounded."""
    td = np.asarray(td, dtype=np.float64)
    t = np.ones(td.shape)
    with np.errstate(invalid='ignore', divide='ignore'):
        below = td < needed
        above = td > needed
        if needed > low:
            t[below] = np.clip((td[below] - low) / (needed - low), 0.0, 1.0)
        else:
            t[below] = 0.0
        if high > needed:
            t[above] = 1.0 + np.clip((td[above] - needed) / (high - needed), 0.0, 1.0)
        else:
            t[above] = 2.0
    lv = np.rint(t * 2.0 * steps).astype(np.int64)
    lv[~np.isfinite(td)] = -1
    return lv


def level_rgb(levels, steps=TD_STEPS):
    """Colors of color steps (gray for -1), the same hues as td_rgb."""
    levels = np.asarray(levels, dtype=np.int64)
    h = levels.astype(np.float64) / steps
    rgb = np.column_stack((np.clip(np.abs(h - 3.0) - 1.0, 0.0, 1.0),
                           np.clip(2.0 - np.abs(h - 2.0), 0.0, 1.0),
                           np.clip(2.0 - np.abs(h - 4.0), 0.0, 1.0)))
    rgb[levels < 0] = 0.5
    return rgb


def object_face_levels(geo, td, thr, obj, nfaces):
    """Color step per face of shown object `obj` (-2: face not shown)."""
    out = np.full(int(nfaces), -2, dtype=np.int64)
    if obj >= len(geo.obj_fidx):
        return out
    fi, fs = geo.obj_fidx[obj], geo.obj_face_shell[obj]
    if fi.size:
        out[fi] = td_levels(np.asarray(td)[fs], *thr)
    return out
