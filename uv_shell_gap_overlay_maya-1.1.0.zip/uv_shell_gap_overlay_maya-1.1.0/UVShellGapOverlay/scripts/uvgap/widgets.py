# SPDX-License-Identifier: GPL-3.0-or-later
#
# UV Shell Gap Overlay for Maya - small widgets for the panel: collapsible sections, color
# buttons, a two-handle range slider.
#
# Authors: Iurii Kruglov & Claude (Anthropic)

from .qtcompat import QtCore, QtGui, QtWidgets, Qt, Signal, color, event_pos


class Section(QtWidgets.QWidget):
    """A titled block whose content folds away (like Blender's sub-panels)."""

    def __init__(self, title, expanded=True, parent=None):
        QtWidgets.QWidget.__init__(self, parent)
        self.button = QtWidgets.QToolButton(self)
        self.button.setText(title)
        self.button.setCheckable(True)
        self.button.setChecked(expanded)
        self.button.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextBesideIcon)
        self.button.setSizePolicy(QtWidgets.QSizePolicy.Policy.Expanding, QtWidgets.QSizePolicy.Policy.Fixed)
        self.button.setStyleSheet("QToolButton { border: none; font-weight: bold; padding: 3px 0px; }")
        self.header = QtWidgets.QHBoxLayout()
        self.header.setContentsMargins(0, 0, 0, 0)
        self.header.addWidget(self.button, 1)
        self.body = QtWidgets.QWidget(self)
        self.form = QtWidgets.QFormLayout(self.body)
        self.form.setContentsMargins(14, 2, 2, 6)
        self.form.setLabelAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        self.form.setFieldGrowthPolicy(QtWidgets.QFormLayout.FieldGrowthPolicy.ExpandingFieldsGrow)
        lay = QtWidgets.QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)
        lay.addLayout(self.header)
        lay.addWidget(self.body)
        self.button.toggled.connect(self._toggled)
        self._toggled(expanded)

    def _toggled(self, on):
        self.button.setArrowType(Qt.ArrowType.DownArrow if on else Qt.ArrowType.RightArrow)
        self.body.setVisible(on)

    def add_header_widget(self, w):
        self.header.addWidget(w, 0)

    def row(self, label, widget):
        if label:
            self.form.addRow(label, widget)
        else:
            self.form.addRow(widget)
        return widget


class ColorButton(QtWidgets.QPushButton):
    """Shows a color; click to pick another."""
    changed = Signal(tuple)

    def __init__(self, rgb=(1.0, 1.0, 1.0), parent=None):
        QtWidgets.QPushButton.__init__(self, parent)
        self.setFixedHeight(20)
        self.setMinimumWidth(60)
        self._rgb = tuple(rgb)
        self.clicked.connect(self._pick)
        self.set_rgb(rgb)

    def rgb(self):
        return self._rgb

    def set_rgb(self, rgb):
        self._rgb = tuple(float(c) for c in rgb)
        q = color(self._rgb)
        self.setStyleSheet("QPushButton { background-color: %s; border: 1px solid #222; border-radius: 2px; }"
                           % q.name())

    def _pick(self):
        q = QtWidgets.QColorDialog.getColor(color(self._rgb), self, "Color")
        if q.isValid():
            rgb = (q.redF(), q.greenF(), q.blueF())
            self.set_rgb(rgb)
            self.changed.emit(rgb)


class RangeSlider(QtWidgets.QWidget):
    """Two handles on one track (0..100): drag a handle, or the band between them."""
    changed = Signal(float, float)

    def __init__(self, parent=None):
        QtWidgets.QWidget.__init__(self, parent)
        self.setMinimumHeight(24)
        self.setMinimumWidth(80)
        self.setSizePolicy(QtWidgets.QSizePolicy.Policy.Expanding, QtWidgets.QSizePolicy.Policy.Fixed)
        self.lo, self.hi = 0.0, 100.0
        self._drag = None
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)

    def set_values(self, lo, hi):
        lo, hi = max(0.0, min(100.0, float(lo))), max(0.0, min(100.0, float(hi)))
        if hi < lo:
            hi = lo
        if (lo, hi) != (self.lo, self.hi):
            self.lo, self.hi = lo, hi
            self.update()

    def _x(self, v):
        m = 7.0
        return m + (self.width() - 2 * m) * v / 100.0

    def _v(self, x):
        m = 7.0
        return max(0.0, min(100.0, (x - m) / max(1.0, self.width() - 2 * m) * 100.0))

    def paintEvent(self, _e):
        p = QtGui.QPainter(self)
        p.setRenderHint(QtGui.QPainter.RenderHint.Antialiasing, True)
        h = self.height()
        y = h * 0.5
        pal = self.palette()
        track = pal.color(QtGui.QPalette.ColorRole.Mid)
        band = pal.color(QtGui.QPalette.ColorRole.Highlight)
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(track)
        p.drawRoundedRect(QtCore.QRectF(self._x(0), y - 2, self._x(100) - self._x(0), 4), 2, 2)
        p.setBrush(band)
        p.drawRect(QtCore.QRectF(self._x(self.lo), y - 3, self._x(self.hi) - self._x(self.lo), 6))
        handle = pal.color(QtGui.QPalette.ColorRole.Button).lighter(130)
        for v in (self.lo, self.hi):
            p.setBrush(handle)
            p.setPen(pal.color(QtGui.QPalette.ColorRole.Shadow))
            p.drawEllipse(QtCore.QPointF(self._x(v), y), 6, 6)
        p.end()

    def mousePressEvent(self, e):
        x = event_pos(e).x()
        dl, dh = abs(x - self._x(self.lo)), abs(x - self._x(self.hi))
        if min(dl, dh) <= 9:
            if dl < dh or (dl == dh and x < self._x(self.lo)):
                self._drag = ("lo",)
            else:
                self._drag = ("hi",)
        elif self._x(self.lo) < x < self._x(self.hi):
            self._drag = ("band", x, self.lo, self.hi)
        else:
            self._drag = ("lo",) if x < self._x(self.lo) else ("hi",)
            self.mouseMoveEvent(e)

    def mouseMoveEvent(self, e):
        if self._drag is None:
            return
        x = event_pos(e).x()
        lo, hi = self.lo, self.hi
        if self._drag[0] == "lo":
            lo = min(self._v(x), hi)
        elif self._drag[0] == "hi":
            hi = max(self._v(x), lo)
        else:
            d = self._v(x) - self._v(self._drag[1])
            d = max(-self._drag[2], min(100.0 - self._drag[3], d))
            lo, hi = self._drag[2] + d, self._drag[3] + d
        if (lo, hi) != (self.lo, self.hi):
            self.lo, self.hi = lo, hi
            self.update()
            self.changed.emit(lo, hi)

    def mouseReleaseEvent(self, _e):
        self._drag = None

    def mouseDoubleClickEvent(self, _e):
        self.set_values(0.0, 100.0)
        self.changed.emit(0.0, 100.0)


def spin(lo, hi, decimals=1, step=1.0, suffix=""):
    if decimals == 0:
        w = QtWidgets.QSpinBox()
        w.setRange(int(lo), int(hi))
        w.setSingleStep(int(step))
    else:
        w = QtWidgets.QDoubleSpinBox()
        w.setRange(lo, hi)
        w.setDecimals(decimals)
        w.setSingleStep(step)
    if suffix:
        w.setSuffix(suffix)
    w.setKeyboardTracking(False)
    w.setAlignment(Qt.AlignmentFlag.AlignRight)
    return w


def hline():
    f = QtWidgets.QFrame()
    f.setFrameShape(QtWidgets.QFrame.Shape.HLine)
    f.setFrameShadow(QtWidgets.QFrame.Shadow.Sunken)
    return f
