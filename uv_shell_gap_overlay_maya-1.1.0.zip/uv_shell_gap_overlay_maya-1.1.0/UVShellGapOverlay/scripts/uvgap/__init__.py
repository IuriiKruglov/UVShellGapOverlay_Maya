# SPDX-License-Identifier: GPL-3.0-or-later
#
# UV Shell Gap Overlay for Maya 2022+
#
# A dockable UV Gaps window showing the selected meshes' UV layout with the pixel gaps
# between shells and to UDIM tile borders graded against minimal / needed padding, overlaps,
# tile crossings and flipped shells; shells stacked on each other on purpose counted as one,
# with a button to move the copies to another tile; texel density per shell (in the window and
# on the mesh in the 3D viewport); per-shell info blocks (density, object scale, flip state,
# orientation arrow); material sets to select, hide and measure separately; UV tools: select
# UVs, edges, faces and shells, cut, weld, move, rotate and scale.
#
#     import uvgap
#     uvgap.show()
#
# Authors: Iurii Kruglov & Claude (Anthropic)

__version__ = "1.1.0"

_panel = None


def _numpy_missing():
    import importlib
    try:
        importlib.import_module("numpy")
        return False
    except ImportError:
        pass
    # installed by the UV Gaps installer into Maya's per-version site-packages, which Maya
    # normally puts on sys.path at startup; add it now in case it didn't
    try:
        import os
        import site
        import sys
        from . import deps
        d = deps.site_packages_dir()
        if os.path.isdir(d) and d not in sys.path:
            site.addsitedir(d)
            importlib.invalidate_caches()
            importlib.import_module("numpy")
            return False
    except Exception:
        pass
    return True


def _alive(w):
    if w is None:
        return False
    try:
        from .qtcompat import isValid
        return bool(isValid(w))
    except Exception:
        return False


def show():
    """Open the UV Gaps window (or bring it to the front)."""
    global _panel
    if _numpy_missing():
        from . import deps
        if not deps.offer_numpy():
            return None
    from maya import cmds
    from .panel import PANEL_NAME, Panel
    ctrl = PANEL_NAME + "WorkspaceControl"
    if _alive(_panel) and not _panel._closed:
        try:
            if cmds.workspaceControl(ctrl, q=True, exists=True):
                cmds.workspaceControl(ctrl, e=True, visible=True)
                cmds.workspaceControl(ctrl, e=True, restore=True)
            else:
                _panel.show()
            _panel.raise_()
            return _panel
        except Exception:
            pass
    close()
    if cmds.workspaceControl(ctrl, q=True, exists=True):
        cmds.deleteUI(ctrl)
    _panel = Panel()
    if hasattr(_panel, "setDockableParameters"):  # MayaQWidgetDockableMixin
        _panel.show(dockable=True, floating=True, width=980, height=680, retain=False,
                    uiScript="import uvgap; uvgap.restore()")
        _close_with_control()
    else:
        from .qtcompat import Qt, maya_main_window
        _panel.setParent(maya_main_window(), Qt.WindowType.Window)
        _panel.resize(980, 680)
        _panel.show()
    return _panel


def restore():
    """Put the window into its workspace control when Maya rebuilds a layout (the control's
    uiScript). Reuses an open window, since Maya may also run this while show() sets it up."""
    global _panel
    if _numpy_missing():
        return None
    from maya import OpenMayaUI as omui1
    from .panel import Panel
    parent = omui1.MQtUtil.getCurrentParent()
    if not (_alive(_panel) and not _panel._closed):
        _panel = Panel()
    ptr = omui1.MQtUtil.findControl(_panel.objectName())
    if ptr is not None and parent is not None:
        omui1.MQtUtil.addWidgetToMayaLayout(int(ptr), int(parent))
    _close_with_control()
    return _panel


def _close_with_control():
    """Closing the workspace control closes the window (stops watching the scene, removes the
    3D colors), also for a control Maya restored from a layout."""
    try:
        from maya import cmds
        from .panel import PANEL_NAME
        ctrl = PANEL_NAME + "WorkspaceControl"
        if cmds.workspaceControl(ctrl, q=True, exists=True):
            cmds.workspaceControl(ctrl, e=True, closeCommand="import uvgap; uvgap.close()")
    except Exception:
        pass


def close():
    """Close the window: stops watching the scene and removes the 3D viewport colors."""
    global _panel
    if _panel is not None:
        try:
            _panel.shutdown()
        except Exception:
            pass
        try:
            if _alive(_panel):
                _panel.close()
                _panel.deleteLater()
        except Exception:
            pass
    _panel = None


def window():
    """The open window, or None."""
    return _panel if _alive(_panel) else None
