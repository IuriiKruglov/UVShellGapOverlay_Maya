# SPDX-License-Identifier: GPL-3.0-or-later
#
# UV Shell Gap Overlay for Maya - self-test. Run it inside Maya (Settings > Run Self-Test in
# the UV Gaps window, or `import uvgap.selftest; uvgap.selftest.run()`): it builds a few small
# meshes with a known UV layout, checks what the tool reads and measures, selects shells, finds
# stacks and overlaps, cuts, welds, moves, rotates and scales UVs with the UV tools, draws the
# 3D viewport colors, and deletes the meshes again.
#
# Authors: Iurii Kruglov & Claude (Anthropic)

import traceback

import numpy as np

NAME = "uvgapSelfTest"


def test_layout():
    """Three square shells, 1 x 1 cm each (Y up): A and B lie on the ground 8 px apart at
    1024 px, C stands upright with mirrored (flipped) UVs. Each is 0.2 x 0.2 in UV: 20480 px/m
    at 1024 px."""
    g = 8.0 / 1024.0
    points = [(0, 0, 0), (1, 0, 0), (1, 0, -1), (0, 0, -1),          # A, ground
              (2, 0, 0), (3, 0, 0), (3, 0, -1), (2, 0, -1),          # B, ground
              (5, 0, 0), (6, 0, 0), (6, 1, 0), (5, 1, 0)]            # C, wall facing +Z
    faces = [(0, 1, 2, 3), (4, 5, 6, 7), (8, 9, 10, 11)]
    uvs = [(0.1, 0.1), (0.3, 0.1), (0.3, 0.3), (0.1, 0.3),
           (0.3 + g, 0.1), (0.5 + g, 0.1), (0.5 + g, 0.3), (0.3 + g, 0.3),
           (0.8, 0.1), (0.6, 0.1), (0.6, 0.3), (0.8, 0.3)]           # C mirrored: clockwise
    uv_faces = [(0, 1, 2, 3), (4, 5, 6, 7), (8, 9, 10, 11)]
    return points, faces, uvs, uv_faces


def stack_layout():
    """Two more squares lying on shell A of the first mesh: D exactly on it (a stack), E the
    same size 3 % to the side (an overlap, not a stack)."""
    d = 0.2 * 0.03
    points = [(0, 0, 2), (1, 0, 2), (1, 0, 1), (0, 0, 1), (2, 0, 2), (3, 0, 2), (3, 0, 1), (2, 0, 1)]
    faces = [(0, 1, 2, 3), (4, 5, 6, 7)]
    uvs = [(0.1, 0.1), (0.3, 0.1), (0.3, 0.3), (0.1, 0.3),
           (0.1 + d, 0.1), (0.3 + d, 0.1), (0.3 + d, 0.3), (0.1 + d, 0.3)]
    return points, faces, uvs, faces


def strip_layout():
    """Two squares sharing an edge (vertices 1 and 4): one shell, 0.2 x 0.1 in UV."""
    points = [(0, 0, 5), (1, 0, 5), (2, 0, 5), (0, 0, 4), (1, 0, 4), (2, 0, 4)]
    faces = [(0, 1, 4, 3), (1, 2, 5, 4)]
    uvs = [(0.1, 0.6), (0.2, 0.6), (0.3, 0.6), (0.1, 0.7), (0.2, 0.7), (0.3, 0.7)]
    return points, faces, uvs, faces


class _Skip(Exception):
    pass


class _Report(object):
    def __init__(self):
        self.lines, self.fails = [], 0

    def check(self, cond, msg):
        self.lines.append(("ok   " if cond else "FAIL ") + msg)
        print("[UV Gaps self-test] " + self.lines[-1])
        if not cond:
            self.fails += 1
        return cond


def _make_mesh(om, cmds, layout=None, name=NAME):
    points, faces, uvs, uv_faces = layout or test_layout()
    fn = om.MFnMesh()
    tr = fn.create([om.MPoint(*p) for p in points], [len(f) for f in faces], [i for f in faces for i in f],
                   [u for u, _v in uvs], [v for _u, v in uvs])
    fn.assignUVs([len(f) for f in uv_faces], [i for f in uv_faces for i in f])
    path = om.MDagPath.getAPathTo(tr).fullPathName()
    path = cmds.rename(path, name)
    cmds.sets(path, edit=True, forceElement="initialShadingGroup")
    return cmds.ls(path, long=True)[0]


def _shape(cmds, path):
    return (cmds.listRelatives(path, shapes=True, fullPath=True) or [path])[0]


def _shells_of(eng, shape):
    """How many shells of a mesh are shown."""
    geo = eng.geo
    keys = list(geo.obj_keys)
    return int(np.count_nonzero(geo.sh_obj == keys.index(shape))) if shape in keys else 0


def _short(paths):
    return [p.split("|")[-2] if p.count("|") > 1 else p for p in paths]


def _check_stacks(rep, om, cmds, eng, tools, mayadata, path, shape, made):
    """Shells lying on each other: a stack, an overlap, All but One."""
    st = eng.settings
    path2 = _make_mesh(om, cmds, stack_layout(), NAME + "B")
    made.append(path2)
    shape2 = _shape(cmds, path2)
    cmds.select([path, path2], replace=True)
    st.update({"stacks": True, "stack_match": 99.9, "stack_tiles": 1, "same_material": False})
    eng.update()
    geo = eng.geo
    rep.check(eng.error is None and list(eng.paths) == [shape, shape2] and geo.sh_n == 5,
              "two meshes shown, in the order of their names: %d shells of %s" % (geo.sh_n, _short(eng.paths)))
    counts = eng.stacks.counts() if eng.stacks is not None else None
    rep.check(counts == (1, 2), "the square lying exactly on A is one stack with it: %s" % (counts,))
    rep.check(eng.meas is not None and eng.meas.overlap_pairs == 1,
              "the square 3 %% off is an overlap, not a stack: %s overlapping pair(s)" % (
                  eng.meas.overlap_pairs if eng.meas is not None else None))
    shells = tools.but_one(eng)
    objs = sorted(set(geo.obj_keys[int(i)] for i in geo.sh_obj[shells].tolist()))
    rep.check(shells.size == 2 and objs == [shape2], "All but One: both squares lying on A, not A itself: %d shell(s) of %s" % (
        shells.size, _short(objs)))
    before = mayadata.read_mesh(shape2).uv_table.copy()
    before_a = mayadata.read_mesh(shape).uv_table.copy()
    n = tools.move_but_one(eng)
    eng.update()
    after = mayadata.read_mesh(shape2).uv_table
    rep.check(n == 2 and np.allclose(after, before + (1.0, 0.0), atol=1e-5)
              and np.allclose(mayadata.read_mesh(shape).uv_table, before_a, atol=1e-6),
              "Move All but One: they go one tile along U, A stays")
    counts = eng.stacks.counts() if eng.stacks is not None else None
    rep.check(counts == (0, 0) and eng.meas is not None and eng.meas.overlap_pairs == 1,
              "afterwards no stack is left; the two moved squares overlap in their tile: %s, %s pair(s)" % (
                  counts, eng.meas.overlap_pairs if eng.meas is not None else None))
    st.update({"same_material": True})


def _check_tools(rep, om, cmds, eng, tools, mayadata, made):
    """The UV tools on a strip of two squares: cut, weld, weld by distance, move, rotate, scale."""
    st = eng.settings
    path3 = _make_mesh(om, cmds, strip_layout(), NAME + "C")
    made.append(path3)
    shape3 = _shape(cmds, path3)
    fn = om.MFnMesh(mayadata.dag_path(shape3))
    edge = [e for e in range(fn.numEdges) if set(fn.getEdgeVertices(e)) == {1, 4}]
    if not rep.check(len(edge) == 1, "the strip's shared edge: %s" % edge):
        return
    edge = edge[0]
    got = mayadata.edges_of_corners(shape3, [0, 1], [1, 4], [4, 1]).tolist()
    rep.check(got == [edge, edge], "an edge picked in the view maps to the mesh edge: %s (edge %d)" % (got, edge))

    def uvs():
        return mayadata.read_mesh(shape3).uv_table

    def pick(items):
        cmds.select(items, replace=True)
        eng.update()

    def shells():
        return _shells_of(eng, shape3)

    pick(path3)
    rep.check(shells() == 1 and uvs().shape[0] == 6, "the strip is one shell with 6 UVs (%d, %d)" % (shells(), uvs().shape[0]))
    eng.select_components([(shape3, np.array([edge]))], "edge", "replace")
    sel = cmds.ls(sl=True, long=True) or []
    rep.check(len(sel) == 1 and sel[0].endswith(".e[%d]" % edge), "selecting an edge from the tool: %s" % sel)
    eng.update()
    tools.cut(eng)
    eng.update()
    rep.check(shells() == 2 and uvs().shape[0] == 8, "Cut along the edge: 2 shells, 8 UVs (%d, %d)" % (
        shells(), uvs().shape[0]))
    pick(shape3 + ".e[%d]" % edge)
    tools.weld(eng)
    eng.update()
    rep.check(shells() == 1 and uvs().shape[0] == 6, "Weld with the edge selected sews it: 1 shell, 6 UVs (%d, %d)" % (
        shells(), uvs().shape[0]))
    # cut again, move one face half a pixel, weld by distance
    pick(shape3 + ".e[%d]" % edge)
    tools.cut(eng)
    pick(shape3 + ".f[1]")
    A = mayadata.read_mesh(shape3)
    ids = np.unique(A.uv_id[A.f_start[1]:A.f_start[1] + A.f_total[1]])
    before = A.uv_table.copy()
    half = 0.5 / 1024.0
    tools.move(eng, half, 0.0)
    eng.update()
    want = before.copy()
    want[ids] += (half, 0.0)
    rep.check(np.allclose(uvs(), want, atol=1e-6), "Move: a selected face's UVs move by the amount, the others stay")
    pick(path3)
    st.update({"weld_dist": 0.25, "weld_unit": "PX"})
    tools.weld_within(eng)
    eng.update()
    rep.check(shells() == 2, "Weld Within 0.25 px: UVs half a pixel apart stay apart (%d shells)" % shells())
    st.update({"weld_dist": 1.0, "weld_unit": "PX"})
    tools.weld_within(eng)
    eng.update()
    rep.check(shells() == 1 and uvs().shape[0] == 6, "Weld Within 1 px welds them: 1 shell, 6 UVs (%d, %d)" % (
        shells(), uvs().shape[0]))
    # rotate and scale around the middle of the selection
    st.update({"pivot": "SELECTION"})
    pick(shape3 + ".map[0:%d]" % (uvs().shape[0] - 1))
    before = uvs().copy()
    c = (before.min(axis=0) + before.max(axis=0)) * 0.5
    d = before - c
    mayadata._ROTATION["sign"] = None  # (find out again which way Maya's angle turns)
    tools.rotate(eng, 90.0)
    eng.update()
    after = uvs()
    ccw = np.column_stack((-d[:, 1], d[:, 0])) + c
    cw = np.column_stack((d[:, 1], -d[:, 0])) + c
    how = "counterclockwise" if np.allclose(after, ccw, atol=1e-5) else \
        "CLOCKWISE" if np.allclose(after, cw, atol=1e-5) else "somewhere else: %s" % np.round(after, 4).tolist()
    sign = mayadata._ROTATION["sign"]
    rep.check(how == "counterclockwise", "Rotate 90: around the selection's middle, %s (Maya's own angle turns %s)" % (
        how, {1.0: "counterclockwise", -1.0: "clockwise"}.get(sign, "an unknown way")))
    tools.rotate(eng, -90.0)
    eng.update()
    rep.check(np.allclose(uvs(), before, atol=1e-5), "Rotate -90: back")
    tools.scale(eng, 2.0, 0.5)
    eng.update()
    rep.check(np.allclose(uvs(), d * (2.0, 0.5) + c, atol=1e-5), "Scale 2 x 0.5 around the selection's middle")
    tools.scale(eng, 0.5, 2.0)
    eng.update()
    rep.check(np.allclose(uvs(), before, atol=1e-5), "Scale 0.5 x 2: back")
    st.update({"move_amount": 16.0, "move_unit": "PX"})
    tools.move_step(eng, "up")
    eng.update()
    rep.check(np.allclose(uvs(), before + (0.0, 16.0 / 1024.0), atol=1e-6), "Move up by 16 px at 1024")


def run(interactive=True):
    """Run the checks; returns the number of failures."""
    import maya.api.OpenMaya as om
    from maya import cmds

    from . import __version__, mayadata, td3d, tools, window
    from .engine import Engine
    from .qtcompat import QtCore

    rep = _Report()
    rep.check(True, "UV Shell Gap Overlay %s, Maya %s, Python %s, NumPy %s, Qt %s" % (
        __version__, cmds.about(version=True), __import__("sys").version.split()[0], np.__version__,
        QtCore.qVersion()))
    try:
        w = window()
        if w is not None:
            v = w.view
            if type(v).__name__ != "GLView":
                how = "QPainter (the standard view)"
            elif getattr(v, "_ready", False):
                how = "the GPU (%s)" % getattr(v, "gl_info", "OpenGL")
            else:
                how = "the GPU, but OpenGL hasn't started (the standard view takes over if it doesn't)"
            rep.check(True, "the window draws with " + how)
    except Exception:
        pass
    sel_before = cmds.ls(sl=True, long=True) or []
    # meshes in component mode are shown too: only the test meshes should be, for now
    hilite_before = cmds.ls(hilite=True, long=True) or []
    if hilite_before:
        cmds.hilite(hilite_before, unHilite=True)
    made, mat = [], []
    was_3d = td3d._State.enabled
    eng = None
    # nothing here goes into the undo queue: MFnMesh.create isn't undoable, so undoing the
    # rest would bring back a stray copy of the test mesh
    no_undo = td3d._NoUndo()
    no_undo.__enter__()
    try:
        path = _make_mesh(om, cmds)
        made.append(path)
        shape = _shape(cmds, path)
        cmds.select(path, replace=True)
        cmds.upAxis(q=True, axis=True)

        # reading
        A = mayadata.read_mesh(shape)
        rep.check(A.f_total.tolist() == [4, 4, 4] and A.uv_table.shape == (12, 2),
                  "reads faces and UVs: %s faces, %d UVs" % (A.f_total.tolist(), A.uv_table.shape[0]))
        rep.check(np.allclose(A.co[2], (1, 0, -1)), "reads points in centimeters: %s" % (A.co[2].tolist(),))
        rep.check(np.allclose(A.matrix, np.eye(4)), "reads the world matrix")
        rep.check(A.mat_keys and A.f_mat.tolist() == [0, 0, 0], "reads the material: %s" % (A.mat_keys,))

        # the engine, computing right away (the window's computes in a background thread)
        eng = Engine(threaded=False)
        st = eng.settings
        st.update({"resolution": "1024", "points": 24, "search_px": 32.0, "tile_border": True,
                   "same_material": True, "selected_only": False, "show": True, "td_show": True,
                   "info_show": True, "show_orientation": True, "hidden": (), "checked": ()})
        eng.active = True
        eng.update()
        geo, meas = eng.geo, eng.meas
        rep.check(eng.error is None, "update without errors" + ("" if eng.error is None else ":\n" + eng.error))
        rep.check(geo.sh_n == 3 and geo.nshells == 3, "3 shells: %d" % geo.sh_n)
        rep.check(meas is not None and meas.dist.size > 0 and np.allclose(meas.dist, 8.0, atol=1e-3),
                  "every gap between A and B is 8 px: %s" % (np.unique(np.round(meas.dist, 3)).tolist()
                                                           if meas is not None else None))
        rep.check(int(geo.flipped.sum()) == 1 and bool(geo.flipped[2]), "C is flipped")
        rep.check(np.allclose(eng.td, 20480.0, rtol=1e-6), "texel density 20480 px/m: %s" % np.round(eng.td, 2).tolist())
        if mayadata.up_axis() == "y":
            rep.check(geo.sh_axis.tolist() == [3, 3, 2] and np.allclose(geo.sh_orient, [(0, 1)] * 3, atol=1e-6),
                      "orientation arrows: -Z on the ground shells, +Y on the wall: axes %s" % geo.sh_axis.tolist())

        # selection
        cmds.select(shape + ".f[1]", replace=True)
        eng.update()
        rep.check(eng.component_selection and eng.sel_shells.tolist() == [False, True, False],
                  "a selected face selects its shell: %s" % eng.sel_shells.tolist())
        n = eng.select_shells([2], "replace")
        uv_sel = set()
        for item in cmds.ls(sl=True, long=True) or []:
            m = mayadata._RANGE.search(item)
            if ".map[" in item and m:
                uv_sel.update(range(int(m.group(1)), int(m.group(2) or m.group(1)) + 1))
        rep.check(n == 1 and sorted(uv_sel) == [8, 9, 10, 11], "selecting shell C selects its UVs: %s" % sorted(uv_sel))

        # materials
        red = cmds.shadingNode("lambert", asShader=True, name=NAME + "_red")
        sg = cmds.sets(renderable=True, noSurfaceShader=True, empty=True, name=NAME + "_redSG")
        cmds.connectAttr(red + ".outColor", sg + ".surfaceShader")
        mat.extend([red, sg])
        cmds.sets(shape + ".f[1]", edit=True, forceElement=sg)
        eng.invalidate()
        eng.update()
        keys = [eng.geo.mat_keys[i] for i in eng.geo.sh_mat.tolist()]
        rep.check(keys[1] == red and keys[0] != red, "material sets by shell: %s" % keys)
        rep.check(red in eng.materials, "material list: %s" % eng.materials)
        st.update({"hidden": (red,)})
        eng.update()
        rep.check(eng.geo.sh_n == 2, "hiding the red set hides shell B: %d shells" % eng.geo.sh_n)
        st.update({"hidden": ()})
        eng.update()

        # shells lying on each other, and the UV tools
        try:
            _check_stacks(rep, om, cmds, eng, tools, mayadata, path, shape, made)
        except Exception:
            rep.check(False, "stacks and overlaps:\n" + traceback.format_exc())
        try:
            _check_tools(rep, om, cmds, eng, tools, mayadata, made)
        except Exception:
            rep.check(False, "UV tools:\n" + traceback.format_exc())
        cmds.hilite(list(made), unHilite=True)
        cmds.select(path, replace=True)
        eng.update()

        # 3D viewport (needs Viewport 2.0: not in batch mode)
        if cmds.about(batch=True):
            rep.check(True, "3D viewport: skipped in batch mode")
            raise _Skip()
        try:
            td3d.enable(True)
            st.update({"td_show_3d": True})
            td3d._State.key = None
            td3d.update(eng)
            items = td3d.draw_items()
            rep.check(td3d.find_node() is not None, "3D: the overlay locator exists")
            rep.check(len(items) == 1 and sum(len(g) for _p, g in items) >= 1,
                      "3D: triangles grouped by color: %d group(s)" % sum(len(g) for _p, g in items))
            if interactive:
                before = td3d._State.draws
                cmds.refresh(force=True)
                rep.check(td3d._State.draws > before, "3D: the viewport drew the colors")
        except Exception:
            rep.check(False, "3D viewport:\n" + traceback.format_exc())
    except _Skip:
        pass
    except Exception:
        rep.check(False, "unexpected error:\n" + traceback.format_exc())
    finally:
        try:
            if eng is not None:
                eng.stop()
            if not was_3d:
                td3d.enable(False)
            if made or mat:
                cmds.delete([n for n in made + mat if cmds.objExists(n)])
        except Exception:
            print(traceback.format_exc())
        no_undo.__exit__(None, None, None)
        td3d._State.key = None
        try:
            w = window()
            if w is not None:  # back to what the open window shows
                w.engine.invalidate()
        except Exception:
            pass
        try:
            if sel_before:
                cmds.select(sel_before, replace=True)
            else:
                cmds.select(clear=True)
            if hilite_before:
                cmds.hilite([n for n in hilite_before if cmds.objExists(n)])
        except Exception:
            pass
    summary = "%d check%s, %d failed" % (len(rep.lines), "" if len(rep.lines) == 1 else "s", rep.fails)
    print("[UV Gaps self-test] " + summary)
    if interactive and not cmds.about(batch=True):
        failed = [ln.split("\n")[0] for ln in rep.lines if ln.startswith("FAIL")]
        body = "\n".join(failed[:12]) if failed else "Everything works as expected."
        cmds.confirmDialog(title="UV Gaps self-test", message=summary + "\n\n" + body +
                           "\n\nThe full report is in the Script Editor.", button=["OK"])
    return rep.fails
