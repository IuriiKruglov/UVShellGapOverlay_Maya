# SPDX-License-Identifier: GPL-3.0-or-later
#
# UV Shell Gap Overlay for Maya - installer. Drag and drop this file into a Maya viewport.
#
# Copies the UVShellGapOverlay module into your Maya modules folder (so every Maya 2022+ you
# use finds it), installs NumPy if Maya's Python lacks it, adds a "UV Gaps" button to the
# current shelf and opens the window.
#
# Authors: Iurii Kruglov & Claude (Anthropic)

import os
import shutil
import sys

MODULE = "UVShellGapOverlay"
VERSION = "1.1.0"
SHELF_COMMAND = "import uvgap; uvgap.show()"


def onMayaDroppedPythonFile(*_args):
    install()


def _module_source():
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), MODULE)


def install():
    from maya import cmds, mel

    src = _module_source()
    if not os.path.isdir(os.path.join(src, "scripts", "uvgap")):
        cmds.confirmDialog(title="UV Shell Gap Overlay", button=["OK"],
                           message="The %s folder must sit next to install.py.\nUnpack the whole zip first." % MODULE)
        return
    modules = os.path.join(cmds.internalVar(userAppDir=True), "modules")
    dst = os.path.join(modules, MODULE)
    if not os.path.isdir(modules):
        os.makedirs(modules)

    # an earlier version may be running: close its window (that also deletes its 3D overlay
    # node), then unload its plug-in so the new one loads
    try:
        import uvgap
        uvgap.close()
    except Exception:
        pass
    try:
        if cmds.pluginInfo("uvGapOverlay.py", q=True, loaded=True):
            cmds.unloadPlugin("uvGapOverlay.py")
    except Exception as e:
        print("UV Shell Gap Overlay: the old plug-in stays loaded until Maya restarts (%s)" % e)

    if os.path.normcase(os.path.abspath(src)) != os.path.normcase(os.path.abspath(dst)):
        if os.path.isdir(dst):
            shutil.rmtree(dst)
        shutil.copytree(src, dst)
    with open(os.path.join(modules, MODULE + ".mod"), "w") as f:
        f.write("+ %s %s %s\n" % (MODULE, VERSION, dst.replace("\\", "/")))

    # this session: the module is read at startup, so add its folders now
    scripts = os.path.join(dst, "scripts")
    for name in [m for m in sys.modules if m == "uvgap" or m.startswith("uvgap.")]:
        del sys.modules[name]  # an older copy
    if scripts not in sys.path:
        sys.path.insert(0, scripts)
    for var, sub in (("MAYA_PLUG_IN_PATH", "plug-ins"), ("XBMLANGPATH", "icons")):
        folder = os.path.join(dst, sub)
        parts = [p for p in os.environ.get(var, "").split(os.pathsep) if p]
        if folder not in parts:
            os.environ[var] = os.pathsep.join([folder] + parts)

    from uvgap import deps
    numpy_ok = deps.offer_numpy()

    try:
        _add_shelf_button(cmds, mel, os.path.join(dst, "icons", "uvGapOverlay.png"))
    except Exception as e:
        print("UV Shell Gap Overlay: no shelf button added (%s)" % e)

    msg = "UV Shell Gap Overlay %s is installed in\n%s\n\nOpen it with the UV Gaps shelf button or:\n%s" % (
        VERSION, dst, SHELF_COMMAND)
    if not numpy_ok:
        msg += "\n\nIt needs NumPy before it can open (see the Script Editor)."
    cmds.confirmDialog(title="UV Shell Gap Overlay", message=msg, button=["OK"])
    if numpy_ok:
        import uvgap
        uvgap.show()


def _add_shelf_button(cmds, mel, icon):
    top = mel.eval("$uvgap_tmp = $gShelfTopLevel")
    shelf = cmds.tabLayout(top, q=True, selectTab=True)
    for b in cmds.shelfLayout(shelf, q=True, childArray=True) or []:
        try:
            if cmds.shelfButton(b, q=True, command=True) == SHELF_COMMAND:
                return  # already there
        except Exception:
            pass
    cmds.shelfButton(parent=shelf, command=SHELF_COMMAND, sourceType="python", label="UV Gaps",
                     annotation="UV Shell Gap Overlay: pixel gaps and texel density of UV shells",
                     image=icon if os.path.isfile(icon) else "commandButton.png", imageOverlayLabel="")
